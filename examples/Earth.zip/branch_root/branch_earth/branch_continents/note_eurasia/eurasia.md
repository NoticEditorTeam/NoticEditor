Eurasia - Wikipedia, the free encyclopedia                        
<div></div> 
<div></div> 
<div> 
<a></a> 
<div></div> 
<div> 
</div> 
<h1>Eurasia</h1> 
<div> 
<div>
From Wikipedia, the free encyclopedia
</div> 
<div></div> 
<div>
 Jump to: 
<a href="https://en.wikipedia.org/wiki#mw-head">navigation</a>, 
<a href="https://en.wikipedia.org/wiki#p-search">search</a> 
</div> 
<div>
<div>
For other uses, see 
<a href="https://en.wikipedia.org/wiki/Eurasia_(disambiguation)" title="Eurasia (disambiguation)">Eurasia (disambiguation)</a>.
</div> 
<div>
"Eurasian" redirects here. For people of mixed European and Asian ancestry, see 
<a href="https://en.wikipedia.org/wiki/Eurasian_(mixed_ancestry)" title="Eurasian (mixed ancestry)">Eurasian (mixed ancestry)</a>.
</div> 
<table> 
<caption>
Eurasia
</caption> 
<tbody>
<tr> 
<td colspan="2"><a href="https://en.wikipedia.org/wiki/File:Eurasia_(orthographic_projection).svg"><img alt="Eurasia (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Eurasia_%28orthographic_projection%29.svg/250px-Eurasia_%28orthographic_projection%29.svg.png" width="250" height="250"></a></td> 
</tr> 
<tr> 
<th scope="row">Area</th> 
<td>54,759,000&nbsp;km<sup>2</sup></td> 
</tr> 
<tr> 
<th scope="row">Population</th> 
<td>4,620,000,000 (2010)</td> 
</tr> 
<tr> 
<th scope="row">Pop. density</th> 
<td>84/km<sup>2</sup></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Demonym" title="Demonym">Demonym</a></th> 
<td>Eurasian</td> 
</tr> 
<tr> 
<th scope="row">Countries</th> 
<td>93 (<a href="https://en.wikipedia.org/wiki/List_of_sovereign_states_and_dependent_territories_in_Eurasia" title="List of sovereign states and dependent territories in Eurasia">list</a>)</td> 
</tr> 
<tr> 
<th scope="row">Dependencies</th> 
<td>9</td> 
</tr> 
<tr> 
<th scope="row">Unrecognized regions</th> 
<td>8</td> 
</tr> 
<tr> 
<th scope="row">Time zones</th> 
<td><a href="https://en.wikipedia.org/wiki/UTC%C2%B10" title="UTC±0">UTC</a> to <a href="https://en.wikipedia.org/wiki/UTC%2B12" title="UTC+12">UTC+12</a></td> 
</tr> 
</tbody>
</table> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Two-point-equidistant-asia.jpg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Two-point-equidistant-asia.jpg/220px-Two-point-equidistant-asia.jpg" width="220" height="164"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Two-point-equidistant-asia.jpg" title="Enlarge"></a>
</div> Eurasia with surrounding areas of 
<a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a> and 
<a href="https://en.wikipedia.org/wiki/Australasia" title="Australasia">Australasia</a> visible
</div> 
</div> 
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Earth_Eastern_Hemisphere.jpg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Earth_Eastern_Hemisphere.jpg/220px-Earth_Eastern_Hemisphere.jpg" width="220" height="220"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Earth_Eastern_Hemisphere.jpg" title="Enlarge"></a>
</div> Afro-Eurasian aspect of 
<a href="https://en.wikipedia.org/wiki/The_Blue_Marble" title="The Blue Marble">Earth</a>
</div> 
</div> 
</div> 
<p><b>Eurasia</b> is the combined <a href="https://en.wikipedia.org/wiki/Continent" title="Continent">continental</a> landmass of <a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a> and <a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-1"><span>[</span>1<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-2"><span>[</span>2<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-NatlGeo-3"><span>[</span>3<span>]</span></a></sup> The term is a <a href="https://en.wikipedia.org/wiki/Portmanteau" title="Portmanteau">portmanteau</a> of its two constituents. Located primarily in the <a href="https://en.wikipedia.org/wiki/Northern_Hemisphere" title="Northern Hemisphere">Northern</a> and <a href="https://en.wikipedia.org/wiki/Eastern_Hemisphere" title="Eastern Hemisphere">Eastern Hemispheres</a>, it is bordered by the <a href="https://en.wikipedia.org/wiki/Atlantic_Ocean" title="Atlantic Ocean">Atlantic Ocean</a> on the west, the <a href="https://en.wikipedia.org/wiki/Pacific_Ocean" title="Pacific Ocean">Pacific Ocean</a> to the east, the <a href="https://en.wikipedia.org/wiki/Arctic_Ocean" title="Arctic Ocean">Arctic Ocean</a> on the north, and by <a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a>, the <a href="https://en.wikipedia.org/wiki/Mediterranean_Sea" title="Mediterranean Sea">Mediterranean Sea</a>, the Pacific Ocean and the <a href="https://en.wikipedia.org/wiki/Indian_Ocean" title="Indian Ocean">Indian Ocean</a> to the south.<sup><a href="https://en.wikipedia.org/wiki#cite_note-4"><span>[</span>4<span>]</span></a></sup> The division between Europe and Asia as two different continents is a historical and cultural construct, with no clear physical separation between them; thus, in some parts of the world, Eurasia is recognized as the largest of five or six continents.<sup><a href="https://en.wikipedia.org/wiki#cite_note-NatlGeo-3"><span>[</span>3<span>]</span></a></sup></p> 
<p>Eurasia covers around 55,000,000 square kilometres (21,000,000&nbsp;sq&nbsp;mi), or around 36.2% of the <a href="https://en.wikipedia.org/wiki/Earth" title="Earth">Earth</a>'s total land area. The landmass contains around 5.0 billion people, equating to approximately 72% of the <a href="https://en.wikipedia.org/wiki/Human_population" title="Human population">human population</a>. Humans first settled in Eurasia between 60,000 and 125,000 years ago.</p> 
<p></p> 
<div> 
<div> 
<h2>Contents</h2> 
</div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki#Overview"><span>1</span> <span>Overview</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#History"><span>2</span> <span>History</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Geology"><span>3</span> <span>Geology</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Geopolitics"><span>4</span> <span>Geopolitics</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Use_of_term"><span>5</span> <span>Use of term</span></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki#History_of_the_Europe_and_Asia_division"><span>5.1</span> <span>History of the Europe and Asia division</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Anthropology_and_genetics"><span>5.2</span> <span>Anthropology and genetics</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Geography"><span>5.3</span> <span>Geography</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Post-Soviet_countries"><span>5.4</span> <span>Post-Soviet countries</span></a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki#See_also"><span>6</span> <span>See also</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#References"><span>7</span> <span>References</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#External_links"><span>8</span> <span>External links</span></a></li> 
</ul> 
</div> 
<p></p> 
<h2><span>Overview</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=1" title="Edit section: Overview">edit</a><span>]</span></span></h2> 
<p><a href="https://en.wikipedia.org/wiki/Physical_geography" title="Physical geography">Physiographically</a>, Eurasia is a single continent.<sup><a href="https://en.wikipedia.org/wiki#cite_note-NatlGeo-3"><span>[</span>3<span>]</span></a></sup> The concepts of <a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a> and <a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a> as distinct continents date back to <a href="https://en.wikipedia.org/wiki/Classical_antiquity" title="Classical antiquity">antiquity</a> and their borders are geologically arbitrary, with the <a href="https://en.wikipedia.org/wiki/Ural_Mountains" title="Ural Mountains">Ural</a> and <a href="https://en.wikipedia.org/wiki/Caucasus_Mountains" title="Caucasus Mountains">Caucasus</a> ranges being the main delimiters between the two. Eurasia is connected to <a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a> at the <a href="https://en.wikipedia.org/wiki/Suez_Canal" title="Suez Canal">Suez Canal</a>, and Eurasia is sometimes combined with Africa as the <a href="https://en.wikipedia.org/wiki/Supercontinent" title="Supercontinent">supercontinent</a> <a href="https://en.wikipedia.org/wiki/Afro-Eurasia" title="Afro-Eurasia">Afro-Eurasia</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-5"><span>[</span>5<span>]</span></a></sup></p> 
<h2><span>History</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=2" title="Edit section: History">edit</a><span>]</span></span></h2> 
<div>
Further information: 
<a href="https://en.wikipedia.org/wiki/Foreign_interactions_with_Europe" title="Foreign interactions with Europe">Foreign interactions with Europe</a>
</div> 
<p>Eurasia has been the host of many ancient civilizations, including those based in <a href="https://en.wikipedia.org/wiki/Mesopotamia" title="Mesopotamia">Mesopotamia</a> and the <a href="https://en.wikipedia.org/wiki/Indus_Valley" title="Indus Valley">Indus Valley</a>.</p> 
<p>The <a href="https://en.wikipedia.org/wiki/Silk_Road" title="Silk Road">Silk Road</a> symbolizes trade and cultural exchange linking Eurasian cultures through history and has been an increasingly popular topic. Over recent decades the idea of a greater <a href="https://en.wikipedia.org/wiki/History_of_Eurasia" title="History of Eurasia">Eurasian history</a> has developed with the aim of investigating the genetic, cultural and <a href="https://en.wikipedia.org/wiki/Linguistics" title="Linguistics">linguistic</a> relationships between European and Asian cultures of antiquity, which had long been considered distinct.</p> 
<h2><span>Geology</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=3" title="Edit section: Geology">edit</a><span>]</span></span></h2> 
<div>
Main article: 
<a href="https://en.wikipedia.org/wiki/Laurasia" title="Laurasia">Laurasia</a>
</div> 
<p>Eurasia formed 375 to 325 million years ago with the merging of <a href="https://en.wikipedia.org/wiki/Siberia_(continent)" title="Siberia (continent)">Siberia</a> (once a separate continent), <a href="https://en.wikipedia.org/wiki/Kazakhstania" title="Kazakhstania">Kazakhstania</a>, and <a href="https://en.wikipedia.org/wiki/Baltica" title="Baltica">Baltica</a>, which was joined to <a href="https://en.wikipedia.org/wiki/Laurentia" title="Laurentia">Laurentia</a>, now North America, to form <a href="https://en.wikipedia.org/wiki/Euramerica" title="Euramerica">Euramerica</a>. Chinese <a href="https://en.wikipedia.org/wiki/Craton" title="Craton">cratons</a> collided with Siberia's southern coast.</p> 
<h2><span>Geopolitics</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=4" title="Edit section: Geopolitics">edit</a><span>]</span></span></h2> 
<p>Originally, “Eurasia” is a geographical notion: in this sense, it is simply the biggest continent; the combined landmass of Europe and Asia. However, geopolitically, the word has several different meanings, reflecting the specific geopolitical interests of each nation.<sup><a href="https://en.wikipedia.org/wiki#cite_note-6"><span>[</span>6<span>]</span></a></sup> “Eurasia” is one of the most important geopolitical concepts; as <a href="https://en.wikipedia.org/wiki/Zbigniew_Brzezinski" title="Zbigniew Brzezinski">Zbigniew Brzezinski</a> observed:</p> 
<p><i>“Ever since the continents started interacting politically, some five hundred years ago, Eurasia has been the center of world power. A power that dominates “Eurasia” would control two of the world’s three most advanced and economically productive regions. A mere glance at the map also suggests that control over “Eurasia” would almost automatically entail Africa’s subordination, rendering the Western Hemisphere and Oceania geopolitically peripheral to the world’s central continent. About 75 per cent of the world’s people live in “Eurasia”, and most of the world’s physical wealth is there as well, both in its enterprises and underneath its soil. “Eurasia” accounts for about three-fourths of the world’s known energy resources.”<sup><a href="https://en.wikipedia.org/wiki#cite_note-7"><span>[</span>7<span>]</span></a></sup></i></p> 
<p>In the widest possible sense, the geopolitical definition of “Eurasia” is consistent with its geographical area.<sup>[<i><a href="https://en.wikipedia.org/wiki/Wikipedia:Citation_needed" title="Wikipedia:Citation needed"><span>citation needed</span></a></i>]</sup> This is sometimes the way the word is understood in countries located at the fringes of, or outside, this area<sup>[<i><a href="https://en.wikipedia.org/wiki/Wikipedia:Citation_needed" title="Wikipedia:Citation needed"><span>citation needed</span></a></i>]</sup>, and it is generally what is meant by “Eurasia” in political circles (see <a href="https://en.wikipedia.org/wiki/Zbigniew_Brzezinski" title="Zbigniew Brzezinski">Zbigniew Brzezinski</a>) in the USA, Japan and India.</p> 
<p>In Western Europe when political scientists talk about “Eurasia”, they generally mean Russia (including Ukraine) integrated into Europe, economically, politically, and even militarily<sup>[<i><a href="https://en.wikipedia.org/wiki/Wikipedia:Citation_needed" title="Wikipedia:Citation needed"><span>citation needed</span></a></i>]</sup>. Since Napoleon, European strategists have understood the importance of allying with Russia, and the potential consequences of failing to do so. At the moment one of the most prominent projects of European Union is <a href="https://en.wikipedia.org/wiki/Russia%E2%80%93European_Union_relations" title="Russia–European Union relations">Russia - EU Four Common Spaces Initiative.</a> A political and economic union of former Soviet states named the <a href="https://en.wikipedia.org/wiki/Eurasian_Union" title="Eurasian Union">Eurasian Union</a> is scheduled for establishment in 2015, similar in concept to the <a href="https://en.wikipedia.org/wiki/European_Union" title="European Union">European Union</a>. As of 2014 neither encompasses all states within Eurasia.</p> 
<p>The Russian concept of “Eurasia” is very different from the European one. It is a view that has older roots than the European one - not surprisingly, considering Russia's geographic position<sup>[<i><a href="https://en.wikipedia.org/wiki/Wikipedia:Citation_needed" title="Wikipedia:Citation needed"><span>citation needed</span></a></i>]</sup>. Russian politologists traditionally view Russia itself, being both European and Asian, as “Eurasian.” The geopolitical area of the Russian concept of “Eurasia” corresponded initially more or less to the land area of Imperial Russia in 1914, including parts of Eastern Europe.<sup><a href="https://en.wikipedia.org/wiki#cite_note-8"><span>[</span>8<span>]</span></a></sup> There is undeniably an influence of Panslavism in this definition; originally the idea of “Eurasia” was more romantically rooted in natural geography. It was the idea that the people scattered across the land called “Eurasia” shared common spiritual values due to its geographic traits, such as a flat land with few coastlines but important rivers, a particular climate (continental, often harshly so), and a certain landscape (steppe, taiga, tundra). This idea was more or less realised, but with difficulty, during the last phases of the Russian Empire and was then realised again with the Soviet Union after 1945, though not stably enough for enduring success. Today, though this Russian geopolitical interest still exists, the physical area of the Russian “Eurasia” is now more realistically assessed. The Russian view today is that “Eurasia” consists of the land lying between Europe and Asia proper; namely, those made up of Western and Central Russia, Belarus, Ukraine, part of Caucasus, Uzbekistan, Kazakhstan, Tajikistan, and Kyrgyzstan (see <a href="https://en.wikipedia.org/wiki/Eurasian_Economic_Union" title="Eurasian Economic Union">Eurasian Economic Union</a>). Just as in the case of the European concept of “Eurasia,” the Russian version of “Eurasia” is a geopolitical interest that underpins foreign policy in that part of the world. Thus, it is not surprising that today one of Russia's main geopolitical interests lies in ever closer integration with those countries that it considers part of “Eurasia.”<sup><a href="https://en.wikipedia.org/wiki#cite_note-9"><span>[</span>9<span>]</span></a></sup></p> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:ASEM.PNG"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/ASEM.PNG/300px-ASEM.PNG" width="300" height="220"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:ASEM.PNG" title="Enlarge"></a>
</div> Members of the 
<a href="https://en.wikipedia.org/wiki/Asia-Europe_Meeting" title="Asia-Europe Meeting">ASEM</a>
</div> 
</div> 
</div> 
<p>Every two years since 1996 a meeting of most Asian and European countries is organised as the <a href="https://en.wikipedia.org/wiki/Asia-Europe_Meeting" title="Asia-Europe Meeting">Asia-Europe Meeting</a> (ASEM).</p> 
<h2><span>Use of term</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=5" title="Edit section: Use of term">edit</a><span>]</span></span></h2> 
<h3><span>History of the Europe and Asia division</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=6" title="Edit section: History of the Europe and Asia division">edit</a><span>]</span></span></h3> 
<p>In ancient times, the <a href="https://en.wikipedia.org/wiki/Greeks" title="Greeks">Greeks</a> classified Europe (derived from the mythological <a href="https://en.wikipedia.org/wiki/Phoenicians" title="Phoenicians">Phoenician</a> princess <a href="https://en.wikipedia.org/wiki/Europa_(mythology)" title="Europa (mythology)">Europa</a>) and Asia (derived from <a href="https://en.wikipedia.org/wiki/Asia_(mythology)" title="Asia (mythology)">Asia</a>, a woman in <a href="https://en.wikipedia.org/wiki/Greek_mythology" title="Greek mythology">Greek mythology</a>) as separate "lands". Where to draw the dividing line between the two regions is still a matter of discussion. Especially whether the <a href="https://en.wikipedia.org/wiki/Kuma-Manych_Depression" title="Kuma-Manych Depression">Kuma-Manych Depression</a> or the <a href="https://en.wikipedia.org/wiki/Caucasus_Mountains" title="Caucasus Mountains">Caucasus Mountains</a> form the southeast boundary is disputed, since <a href="https://en.wikipedia.org/wiki/Mount_Elbrus" title="Mount Elbrus">Mount Elbrus</a> would be part of Europe in the latter case, making it (and not <a href="https://en.wikipedia.org/wiki/Mont_Blanc" title="Mont Blanc">Mont Blanc</a>) Europe's highest mountain. Most accepted is probably the boundary as defined by <a href="https://en.wikipedia.org/wiki/Philip_Johan_von_Strahlenberg" title="Philip Johan von Strahlenberg">Philip Johan von Strahlenberg</a> in the 18th century. He defined the dividing line along the <a href="https://en.wikipedia.org/wiki/Aegean_Sea" title="Aegean Sea">Aegean Sea</a>, <a href="https://en.wikipedia.org/wiki/Dardanelles" title="Dardanelles">Dardanelles</a>, <a href="https://en.wikipedia.org/wiki/Sea_of_Marmara" title="Sea of Marmara">Sea of Marmara</a>, <a href="https://en.wikipedia.org/wiki/Bosporus" title="Bosporus">Bosporus</a>, <a href="https://en.wikipedia.org/wiki/Black_Sea" title="Black Sea">Black Sea</a>, <a href="https://en.wikipedia.org/wiki/Kuma%E2%80%93Manych_Depression" title="Kuma–Manych Depression">Kuma–Manych Depression</a>, <a href="https://en.wikipedia.org/wiki/Caspian_Sea" title="Caspian Sea">Caspian Sea</a>, <a href="https://en.wikipedia.org/wiki/Ural_River" title="Ural River">Ural River</a>, and <a href="https://en.wikipedia.org/wiki/Ural_Mountains" title="Ural Mountains">Ural Mountains</a>.</p> 
<h3><span>Anthropology and genetics</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=7" title="Edit section: Anthropology and genetics">edit</a><span>]</span></span></h3> 
<p>In modern usage, the term "Eurasian" is a demonym usually meaning "of or relating to Eurasia" or "a native or inhabitant of Eurasia".<sup><a href="https://en.wikipedia.org/wiki#cite_note-10"><span>[</span>10<span>]</span></a></sup></p> 
<p>The term "Eurasian" is also used to describe people of combined "Asian" and "European" descent.</p> 
<p>West or western Eurasia is a loose geographic definition used in some disciplines, such as <a href="https://en.wikipedia.org/wiki/Genetics" title="Genetics">genetics</a> or <a href="https://en.wikipedia.org/wiki/Anthropology" title="Anthropology">anthropology</a>, to refer to the region inhabited by the relatively homogeneous population of <a href="https://en.wikipedia.org/wiki/West_Asia" title="West Asia">West Asia</a> and <a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a>. The people of this region are sometimes described collectively as <b>West</b> or <b>Western Eurasians</b>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-11"><span>[</span>11<span>]</span></a></sup></p> 
<h3><span>Geography</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=8" title="Edit section: Geography">edit</a><span>]</span></span></h3> 
<p>Located primarily in the <a href="https://en.wikipedia.org/wiki/Eastern_Hemisphere" title="Eastern Hemisphere">eastern</a> and <a href="https://en.wikipedia.org/wiki/Northern_Hemisphere" title="Northern Hemisphere">northern hemispheres</a>, Eurasia is considered a <a href="https://en.wikipedia.org/wiki/Supercontinent" title="Supercontinent">supercontinent</a>, part of the supercontinent of <a href="https://en.wikipedia.org/wiki/Afro-Eurasia" title="Afro-Eurasia">Afro-Eurasia</a> or simply a continent in its own right.<sup><a href="https://en.wikipedia.org/wiki#cite_note-12"><span>[</span>12<span>]</span></a></sup> In <a href="https://en.wikipedia.org/wiki/Plate_tectonics" title="Plate tectonics">plate tectonics</a>, the <a href="https://en.wikipedia.org/wiki/Eurasian_Plate" title="Eurasian Plate">Eurasian Plate</a> includes Europe and most of Asia but not the <a href="https://en.wikipedia.org/wiki/Indian_subcontinent" title="Indian subcontinent">Indian subcontinent</a>, the <a href="https://en.wikipedia.org/wiki/Arabian_Peninsula" title="Arabian Peninsula">Arabian Peninsula</a> or the area of the <a href="https://en.wikipedia.org/wiki/Russian_Far_East" title="Russian Far East">Russian Far East</a> east of the <a href="https://en.wikipedia.org/wiki/Chersky_Range" title="Chersky Range">Chersky Range</a>.</p> 
<h3><span>Post-Soviet countries</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=9" title="Edit section: Post-Soviet countries">edit</a><span>]</span></span></h3> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Eurasia_and_eurasianism.png"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Eurasia_and_eurasianism.png/220px-Eurasia_and_eurasianism.png" width="220" height="114"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Eurasia_and_eurasianism.png" title="Enlarge"></a>
</div> Eurasian world for 
<a href="https://en.wikipedia.org/wiki/Eurasianism" title="Eurasianism">eurasianist political movement</a>
</div> 
</div> 
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:EEA_CES.PNG"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/EEA_CES.PNG/600px-EEA_CES.PNG" width="600" height="190"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:EEA_CES.PNG" title="Enlarge"></a>
</div> 
<a href="https://en.wikipedia.org/wiki/Single_market" title="Single market">Single markets</a> in European and post Soviet countries; 
<a href="https://en.wikipedia.org/wiki/European_Economic_Area" title="European Economic Area">European Economic Area</a> and 
<a href="https://en.wikipedia.org/wiki/Common_Economic_Space_(CIS)" title="Common Economic Space (CIS)">Common Economic Space</a>
</div> 
</div> 
</div> 
<p><i>Eurasia</i> is also sometimes used in <a href="https://en.wikipedia.org/wiki/Geopolitics" title="Geopolitics">geopolitics</a> to refer to organizations of or affairs concerning the <a href="https://en.wikipedia.org/wiki/Post-Soviet_states" title="Post-Soviet states">post-Soviet states</a>, in particular, <a href="https://en.wikipedia.org/wiki/Russia" title="Russia">Russia</a>, the <a href="https://en.wikipedia.org/wiki/Central_Asia" title="Central Asia">Central Asian</a> republics, and the <a href="https://en.wikipedia.org/wiki/South_Caucasus" title="South Caucasus">Transcaucasian</a> republics.<sup>[<i><a href="https://en.wikipedia.org/wiki/Wikipedia:Citation_needed" title="Wikipedia:Citation needed"><span>citation needed</span></a></i>]</sup> A prominent example of this usage is in the name of the <a href="https://en.wikipedia.org/wiki/Eurasian_Economic_Community" title="Eurasian Economic Community">Eurasian Economic Community</a>, the organization including <a href="https://en.wikipedia.org/wiki/Kazakhstan" title="Kazakhstan">Kazakhstan</a>, Russia, and some of their neighbors, and headquartered in <a href="https://en.wikipedia.org/wiki/Moscow" title="Moscow">Moscow</a>, Russia, and <a href="https://en.wikipedia.org/wiki/Astana" title="Astana">Astana</a>, the capital of Kazakhstan.</p> 
<p>The word "Eurasia" is often used in <a href="https://en.wikipedia.org/wiki/Kazakhstan" title="Kazakhstan">Kazakhstan</a> to describe its location. Numerous Kazakh institutions have the term in their names, like the <a href="https://en.wikipedia.org/wiki/Lev_Gumilev" title="Lev Gumilev">L.&nbsp;N.&nbsp;Gumilev</a> Eurasian National University (<a href="https://en.wikipedia.org/wiki/Kazakh_language" title="Kazakh language">Kazakh</a>: <span><a href="https://kk.wikipedia.org/wiki/%D0%95%D1%83%D1%80%D0%B0%D0%B7%D0%B8%D1%8F_%D2%B1%D0%BB%D1%82%D1%82%D1%8B%D2%9B_%D1%83%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%82%D0%B5%D1%82%D1%96" title="kk:Еуразия ұлттық университеті">Л. Н. Гумилёв атындағы Еуразия Ұлттық университеті</a></span>; <a href="https://en.wikipedia.org/wiki/Russian_language" title="Russian language">Russian</a>: <span><a href="https://ru.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9_%D0%9D%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9_%D1%83%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B8%D1%82%D0%B5%D1%82_%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8_%D0%9B._%D0%9D._%D0%93%D1%83%D0%BC%D0%B8%D0%BB%D1%91%D0%B2%D0%B0" title="ru:Евразийский Национальный университет имени Л. Н. Гумилёва">Евразийский Национальный университет имени Л. Н. Гумилёва</a></span>)<sup><a href="https://en.wikipedia.org/wiki#cite_note-13"><span>[</span>13<span>]</span></a></sup> (<a href="https://en.wikipedia.org/wiki/Lev_Gumilev" title="Lev Gumilev">Lev Gumilev</a>'s <a href="https://en.wikipedia.org/wiki/Eurasianists" title="Eurasianists">Eurasianism</a> ideas having been popularized in Kazakhstan by <a href="https://en.wikipedia.org/wiki/Olzhas_Suleimenov" title="Olzhas Suleimenov">Olzhas Suleimenov</a>), the Eurasian Media Forum,<sup><a href="https://en.wikipedia.org/wiki#cite_note-14"><span>[</span>14<span>]</span></a></sup> the Eurasian Cultural Foundation (<a href="https://en.wikipedia.org/wiki/Russian_language" title="Russian language">Russian</a>: <span><a href="https://ru.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9_%D1%84%D0%BE%D0%BD%D0%B4_%D0%BA%D1%83%D0%BB%D1%8C%D1%82%D1%83%D1%80%D1%8B" title="ru:Евразийский фонд культуры">Евразийский фонд культуры</a></span>), the <a href="https://en.wikipedia.org/wiki/Eurasian_Development_Bank" title="Eurasian Development Bank">Eurasian Development Bank</a> (<a href="https://en.wikipedia.org/wiki/Russian_language" title="Russian language">Russian</a>: <span><a href="https://ru.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9_%D0%B1%D0%B0%D0%BD%D0%BA_%D1%80%D0%B0%D0%B7%D0%B2%D0%B8%D1%82%D0%B8%D1%8F" title="ru:Евразийский банк развития">Евразийский банк развития</a></span>),<sup><a href="https://en.wikipedia.org/wiki#cite_note-15"><span>[</span>15<span>]</span></a></sup> and the Eurasian Bank.<sup><a href="https://en.wikipedia.org/wiki#cite_note-16"><span>[</span>16<span>]</span></a></sup> In 2007 Kazakhstan's President, <a href="https://en.wikipedia.org/wiki/Nursultan_Nazarbayev" title="Nursultan Nazarbayev">Nursultan Nazarbayev</a>, proposed building a "<a href="https://en.wikipedia.org/wiki/Eurasia_Canal" title="Eurasia Canal">Eurasia Canal</a>" to connect the <a href="https://en.wikipedia.org/wiki/Caspian_Sea" title="Caspian Sea">Caspian Sea</a> and the <a href="https://en.wikipedia.org/wiki/Black_Sea" title="Black Sea">Black Sea</a> via Russia's <a href="https://en.wikipedia.org/wiki/Kuma-Manych_Depression" title="Kuma-Manych Depression">Kuma-Manych Depression</a> in order to provide Kazakhstan and other Caspian-basin countries with a more efficient path to the ocean than the existing <a href="https://en.wikipedia.org/wiki/Volga-Don_Canal" title="Volga-Don Canal">Volga-Don Canal</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-17"><span>[</span>17<span>]</span></a></sup> This usage is comparable to how Americans use "<a href="https://en.wikipedia.org/wiki/Western_Hemisphere" title="Western Hemisphere">Western Hemisphere</a>" to describe concepts and organizations dealing with the Americas (e.g.,&nbsp;<a href="https://en.wikipedia.org/wiki/Council_on_Hemispheric_Affairs" title="Council on Hemispheric Affairs">Council on Hemispheric Affairs</a>, <a href="https://en.wikipedia.org/wiki/Western_Hemisphere_Institute_for_Security_Cooperation" title="Western Hemisphere Institute for Security Cooperation">Western Hemisphere Institute for Security Cooperation</a>).</p> 
<h2><span>See also</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=10" title="Edit section: See also">edit</a><span>]</span></span></h2> 
<div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/File:Terrestrial_globe.svg"><img alt="Portal icon" src="https://upload.wikimedia.org/wikipedia/en/thumb/6/6b/Terrestrial_globe.svg/29px-Terrestrial_globe.svg.png" width="29" height="28"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Portal:Geography" title="Portal:Geography">Geography portal</a></td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/File:Asia_(orthographic_projection).svg"><img alt="Portal icon" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Asia_%28orthographic_projection%29.svg/28px-Asia_%28orthographic_projection%29.svg.png" width="28" height="28"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Portal:Asia" title="Portal:Asia">Asia portal</a></td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/File:Europe_green_light.png"><img alt="Portal icon" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Europe_green_light.png/32px-Europe_green_light.png" width="32" height="28"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Portal:Europe" title="Portal:Europe">Europe portal</a></td> 
</tr> 
</tbody>
</table> 
</div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Asia-Europe_Foundation" title="Asia-Europe Foundation">Asia-Europe Foundation</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Asia%E2%80%93Europe_Meeting" title="Asia–Europe Meeting">Asia–Europe Meeting</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Borders_of_the_continents" title="Borders of the continents">Borders of the continents</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Eurasia_(Nineteen_Eighty-Four)#Eurasia" title="Eurasia (Nineteen Eighty-Four)">Eurasia (Nineteen Eighty-Four)</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Eurasian_(disambiguation)" title="Eurasian (disambiguation)">Eurasian (disambiguation)</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Eurasian_Economic_Community" title="Eurasian Economic Community">Eurasian Economic Community</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Eurasian_Union" title="Eurasian Union">Eurasian Union</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Intermediate_Region" title="Intermediate Region">Intermediate Region</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Laurasia" title="Laurasia">Laurasia</a>, a geological supercontinent joining Eurasia and North America.</li> 
<li><a href="https://en.wikipedia.org/wiki/List_of_Eurasian_countries_by_population" title="List of Eurasian countries by population">List of Eurasian countries by population</a></li> 
<li><a href="https://en.wikipedia.org/wiki/List_of_supercontinents" title="List of supercontinents">List of supercontinents</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Neo-Eurasianism" title="Neo-Eurasianism">Neo-Eurasianism</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Palearctic" title="Palearctic">Palearctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Shanghai_Cooperation_Organisation" title="Shanghai Cooperation Organisation">Shanghai Cooperation Organisation</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vega_expedition" title="Vega expedition">Vega expedition</a>, the first voyage to circumnavigate Eurasia</li> 
<li><a href="https://en.wikipedia.org/wiki/Eurasianism" title="Eurasianism">Eurasianism</a></li> 
</ul> 
<h2><span>References</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=11" title="Edit section: References">edit</a><span>]</span></span></h2> 
<div> 
<ol> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-1">^</a></b></span> <span><span>Lewis, Martin W.; Wigen, Kären (1997), <i>The myth of continents: a critique of metageography</i>, University of California Press, pp.&nbsp;31–32, <a href="https://en.wikipedia.org/wiki/International_Standard_Book_Number" title="International Standard Book Number">ISBN</a>&nbsp;<a href="https://en.wikipedia.org/wiki/Special:BookSources/0-520-20743-2" title="Special:BookSources/0-520-20743-2">0-520-20743-2</a></span><span><span>&nbsp;</span></span> "While a few professionals may regard Europe as a mere peninsula of Asia (or Eurasia), most geographers—and almost all nongeographers—continue to treat it not only as a full-fledged continent, but as the <i>archetypal</i> continent."</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-2">^</a></b></span> <span><span>Nield, Ted. <a href="http://www.geolsoc.org.uk/en/Education%20and%20Careers/Ask%20a%20Geologist/Continents%20Supercontinents%20and%20the%20Earths%20Crust/Continental%20Divide">"Continental Divide"</a>. <i>Geological Society</i><span>. Retrieved <span>2012-08-08</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-NatlGeo_3-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-NatlGeo_3-1"><sup><i><b>b</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-NatlGeo_3-2"><sup><i><b>c</b></i></sup></a></span> <span><span><a href="http://www.nationalgeographic.com/faq/geography.html#continents">"How many continents are there?"</a>. <a href="https://en.wikipedia.org/wiki/National_Geographic_Society" title="National Geographic Society">National Geographic Society</a><span>. Retrieved <span>2010-09-26</span></span>. <q>By convention there are seven continents: <a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a>, <a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a>, <a href="https://en.wikipedia.org/wiki/North_America" title="North America">North America</a>, <a href="https://en.wikipedia.org/wiki/South_America" title="South America">South America</a>, <a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a>, <a href="https://en.wikipedia.org/wiki/Australia" title="Australia">Australia</a>, and <a href="https://en.wikipedia.org/wiki/Antarctica" title="Antarctica">Antarctica</a>. Some geographers list only six continents, combining <a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a> and <a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a> into Eurasia. In parts of the world, students learn that there are just five continents: Eurasia, Australia, Africa, Antarctica, and the <a href="https://en.wikipedia.org/wiki/Americas" title="Americas">Americas</a>.</q></span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-4">^</a></b></span> <span><span><a href="http://geography.about.com/od/learnabouttheearth/a/What-Is-Eurasia.htm">"What is Eurasia?"</a>. geography.about.com<span>. Retrieved <span>17 December</span> 2012</span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-5">^</a></b></span> <span><span>R. W. McColl, ed. (2005, Golson Books Ltd.). <a href="http://books.google.com/books?id=DJgnebGbAB8C&amp;pg=PA215&amp;redir_esc=y#v=onepage&amp;q&amp;f=false"><i>'continents' -</i> Encyclopedia of World Geography, Volume 1</a>. p.&nbsp;215. <a href="https://en.wikipedia.org/wiki/International_Standard_Book_Number" title="International Standard Book Number">ISBN</a>&nbsp;<a href="https://en.wikipedia.org/wiki/Special:BookSources/9780816072293" title="Special:BookSources/9780816072293">9780816072293</a><span>. Retrieved <span>2012-06-26</span></span>. <q>And since Africa and Asia are connected at the Suez Peninsula, Europe, Africa, and Asia are sometimes combined as Afro-Eurasia or Eurafrasia.</q></span><span><span>&nbsp;</span></span> <span>Check date values in: <code>|date=</code> (<a href="https://en.wikipedia.org/wiki/Help:CS1_errors#bad_date" title="Help:CS1 errors">help</a>)</span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-6">^</a></b></span> <span><span>Andreen, Finn. <a href="http://commentandoutlook.blogspot.fr/2014/04/the-concept-of-eurasia-part-i.html">"The Concept of Eurasia"</a>. <i><a href="http://commentandoutlook.blogspot.fr/">http://commentandoutlook.blogspot.fr/</a></i>. Comment and Outlook<span>. Retrieved <span>6 June</span> 2014</span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-7">^</a></b></span> <span><span>Brzezinski, Zbigniew (2006). <i>The grand chessboard&nbsp;: American primacy and its geostrategic imperatives</i> ([Repr.] ed.). New York, NY: Basic Books. p.&nbsp;31. <a href="https://en.wikipedia.org/wiki/International_Standard_Book_Number" title="International Standard Book Number">ISBN</a>&nbsp;<a href="https://en.wikipedia.org/wiki/Special:BookSources/0465027261" title="Special:BookSources/0465027261">0465027261</a>.</span><span><span>&nbsp;</span></span> <span><code>|accessdate=</code> requires <code>|url=</code> (<a href="https://en.wikipedia.org/wiki/Help:CS1_errors#accessdate_missing_url" title="Help:CS1 errors">help</a>)</span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-8">^</a></b></span> <span><span>Nartov, N. A. (2004). <i>Geopolitika&nbsp;: [učebnik]</i> (3rd ed.). Moskva: Edinstvo. Part 2.4, p. 50. <a href="https://en.wikipedia.org/wiki/International_Standard_Book_Number" title="International Standard Book Number">ISBN</a>&nbsp;<a href="https://en.wikipedia.org/wiki/Special:BookSources/5238006829" title="Special:BookSources/5238006829">5238006829</a>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-9">^</a></b></span> <span><span>Andreen, Finn. <a href="http://commentandoutlook.blogspot.fr/search/label/Russia">"The Concept of Euroasia"</a>. <i><a href="http://commentandoutlook.blogspot.fr/">http://commentandoutlook.blogspot.fr/</a></i>. Commentary and Outlook<span>. Retrieved <span>6 June</span> 2014</span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-10">^</a></b></span> <span>American Heritage Dictionary</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-11">^</a></b></span> <span>"Anthropologically, historically and linguistically Eurasia is more appropriately, though vaguely subdivided into West Eurasia (often including North Africa) and East Eurasia", Anita Sengupta, <i>Heartlands of Eurasia: The Geopolitics of Political Space</i>, Lexington Books, 2009, p.25</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-12">^</a></b></span> <span><span><a href="http://geology.com/articles/supercontinent.shtml">"Pangaea Supercontinent"</a>. Geology.com<span>. Retrieved <span>19 Feb</span> 2011</span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-13">^</a></b></span> <span><span><a href="http://www.emu.kz/">"L. N. Gumilyov Eurasian National University"</a>. Emu.kz. 2010-07-29<span>. Retrieved <span>2010-08-07</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-14">^</a></b></span> <span><span><a href="http://www.eamedia.org/about">"The Eurasian Media Forum"</a>. Eamedia.org<span>. Retrieved <span>2010-08-07</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-15">^</a></b></span> <span><span><a href="http://www.eabr.org/eng">"Eurasian Development Bank"</a>. Eabr.org<span>. Retrieved <span>2010-08-07</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-16">^</a></b></span> <span><span><a href="http://www.eurasian-bank.kz/">"Eurasian Bank"</a>. Eurasian-bank.kz<span>. Retrieved <span>2010-08-07</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-17">^</a></b></span> <span><a href="http://www.timesonline.co.uk/tol/news/world/europe/article2002408.ece">Canal will link Caspian Sea to world</a> (The Times, June 29, 2007)</span></li> 
</ol> 
</div> 
<h2><span>External links</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit&amp;section=12" title="Edit section: External links">edit</a><span>]</span></span></h2> 
<table> 
<tbody>
<tr> 
<td><img alt="" src="https://upload.wikimedia.org/wikipedia/en/thumb/4/4a/Commons-logo.svg/30px-Commons-logo.svg.png" width="30" height="40"></td> 
<td>Wikimedia Commons has media related to <i><b><a href="https://commons.wikimedia.org/wiki/Special:Search/Eurasia" title="commons:Special:Search/Eurasia">Eurasia</a></b></i>.</td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Wiktionary-logo-en.svg/37px-Wiktionary-logo-en.svg.png" width="37" height="40"></td> 
<td>Look up <i><b><a href="https://en.wiktionary.org/wiki/Special:Search/eurasia" title="wiktionary:Special:Search/eurasia">eurasia</a></b></i> in Wiktionary, the free dictionary.</td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:Continents_of_the_world" title="Template:Continents of the world"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:Continents_of_the_world" title="Template talk:Continents of the world"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:Continents_of_the_world&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> 
<div>
<a href="https://en.wikipedia.org/wiki/Continent" title="Continent">Continents</a> of the 
<a href="https://en.wikipedia.org/wiki/Earth" title="Earth">world</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<td colspan="2"> 
<div> 
<table> 
<tbody>
<tr> 
<td>&nbsp;&nbsp;&nbsp;</td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Africa" title="Africa"><img alt="Africa (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Africa_%28orthographic_projection%29.svg/75px-Africa_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Antarctica" title="Antarctica"><img alt="Antarctica (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Antarctica_%28orthographic_projection%29.svg/75px-Antarctica_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Antarctica" title="Antarctica">Antarctica</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Asia" title="Asia"><img alt="Asia (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Asia_%28orthographic_projection%29.svg/75px-Asia_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Australia_(continent)" title="Australia (continent)"><img alt="Australia-New Guinea (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Australia-New_Guinea_%28orthographic_projection%29.svg/75px-Australia-New_Guinea_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Australia_(continent)" title="Australia (continent)">Australia</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Europe" title="Europe"><img alt="Europe orthographic Caucasus Urals boundary.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Europe_orthographic_Caucasus_Urals_boundary.svg/75px-Europe_orthographic_Caucasus_Urals_boundary.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/North_America" title="North America"><img alt="Location North America.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Location_North_America.svg/75px-Location_North_America.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/North_America" title="North America">North America</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/South_America" title="South America"><img alt="South America (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/South_America_%28orthographic_projection%29.svg/75px-South_America_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/South_America" title="South America">South America</a></p> 
</div> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<td colspan="2"> 
<div> 
<table> 
<tbody>
<tr> 
<td>&nbsp;&nbsp;&nbsp;</td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Afro-Eurasia" title="Afro-Eurasia"><img alt="Afro-Eurasia (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Afro-Eurasia_%28orthographic_projection%29.svg/75px-Afro-Eurasia_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Afro-Eurasia" title="Afro-Eurasia">Afro-Eurasia</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Americas" title="Americas"><img alt="Americas (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Americas_%28orthographic_projection%29.svg/75px-Americas_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Americas" title="Americas">Americas</a></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Eurasia" title="Eurasia"><img alt="Eurasia (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Eurasia_%28orthographic_projection%29.svg/75px-Eurasia_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <strong>Eurasia</strong></p> 
</div> </td> 
<td> 
<div> 
<p><a href="https://en.wikipedia.org/wiki/Oceania" title="Oceania"><img alt="Oceania (orthographic projection).svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Oceania_%28orthographic_projection%29.svg/75px-Oceania_%28orthographic_projection%29.svg.png" width="75" height="75"></a><br> <a href="https://en.wikipedia.org/wiki/Oceania" title="Oceania">Oceania</a></p> 
</div> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<td colspan="2"> 
<div> 
<table> 
<tbody>
<tr> 
<td>&nbsp;&nbsp;&nbsp;</td> 
<td> 
<div> 
<ul> 
<li><span><b><a href="https://en.wikipedia.org/wiki/Geology" title="Geology">Geological</a> <a href="https://en.wikipedia.org/wiki/Supercontinent" title="Supercontinent">supercontinents</a></b></span><br> <a href="https://en.wikipedia.org/wiki/Gondwana" title="Gondwana">Gondwana</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Laurasia" title="Laurasia">Laurasia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pangaea" title="Pangaea">Pangaea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pannotia" title="Pannotia">Pannotia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Rodinia" title="Rodinia">Rodinia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Columbia_(supercontinent)" title="Columbia (supercontinent)">Columbia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Kenorland" title="Kenorland">Kenorland</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nena_(supercontinent)" title="Nena (supercontinent)">Nena</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ur_(continent)" title="Ur (continent)">Ur</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vaalbara" title="Vaalbara">Vaalbara</a></li> 
</ul> 
</div> </td> 
<td> 
<div> 
<ul> 
<li><span><b>Historical continents</b></span><br> <a href="https://en.wikipedia.org/wiki/Arctica" title="Arctica">Arctica</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Asiamerica" title="Asiamerica">Asiamerica</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Atlantica" title="Atlantica">Atlantica</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Avalonia" title="Avalonia">Avalonia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Baltica" title="Baltica">Baltica</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Cimmeria_(continent)" title="Cimmeria (continent)">Cimmeria</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Congo_craton" title="Congo craton">Congo craton</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Euramerica" title="Euramerica">Euramerica</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Kalahari_craton" title="Kalahari craton">Kalaharia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Kazakhstania" title="Kazakhstania">Kazakhstania</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Laurentia" title="Laurentia">Laurentia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/North_China_craton" title="North China craton">North China</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Siberia_(continent)" title="Siberia (continent)">Siberia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/South_China_(continent)" title="South China (continent)">South China</a></li> 
<li><a href="https://en.wikipedia.org/wiki/East_Antarctic_craton" title="East Antarctic craton">East Antarctica</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Indian_subcontinent" title="Indian subcontinent">India</a></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<td colspan="2"> 
<div> 
<table> 
<tbody>
<tr> 
<td>&nbsp;&nbsp;&nbsp;</td> 
<td> 
<div> 
<ul> 
<li><span><b><a href="https://en.wikipedia.org/wiki/Submerged_continent" title="Submerged continent">Submerged continents</a></b></span><br> <a href="https://en.wikipedia.org/wiki/Kerguelen_Plateau" title="Kerguelen Plateau">Kerguelen Plateau</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Zealandia_(continent)" title="Zealandia (continent)">Zealandia</a></li> 
</ul> 
</div> </td> 
<td> 
<div> 
<ul> 
<li><span><b>Possible future supercontinents</b></span><br> <a href="https://en.wikipedia.org/wiki/Pangaea_Ultima" title="Pangaea Ultima">Pangaea Ultima</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Amasia_(continent)" title="Amasia (continent)">Amasia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Novopangaea" title="Novopangaea">Novopangaea</a></li> 
</ul> 
</div> </td> 
<td> 
<div> 
<ul> 
<li><span><b><a href="https://en.wikipedia.org/wiki/Mythical_continents" title="Mythical continents">Mythical and hypothesised continents</a></b></span><br> <a href="https://en.wikipedia.org/wiki/Atlantis" title="Atlantis">Atlantis</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Kumari_Kandam" title="Kumari Kandam">Kumari Kandam</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Lemuria_(continent)" title="Lemuria (continent)">Lemuria</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mu_(lost_continent)" title="Mu (lost continent)">Mu</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Terra_Australis" title="Terra Australis">Terra Australis</a></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div> 
<div> 
<ul> 
<li><i>See also <a href="https://en.wikipedia.org/wiki/Template:Regions_of_the_world" title="Template:Regions of the world">Regions of the world</a></i></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Continental_fragment" title="Continental fragment">Continental fragment</a></i></li> 
</ul> 
</div> 
<ul> 
<li><img alt="Wikipedia book" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Symbol_book_class2.svg/16px-Symbol_book_class2.svg.png" title="Wikipedia book" width="16" height="16"> <b><a href="https://en.wikipedia.org/wiki/Book:Continents" title="Book:Continents">Book</a></b></li> 
<li><img alt="Category" src="https://upload.wikimedia.org/wikipedia/en/thumb/4/48/Folder_Hexagonal_Icon.svg/16px-Folder_Hexagonal_Icon.svg.png" title="Category" width="16" height="14"> <b><a href="https://en.wikipedia.org/wiki/Category:Continents" title="Category:Continents">Category</a></b></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:Regions_of_the_world" title="Template:Regions of the world"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:Regions_of_the_world" title="Template talk:Regions of the world"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:Regions_of_the_world&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> 
<div>
<a href="https://en.wikipedia.org/wiki/United_Nations_statistical_divisions" title="United Nations statistical divisions">Regions</a> of the 
<a href="https://en.wikipedia.org/wiki/Earth" title="Earth">world</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div> 
<table> 
<tbody>
<tr> 
<td> 
<div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Africa" title="Africa"><img alt="LocationAfrica.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/LocationAfrica.png/60px-LocationAfrica.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/North_Africa" title="North Africa">Northern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Maghreb" title="Maghreb">Maghreb</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Sub-Saharan_Africa" title="Sub-Saharan Africa">Sub-Saharan</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/West_Africa" title="West Africa">Western</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/East_Africa" title="East Africa">East</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Central_Africa" title="Central Africa">Central</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Southern_Africa" title="Southern Africa">Southern</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Horn_of_Africa" title="Horn of Africa">Horn</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Islands_of_Africa" title="Islands of Africa">Islands</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/North_America" title="North America"><img alt="LocationNorthAmerica.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationNorthAmerica.png/60px-LocationNorthAmerica.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/North_America" title="North America">North<br> America</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Northern_America" title="Northern America">Northern</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Caribbean" title="Caribbean">Caribbean</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Central_America" title="Central America">Central</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Middle_America_(Americas)" title="Middle America (Americas)">Middle</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Anglo-America" title="Anglo-America">Anglo</a></li> 
<li><a href="https://en.wikipedia.org/wiki/French_America" title="French America">French</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Latin_America" title="Latin America">Latin</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Hispanic_America" title="Hispanic America">Hispanic</a></span>)</li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/South_America" title="South America"><img alt="LocationSouthAmerica.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/LocationSouthAmerica.png/60px-LocationSouthAmerica.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/South_America" title="South America">South<br> America</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Cone" title="Southern Cone">Southern</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northern_South_America" title="Northern South America">Northern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/The_Guianas" title="The Guianas">Guianan states</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Andean_states" title="Andean states">Western</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Latin_America" title="Latin America">Latin</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Hispanic_America" title="Hispanic America">Hispanic</a></span>)</li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Asia" title="Asia"><img alt="LocationAsia.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/LocationAsia.svg/60px-LocationAsia.svg.png" width="60" height="30"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Central_Asia" title="Central Asia">Central</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Far_East" title="Far East">Far East</a></li> 
<li><a href="https://en.wikipedia.org/wiki/East_Asia" title="East Asia">Eastern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Northeast_Asia" title="Northeast Asia">Northeastern</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Southeast_Asia" title="Southeast Asia">Southeastern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Mainland_Southeast_Asia" title="Mainland Southeast Asia">Mainland</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Maritime_Southeast_Asia" title="Maritime Southeast Asia">Maritime</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/North_Asia" title="North Asia">Northern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Siberia" title="Siberia">Siberia</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/South_Asia" title="South Asia">Southern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Indian_subcontinent" title="Indian subcontinent">Indian subcontinent</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Western_Asia" title="Western Asia">Western</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/South_Caucasus" title="South Caucasus">South Caucasus</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Middle_East" title="Middle East">Middle East</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Near_East" title="Near East">Near East</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Asia-Pacific" title="Asia-Pacific">Asia-Pacific</a></li> 
</ul> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
<td> 
<div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Europe" title="Europe"><img alt="LocationEurope.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationEurope.png/60px-LocationEurope.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Central_Europe" title="Central Europe">Central</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northern_Europe" title="Northern Europe">Northern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Nordic_countries" title="Nordic countries">Nordic</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Scandinavia" title="Scandinavia">Scandinavia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Scandinavian_Peninsula" title="Scandinavian Peninsula">Scandinavian Peninsula</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Baltic_countries" title="Baltic countries">Baltic</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Eastern_Europe" title="Eastern Europe">Eastern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Southeast_Europe" title="Southeast Europe">Southeastern</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Balkans" title="Balkans">Balkans</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/North_Caucasus" title="North Caucasus">North Caucasus</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Middle_East" title="Middle East">Middle East</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Europe" title="Southern Europe">Southern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Iberian_Peninsula" title="Iberian Peninsula">Iberia</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Western_Europe" title="Western Europe">Western</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Northwestern_Europe" title="Northwestern Europe">Northwestern</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/British_Isles" title="British Isles">British Isles</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Germanic-speaking_Europe" title="Germanic-speaking Europe">Germanic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Romance-speaking_Europe" title="Romance-speaking Europe">Romance</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Oceania" title="Oceania"><img alt="LocationOceania.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/LocationOceania.png/60px-LocationOceania.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Oceania" title="Oceania">Oceania</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Australasia" title="Australasia">Australasia</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Australia_(continent)" title="Australia (continent)">Australia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/New_Guinea" title="New Guinea">New Guinea</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Zealandia_(continent)" title="Zealandia (continent)">Zealandia</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Pacific_Islands" title="Pacific Islands">Pacific Islands</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Micronesia" title="Micronesia">Micronesia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Melanesia" title="Melanesia">Melanesia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Polynesia" title="Polynesia">Polynesia</a></span></li> 
</ul> </li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Polar_regions_of_Earth" title="Polar regions of Earth"><img alt="LocationPolarRegions.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/LocationPolarRegions.png/60px-LocationPolarRegions.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Polar_regions_of_Earth" title="Polar regions of Earth">Polar</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Antarctic" title="Antarctic">Antarctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic" title="Arctic">Arctic</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Ocean" title="Ocean"><img alt="LocationOceans.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/LocationOceans.png/60px-LocationOceans.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Ocean" title="Ocean">Oceans</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Sea" title="Sea">World (Sea)</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Ocean" title="Arctic Ocean">Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Atlantic_Ocean" title="Atlantic Ocean">Atlantic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Indian_Ocean" title="Indian Ocean">Indian</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pacific_Ocean" title="Pacific Ocean">Pacific</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Ocean" title="Southern Ocean">Southern</a></li> 
<li><a href="https://en.wikipedia.org/wiki/List_of_seas" title="List of seas">List of seas</a></li> 
</ul> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div> 
<ul> 
<li><img alt="Template" src="https://upload.wikimedia.org/wikipedia/en/thumb/5/5c/Symbol_template_class.svg/16px-Symbol_template_class.svg.png" title="Template" width="16" height="16"> <a href="https://en.wikipedia.org/wiki/Template:Continents_of_the_world" title="Template:Continents of the world">Continents of the world</a>&nbsp;/ <a href="https://en.wikipedia.org/wiki/Template:List_of_seas" title="Template:List of seas">List of seas</a>&nbsp;/ <a href="https://en.wikipedia.org/wiki/Template:Physical_Earth" title="Template:Physical Earth">Physical Earth</a></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> 
<p><span><span><a href="https://en.wikipedia.org/wiki/Geographic_coordinate_system" title="Geographic coordinate system">Coordinates</a>: <span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Eurasia&amp;params=50.0000_N_80.0000_E_source:wikidata"><span><span><span>50°00′00″N</span> <span>80°00′00″E</span></span></span><span>﻿ / ﻿</span><span><span>50.0000°N 80.0000°E</span><span>﻿ / <span>50.0000; 80.0000</span></span></span></a></span></span></span></p> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Help:Authority_control" title="Help:Authority control">Authority control</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Virtual_International_Authority_File" title="Virtual International Authority File">VIAF</a>: <span><a href="https://viaf.org/viaf/239429852">239429852</a></span></li> 
<li><a href="https://en.wikipedia.org/wiki/Library_of_Congress_Control_Number" title="Library of Congress Control Number">LCCN</a>: <span><a href="http://id.loc.gov/authorities/subjects/sh85045617">sh85045617</a></span></li> 
<li><a href="https://en.wikipedia.org/wiki/Integrated_Authority_File" title="Integrated Authority File">GND</a>: <span><a href="http://d-nb.info/gnd/4015685-0">4015685-0</a></span></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table>    
<img src="https://en.wikipedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1">
</div> 
<div>
 Retrieved from "
<a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;oldid=673430487">https://en.wikipedia.org/w/index.php?title=Eurasia&amp;oldid=673430487</a>" 
</div> 
<div>
<div>
<a href="https://en.wikipedia.org/wiki/Help:Category" title="Help:Category">Categories</a>: 
<ul>
<li><a href="https://en.wikipedia.org/wiki/Category:Eurasia" title="Category:Eurasia">Eurasia</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Supercontinents" title="Category:Supercontinents">Supercontinents</a></li>
</ul>
</div>
<div>
Hidden categories: 
<ul>
<li><a href="https://en.wikipedia.org/wiki/Category:CS1_errors:_dates" title="Category:CS1 errors: dates">CS1 errors: dates</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Pages_using_citations_with_accessdate_and_no_URL" title="Category:Pages using citations with accessdate and no URL">Pages using citations with accessdate and no URL</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_indefinitely_move-protected_pages" title="Category:Wikipedia indefinitely move-protected pages">Wikipedia indefinitely move-protected pages</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:All_articles_with_unsourced_statements" title="Category:All articles with unsourced statements">All articles with unsourced statements</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_with_unsourced_statements_from_June_2014" title="Category:Articles with unsourced statements from June 2014">Articles with unsourced statements from June 2014</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_with_unsourced_statements_from_December_2010" title="Category:Articles with unsourced statements from December 2010">Articles with unsourced statements from December 2010</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_containing_Kazakh-language_text" title="Category:Articles containing Kazakh-language text">Articles containing Kazakh-language text</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_containing_Russian-language_text" title="Category:Articles containing Russian-language text">Articles containing Russian-language text</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Coordinates_on_Wikidata" title="Category:Coordinates on Wikidata">Coordinates on Wikidata</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_articles_with_VIAF_identifiers" title="Category:Wikipedia articles with VIAF identifiers">Wikipedia articles with VIAF identifiers</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_articles_with_LCCN_identifiers" title="Category:Wikipedia articles with LCCN identifiers">Wikipedia articles with LCCN identifiers</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_articles_with_GND_identifiers" title="Category:Wikipedia articles with GND identifiers">Wikipedia articles with GND identifiers</a></li>
</ul>
</div>
</div> 
<div></div> 
</div> 
</div> 
<div> 
<h2>Navigation menu</h2> 
<div> 
<div> 
<h3>Personal tools</h3> 
<ul> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:UserLogin&amp;returnto=Eurasia&amp;type=signup" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:UserLogin&amp;returnto=Eurasia" title="You're encouraged to log in; however, it's not mandatory. [o]">Log in</a></li> 
</ul> 
</div> 
<div> 
<div> 
<h3>Namespaces</h3> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Eurasia" title="View the content page [c]">Article</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Talk:Eurasia" title="Discussion about the content page [t]">Talk</a></span></li> 
</ul> 
</div> 
<div> 
<h3> <span>Variants</span><a href="https://en.wikipedia.org/wiki#"></a> </h3> 
<div> 
<ul> 
</ul> 
</div> 
</div> 
</div> 
<div> 
<div> 
<h3>Views</h3> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Eurasia">Read</a></span></li> 
<li><span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=edit" title="Edit this page [e]">Edit</a></span></li> 
<li><span><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=history" title="Past versions of this page [h]">View history</a></span></li> 
</ul> 
</div> 
<div> 
<h3><span>More</span><a href="https://en.wikipedia.org/wiki#"></a></h3> 
<div> 
<ul> 
</ul> 
</div> 
</div> 
<div> 
<h3> Search </h3>  
<div>  
</div>  
</div> 
</div> 
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/Main_Page" title="Visit the main page"></a>
</div> 
<div> 
<h3>Navigation</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Main_Page" title="Visit the main page [z]">Main page</a></li>
<li><a href="https://en.wikipedia.org/wiki/Portal:Contents" title="Guides to browsing Wikipedia">Contents</a></li>
<li><a href="https://en.wikipedia.org/wiki/Portal:Featured_content" title="Featured content – the best of Wikipedia">Featured content</a></li>
<li><a href="https://en.wikipedia.org/wiki/Portal:Current_events" title="Find background information on current events">Current events</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:Random" title="Load a random article [x]">Random article</a></li>
<li><a href="https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&amp;utm_medium=sidebar&amp;utm_campaign=C13_en.wikipedia.org&amp;uselang=en" title="Support us">Donate to Wikipedia</a></li>
<li><a href="https://shop.wikimedia.org" title="Visit the Wikimedia store">Wikipedia store</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Interaction</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Help:Contents" title="Guidance on how to use and edit Wikipedia">Help</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:About" title="Find out about Wikipedia">About Wikipedia</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]">Recent changes</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact page</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Tools</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Special:WhatLinksHere/Eurasia" title="List of all English Wikipedia pages containing links to this page [j]">What links here</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:RecentChangesLinked/Eurasia" title="Recent changes in pages linked from this page [k]">Related changes</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:File_Upload_Wizard" title="Upload files [u]">Upload file</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:SpecialPages" title="A list of all special pages [q]">Special pages</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;oldid=673430487" title="Permanent link to this revision of the page">Permanent link</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;action=info" title="More information about this page">Page information</a></li>
<li><a href="https://www.wikidata.org/wiki/Q5401" title="Link to connected data repository item [g]">Wikidata item</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:CiteThisPage&amp;page=Eurasia&amp;id=673430487" title="Information on how to cite this page">Cite this page</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Print/export</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:Book&amp;bookcmd=book_creator&amp;referer=Eurasia">Create a book</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:Book&amp;bookcmd=render_article&amp;arttitle=Eurasia&amp;oldid=673430487&amp;writer=rdf2latex">Download as PDF</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Eurasia&amp;printable=yes" title="Printable version of this page [p]">Printable version</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Languages</h3> 
<div> 
<ul> 
<li><a href="https://af.wikipedia.org/wiki/Eurasi%C3%AB" title="Eurasië – Afrikaans">Afrikaans</a></li>
<li><a href="https://als.wikipedia.org/wiki/Eurasien" title="Eurasien – Alemannisch">Alemannisch</a></li>
<li><a href="https://ang.wikipedia.org/wiki/Eurasia" title="Eurasia – Old English">Ænglisc</a></li>
<li><a href="https://ar.wikipedia.org/wiki/%D8%A3%D9%88%D8%B1%D8%A7%D8%B3%D9%8A%D8%A7" title="أوراسيا – Arabic">العربية</a></li>
<li><a href="https://an.wikipedia.org/wiki/Eurasia" title="Eurasia – Aragonese">Aragonés</a></li>
<li><a href="https://frp.wikipedia.org/wiki/Erasia" title="Erasia – Arpitan">Arpetan</a></li>
<li><a href="https://as.wikipedia.org/wiki/%E0%A6%87%E0%A6%89%E0%A7%B0%E0%A7%87%E0%A6%9B%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A6%BE" title="ইউৰেছিয়া – Assamese">অসমীয়া</a></li>
<li><a href="https://ast.wikipedia.org/wiki/Eurasia" title="Eurasia – Asturian">Asturianu</a></li>
<li><a href="https://gn.wikipedia.org/wiki/Eur%C3%A1sia" title="Eurásia – Guarani">Avañe'ẽ</a></li>
<li><a href="https://av.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Евразия – Avaric">Авар</a></li>
<li><a href="https://az.wikipedia.org/wiki/Avrasiya" title="Avrasiya – Azerbaijani">Azərbaycanca</a></li>
<li><a href="https://bn.wikipedia.org/wiki/%E0%A6%87%E0%A6%89%E0%A6%B0%E0%A7%87%E0%A6%B6%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A6%BE" title="ইউরেশিয়া – Bengali">বাংলা</a></li>
<li><a href="https://be.wikipedia.org/wiki/%D0%95%D1%9E%D1%80%D0%B0%D0%B7%D1%96%D1%8F" title="Еўразія – Belarusian">Беларуская</a></li>
<li><a href="https://be-x-old.wikipedia.org/wiki/%D0%AD%D1%9E%D1%80%D0%B0%D0%B7%D1%96%D1%8F" title="Эўразія – беларуская (тарашкевіца)‎">Беларуская (тарашкевіца)‎</a></li>
<li><a href="https://bh.wikipedia.org/wiki/%E0%A4%AF%E0%A5%82%E0%A4%B0%E0%A5%87%E0%A4%B6%E0%A4%BF%E0%A4%AF%E0%A4%BE" title="यूरेशिया – भोजपुरी">भोजपुरी</a></li>
<li><a href="https://bcl.wikipedia.org/wiki/Eurasya" title="Eurasya – Bikol Central">Bikol Central</a></li>
<li><a href="https://bg.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Евразия – Bulgarian">Български</a></li>
<li><a href="https://bs.wikipedia.org/wiki/Evroazija" title="Evroazija – Bosnian">Bosanski</a></li>
<li><a href="https://br.wikipedia.org/wiki/Eurazia" title="Eurazia – Breton">Brezhoneg</a></li>
<li><a href="https://bxr.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8" title="Еврази – буряад">Буряад</a></li>
<li><a href="https://ca.wikipedia.org/wiki/Eur%C3%A0sia" title="Euràsia – Catalan">Català</a></li>
<li><a href="https://cv.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8" title="Еврази – Chuvash">Чӑвашла</a></li>
<li><a href="https://cs.wikipedia.org/wiki/Eurasie" title="Eurasie – Czech">Čeština</a></li>
<li><a href="https://cy.wikipedia.org/wiki/Ewrasia" title="Ewrasia – Welsh">Cymraeg</a></li>
<li><a href="https://da.wikipedia.org/wiki/Eurasien" title="Eurasien – Danish">Dansk</a></li>
<li><a href="https://de.wikipedia.org/wiki/Eurasien" title="Eurasien – German">Deutsch</a></li>
<li><a href="https://dsb.wikipedia.org/wiki/Eurazija" title="Eurazija – Lower Sorbian">Dolnoserbski</a></li>
<li><a href="https://et.wikipedia.org/wiki/Euraasia" title="Euraasia – Estonian">Eesti</a></li>
<li><a href="https://el.wikipedia.org/wiki/%CE%95%CF%85%CF%81%CE%B1%CF%83%CE%AF%CE%B1" title="Ευρασία – Greek">Ελληνικά</a></li>
<li><a href="https://es.wikipedia.org/wiki/Eurasia" title="Eurasia – Spanish">Español</a></li>
<li><a href="https://eo.wikipedia.org/wiki/E%C5%ADrazio" title="Eŭrazio – Esperanto">Esperanto</a></li>
<li><a href="https://eu.wikipedia.org/wiki/Eurasia" title="Eurasia – Basque">Euskara</a></li>
<li><a href="https://fa.wikipedia.org/wiki/%D8%A7%D9%88%D8%B1%D8%A7%D8%B3%DB%8C%D8%A7" title="اوراسیا – Persian">فارسی</a></li>
<li><a href="https://hif.wikipedia.org/wiki/Eurasia" title="Eurasia – Fiji Hindi">Fiji Hindi</a></li>
<li><a href="https://fo.wikipedia.org/wiki/Evrasia" title="Evrasia – Faroese">Føroyskt</a></li>
<li><a href="https://fr.wikipedia.org/wiki/Eurasie" title="Eurasie – French">Français</a></li>
<li><a href="https://fy.wikipedia.org/wiki/Jeraazje" title="Jeraazje – Western Frisian">Frysk</a></li>
<li><a href="https://fur.wikipedia.org/wiki/Eurasie" title="Eurasie – Friulian">Furlan</a></li>
<li><a href="https://ga.wikipedia.org/wiki/An_Eor%C3%A1ise" title="An Eoráise – Irish">Gaeilge</a></li>
<li><a href="https://gv.wikipedia.org/wiki/Yn_Oaraishey" title="Yn Oaraishey – Manx">Gaelg</a></li>
<li><a href="https://gag.wikipedia.org/wiki/Evraziya" title="Evraziya – Gagauz">Gagauz</a></li>
<li><a href="https://gd.wikipedia.org/wiki/Eor%C3%A0isia" title="Eoràisia – Scottish Gaelic">Gàidhlig</a></li>
<li><a href="https://gl.wikipedia.org/wiki/Eurasia" title="Eurasia – Galician">Galego</a></li>
<li><a href="https://glk.wikipedia.org/wiki/%D8%A7%DB%86%D8%B1%D8%A7%D8%B3%DB%8C%DB%8C%D8%A7" title="اۆراسییا – Gilaki">گیلکی</a></li>
<li><a href="https://gu.wikipedia.org/wiki/%E0%AA%AF%E0%AB%81%E0%AA%B0%E0%AB%87%E0%AA%B6%E0%AB%80%E0%AA%AF%E0%AA%BE" title="યુરેશીયા – Gujarati">ગુજરાતી</a></li>
<li><a href="https://ko.wikipedia.org/wiki/%EC%9C%A0%EB%9D%BC%EC%8B%9C%EC%95%84" title="유라시아 – Korean">한국어</a></li>
<li><a href="https://hy.wikipedia.org/wiki/%D4%B5%D5%BE%D6%80%D5%A1%D5%BD%D5%AB%D5%A1" title="Եվրասիա – Armenian">Հայերեն</a></li>
<li><a href="https://hi.wikipedia.org/wiki/%E0%A4%AF%E0%A5%82%E0%A4%B0%E0%A5%87%E0%A4%B6%E0%A4%BF%E0%A4%AF%E0%A4%BE" title="यूरेशिया – Hindi">हिन्दी</a></li>
<li><a href="https://hsb.wikipedia.org/wiki/Eurazija" title="Eurazija – Upper Sorbian">Hornjoserbsce</a></li>
<li><a href="https://hr.wikipedia.org/wiki/Euroazija" title="Euroazija – Croatian">Hrvatski</a></li>
<li><a href="https://io.wikipedia.org/wiki/Eurazia" title="Eurazia – Ido">Ido</a></li>
<li><a href="https://ilo.wikipedia.org/wiki/Eurasia" title="Eurasia – Iloko">Ilokano</a></li>
<li><a href="https://id.wikipedia.org/wiki/Eurasia" title="Eurasia – Indonesian">Bahasa Indonesia</a></li>
<li><a href="https://ia.wikipedia.org/wiki/Eurasia" title="Eurasia – Interlingua">Interlingua</a></li>
<li><a href="https://ie.wikipedia.org/wiki/Eurasia" title="Eurasia – Interlingue">Interlingue</a></li>
<li><a href="https://is.wikipedia.org/wiki/Evras%C3%ADa" title="Evrasía – Icelandic">Íslenska</a></li>
<li><a href="https://it.wikipedia.org/wiki/Eurasia" title="Eurasia – Italian">Italiano</a></li>
<li><a href="https://he.wikipedia.org/wiki/%D7%90%D7%99%D7%A8%D7%95%D7%90%D7%A1%D7%99%D7%94" title="אירואסיה – Hebrew">עברית</a></li>
<li><a href="https://jv.wikipedia.org/wiki/Eurasia" title="Eurasia – Javanese">Basa Jawa</a></li>
<li><a href="https://kl.wikipedia.org/wiki/Eurasia" title="Eurasia – Kalaallisut">Kalaallisut</a></li>
<li><a href="https://ka.wikipedia.org/wiki/%E1%83%94%E1%83%95%E1%83%A0%E1%83%90%E1%83%96%E1%83%98%E1%83%90" title="ევრაზია – Georgian">ქართული</a></li>
<li><a href="https://kk.wikipedia.org/wiki/%D0%95%D1%83%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Еуразия – Kazakh">Қазақша</a></li>
<li><a href="https://ht.wikipedia.org/wiki/Ewazi" title="Ewazi – Haitian">Kreyòl ayisyen</a></li>
<li><a href="https://ku.wikipedia.org/wiki/Ewrasya" title="Ewrasya – Kurdish">Kurdî</a></li>
<li><a href="https://ky.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Евразия – Kyrgyz">Кыргызча</a></li>
<li><a href="https://mrj.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8" title="Еврази – Western Mari">Кырык мары</a></li>
<li><a href="https://lad.wikipedia.org/wiki/Evrasia" title="Evrasia – Ladino">Ladino</a></li>
<li><a href="https://ltg.wikipedia.org/wiki/Eurazeja" title="Eurazeja – Latgalian">Latgaļu</a></li>
<li><a href="https://la.wikipedia.org/wiki/Eurasia" title="Eurasia – Latin">Latina</a></li>
<li><a href="https://lv.wikipedia.org/wiki/Eir%C4%81zija" title="Eirāzija – Latvian">Latviešu</a></li>
<li><a href="https://lb.wikipedia.org/wiki/Eurasien" title="Eurasien – Luxembourgish">Lëtzebuergesch</a></li>
<li><a href="https://lt.wikipedia.org/wiki/Eurazija" title="Eurazija – Lithuanian">Lietuvių</a></li>
<li><a href="https://lmo.wikipedia.org/wiki/Eurasia" title="Eurasia – Lombard">Lumbaart</a></li>
<li><a href="https://hu.wikipedia.org/wiki/Eur%C3%A1zsia" title="Eurázsia – Hungarian">Magyar</a></li>
<li><a href="https://mk.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%BE%D0%B0%D0%B7%D0%B8%D1%98%D0%B0" title="Евроазија – Macedonian">Македонски</a></li>
<li><a href="https://ml.wikipedia.org/wiki/%E0%B4%AF%E0%B5%81%E0%B4%B1%E0%B5%87%E0%B4%B7%E0%B5%8D%E0%B4%AF" title="യുറേഷ്യ – Malayalam">മലയാളം</a></li>
<li><a href="https://mr.wikipedia.org/wiki/%E0%A4%AF%E0%A5%81%E0%A4%B0%E0%A5%87%E0%A4%B6%E0%A4%BF%E0%A4%AF%E0%A4%BE" title="युरेशिया – Marathi">मराठी</a></li>
<li><a href="https://xmf.wikipedia.org/wiki/%E1%83%94%E1%83%95%E1%83%A0%E1%83%90%E1%83%96%E1%83%98%E1%83%90" title="ევრაზია – Mingrelian">მარგალური</a></li>
<li><a href="https://ms.wikipedia.org/wiki/Eurasia" title="Eurasia – Malay">Bahasa Melayu</a></li>
<li><a href="https://mo.wikipedia.org/wiki/%D0%95%D1%83%D1%80%D0%B0%D1%81%D0%B8%D1%8F" title="Еурасия – молдовеняскэ">Молдовеняскэ</a></li>
<li><a href="https://mn.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8" title="Еврази – Mongolian">Монгол</a></li>
<li><a href="https://my.wikipedia.org/wiki/%E1%80%9A%E1%80%B0%E1%80%9B%E1%80%B1%E1%80%B8%E1%80%9B%E1%80%BE%E1%80%AC%E1%80%B8" title="ယူရေးရှား – Burmese">မြန်မာဘာသာ</a></li>
<li><a href="https://nl.wikipedia.org/wiki/Eurazi%C3%AB" title="Eurazië – Dutch">Nederlands</a></li>
<li><a href="https://new.wikipedia.org/wiki/%E0%A4%AF%E0%A5%81%E0%A4%B0%E0%A5%87%E0%A4%B8%E0%A4%BF%E0%A4%AF%E0%A4%BE" title="युरेसिया – Newari">नेपाल भाषा</a></li>
<li><a href="https://ja.wikipedia.org/wiki/%E3%83%A6%E3%83%BC%E3%83%A9%E3%82%B7%E3%82%A2%E5%A4%A7%E9%99%B8" title="ユーラシア大陸 – Japanese">日本語</a></li>
<li><a href="https://ce.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8" title="Еврази – Chechen">Нохчийн</a></li>
<li><a href="https://frr.wikipedia.org/wiki/Euraasien" title="Euraasien – Northern Frisian">Nordfriisk</a></li>
<li><a href="https://no.wikipedia.org/wiki/Eurasia" title="Eurasia – Norwegian">Norsk bokmål</a></li>
<li><a href="https://nn.wikipedia.org/wiki/Eurasia" title="Eurasia – Norwegian Nynorsk">Norsk nynorsk</a></li>
<li><a href="https://oc.wikipedia.org/wiki/Eurasia" title="Eurasia – Occitan">Occitan</a></li>
<li><a href="https://mhr.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D0%B9" title="Евразий – Eastern Mari">Олык марий</a></li>
<li><a href="https://uz.wikipedia.org/wiki/Yevrosiyo" title="Yevrosiyo – Uzbek">Oʻzbekcha/ўзбекча</a></li>
<li><a href="https://pa.wikipedia.org/wiki/%E0%A8%AF%E0%A9%82%E0%A8%B0%E0%A9%87%E0%A8%B8%E0%A8%BC%E0%A9%80%E0%A8%86" title="ਯੂਰੇਸ਼ੀਆ – Punjabi">ਪੰਜਾਬੀ</a></li>
<li><a href="https://pnb.wikipedia.org/wiki/%DB%8C%D9%88%D8%B1%DB%8C%D8%B4%DB%8C%D8%A7" title="یوریشیا – Western Punjabi">پنجابی</a></li>
<li><a href="https://ps.wikipedia.org/wiki/%D8%A7%D9%88%D8%B1%D8%A7%D8%B3%D9%8A%D8%A7" title="اوراسيا – Pashto">پښتو</a></li>
<li><a href="https://koi.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Евразия – Komi-Permyak">Перем Коми</a></li>
<li><a href="https://pms.wikipedia.org/wiki/Eurasia" title="Eurasia – Piedmontese">Piemontèis</a></li>
<li><a href="https://nds.wikipedia.org/wiki/Eurasien" title="Eurasien – Low German">Plattdüütsch</a></li>
<li><a href="https://pl.wikipedia.org/wiki/Eurazja" title="Eurazja – Polish">Polski</a></li>
<li><a href="https://pt.wikipedia.org/wiki/Eur%C3%A1sia" title="Eurásia – Portuguese">Português</a></li>
<li><a href="https://kaa.wikipedia.org/wiki/Evraziya" title="Evraziya – Kara-Kalpak">Qaraqalpaqsha</a></li>
<li><a href="https://ro.wikipedia.org/wiki/Eurasia" title="Eurasia – Romanian">Română</a></li>
<li><a href="https://rmy.wikipedia.org/wiki/Eurasiya" title="Eurasiya – Romani">Romani</a></li>
<li><a href="https://qu.wikipedia.org/wiki/Iwrasya" title="Iwrasya – Quechua">Runa Simi</a></li>
<li><a href="https://ru.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Евразия – Russian">Русский</a></li>
<li><a href="https://sco.wikipedia.org/wiki/Eurasie" title="Eurasie – Scots">Scots</a></li>
<li><a href="https://stq.wikipedia.org/wiki/Eurasien" title="Eurasien – Saterland Frisian">Seeltersk</a></li>
<li><a href="https://simple.wikipedia.org/wiki/Eurasia" title="Eurasia – Simple English">Simple English</a></li>
<li><a href="https://sk.wikipedia.org/wiki/Eur%C3%A1zia" title="Eurázia – Slovak">Slovenčina</a></li>
<li><a href="https://sl.wikipedia.org/wiki/Evrazija" title="Evrazija – Slovenian">Slovenščina</a></li>
<li><a href="https://szl.wikipedia.org/wiki/Ojrazyjo" title="Ojrazyjo – Silesian">Ślůnski</a></li>
<li><a href="https://ckb.wikipedia.org/wiki/%D8%A6%DB%95%D9%88%D8%B1%D8%A7%D8%B3%DB%8C%D8%A7" title="ئەوراسیا – Central Kurdish">کوردیی ناوەندی</a></li>
<li><a href="https://sr.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%BE%D0%B0%D0%B7%D0%B8%D1%98%D0%B0" title="Евроазија – Serbian">Српски / srpski</a></li>
<li><a href="https://sh.wikipedia.org/wiki/Euroazija" title="Euroazija – Serbo-Croatian">Srpskohrvatski / српскохрватски</a></li>
<li><a href="https://su.wikipedia.org/wiki/%C3%89rasia" title="Érasia – Sundanese">Basa Sunda</a></li>
<li><a href="https://fi.wikipedia.org/wiki/Euraasia" title="Euraasia – Finnish">Suomi</a></li>
<li><a href="https://sv.wikipedia.org/wiki/Eurasien" title="Eurasien – Swedish">Svenska</a></li>
<li><a href="https://ta.wikipedia.org/wiki/%E0%AE%90%E0%AE%B0%E0%AF%8B%E0%AE%B5%E0%AE%BE%E0%AE%9A%E0%AE%BF%E0%AE%AF%E0%AE%BE" title="ஐரோவாசியா – Tamil">தமிழ்</a></li>
<li><a href="https://tt.wikipedia.org/wiki/%D0%90%D1%83%D1%80%D0%B0%D0%B7%D0%B8%D1%8F" title="Ауразия – Tatar">Татарча/tatarça</a></li>
<li><a href="https://te.wikipedia.org/wiki/%E0%B0%AF%E0%B1%81%E0%B0%B0%E0%B1%87%E0%B0%B7%E0%B0%BF%E0%B0%AF%E0%B0%BE" title="యురేషియా – Telugu">తెలుగు</a></li>
<li><a href="https://th.wikipedia.org/wiki/%E0%B8%97%E0%B8%A7%E0%B8%B5%E0%B8%9B%E0%B8%A2%E0%B8%B9%E0%B9%80%E0%B8%A3%E0%B9%80%E0%B8%8A%E0%B8%B5%E0%B8%A2" title="ทวีปยูเรเชีย – Thai">ไทย</a></li>
<li><a href="https://tg.wikipedia.org/wiki/%D0%95%D0%B2%D1%80%D0%BE%D1%81%D0%B8%D1%91" title="Евросиё – Tajik">Тоҷикӣ</a></li>
<li><a href="https://tr.wikipedia.org/wiki/Avrasya" title="Avrasya – Turkish">Türkçe</a></li>
<li><a href="https://uk.wikipedia.org/wiki/%D0%84%D0%B2%D1%80%D0%B0%D0%B7%D1%96%D1%8F" title="Євразія – Ukrainian">Українська</a></li>
<li><a href="https://ur.wikipedia.org/wiki/%DB%8C%D9%88%D8%B1%DB%8C%D8%B4%DB%8C%D8%A7" title="یوریشیا – Urdu">اردو</a></li>
<li><a href="https://vec.wikipedia.org/wiki/Eoraxia" title="Eoraxia – Venetian">Vèneto</a></li>
<li><a href="https://vep.wikipedia.org/wiki/Evrazii" title="Evrazii – Veps">Vepsän kel’</a></li>
<li><a href="https://vi.wikipedia.org/wiki/L%E1%BB%A5c_%C4%91%E1%BB%8Ba_%C3%81-%C3%82u" title="Lục địa Á-Âu – Vietnamese">Tiếng Việt</a></li>
<li><a href="https://fiu-vro.wikipedia.org/wiki/%C3%95uraasia" title="Õuraasia – Võro">Võro</a></li>
<li><a href="https://war.wikipedia.org/wiki/Eurasia" title="Eurasia – Waray">Winaray</a></li>
<li><a href="https://wo.wikipedia.org/wiki/Tugalasi" title="Tugalasi – Wolof">Wolof</a></li>
<li><a href="https://yo.wikipedia.org/wiki/%E1%BA%B8ur%C3%A1s%C3%AD%C3%A0" title="Ẹurásíà – Yoruba">Yorùbá</a></li>
<li><a href="https://zh-yue.wikipedia.org/wiki/%E6%AD%90%E4%BA%9E%E5%A4%A7%E9%99%B8" title="歐亞大陸 – Cantonese">粵語</a></li>
<li><a href="https://diq.wikipedia.org/wiki/Ewrasya" title="Ewrasya – Zazaki">Zazaki</a></li>
<li><a href="https://bat-smg.wikipedia.org/wiki/Euraz%C4%97j%C4%97" title="Eurazėjė – Samogitian">Žemaitėška</a></li>
<li><a href="https://zh.wikipedia.org/wiki/%E6%AD%90%E4%BA%9E%E5%A4%A7%E9%99%B8" title="歐亞大陸 – Chinese">中文</a></li>
<li><a href="https://en.wikipedia.org/wiki#"></a></li> 
</ul> 
<div>
<span><a href="https://www.wikidata.org/wiki/Q5401#sitelinks-wikipedia" title="Edit interlanguage links">Edit links</a></span>
</div> 
</div> 
</div> 
</div> 
</div> 
<div> 
<ul> 
<li> This page was last modified on 28 July 2015, at 07:10.</li> 
<li>Text is available under the <a href="https://en.wikipedia.org/wiki/Wikipedia:Text_of_Creative_Commons_Attribution-ShareAlike_3.0_Unported_License">Creative Commons Attribution-ShareAlike License</a><a href="https://creativecommons.org/licenses/by-sa/3.0/"></a>; additional terms may apply. By using this site, you agree to the <a href="https://wikimediafoundation.org/wiki/Terms_of_Use">Terms of Use</a> and <a href="https://wikimediafoundation.org/wiki/Privacy_policy">Privacy Policy</a>. Wikipedia® is a registered trademark of the <a href="https://www.wikimediafoundation.org/">Wikimedia Foundation, Inc.</a>, a non-profit organization.</li> 
</ul> 
<ul> 
<li><a href="https://wikimediafoundation.org/wiki/Privacy_policy" title="wikimedia:Privacy policy">Privacy policy</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:About" title="Wikipedia:About">About Wikipedia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:General_disclaimer" title="Wikipedia:General disclaimer">Disclaimers</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact Wikipedia</a></li> 
<li><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li> 
<li><a href="https://en.m.wikipedia.org/w/index.php?title=Eurasia&amp;mobileaction=toggle_view_mobile">Mobile view</a></li> 
</ul> 
<ul> 
<li> <a href="https://wikimediafoundation.org/"><img src="https://en.wikipedia.org/static/images/wikimedia-button.png" width="88" height="31" alt="Wikimedia Foundation"></a> </li> 
<li> <a href="https://www.mediawiki.org/"><img src="https://en.wikipedia.org/static/1.26wmf18/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" width="88" height="31"></a> </li> 
</ul> 
<div></div> 
</div>