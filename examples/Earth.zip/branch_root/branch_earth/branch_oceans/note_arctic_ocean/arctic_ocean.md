Arctic Ocean - Wikipedia, the free encyclopedia                        
<div></div> 
<div></div> 
<div> 
<a></a> 
<div></div> 
<div> 
</div> 
<h1>Arctic Ocean</h1> 
<div> 
<div>
From Wikipedia, the free encyclopedia
</div> 
<div></div> 
<div>
 Jump to: 
<a href="https://en.wikipedia.org/wiki#mw-head">navigation</a>, 
<a href="https://en.wikipedia.org/wiki#p-search">search</a> 
</div> 
<div>
<div>
"Arctic Sea" redirects here. For the cargo ship, see 
<a href="https://en.wikipedia.org/wiki/MV_Arctic_Sea" title="MV Arctic Sea">MV Arctic Sea</a>.
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:IBCAO_betamap.jpg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/IBCAO_betamap.jpg/400px-IBCAO_betamap.jpg" width="400" height="456"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:IBCAO_betamap.jpg" title="Enlarge"></a>
</div> A 
<a href="https://en.wikipedia.org/wiki/Bathymetry" title="Bathymetry">bathymetric</a>/
<a href="https://en.wikipedia.org/wiki/Topography" title="Topography">topographic</a> of the Arctic Ocean and the surrounding lands.
</div> 
</div> 
</div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/File:Oceanus.png" title="View of the Earth where all five oceans visible"><img alt="View of the Earth where all five oceans visible" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Oceanus.png/120px-Oceanus.png" width="120" height="120"></a></td> 
</tr> 
<tr> 
<th>Earth's oceans</th> 
</tr> 
<tr> 
<td> 
<ul> 
<li><strong>Arctic</strong></li> 
<li><a href="https://en.wikipedia.org/wiki/Atlantic_Ocean" title="Atlantic Ocean">Atlantic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Indian_Ocean" title="Indian Ocean">Indian</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pacific_Ocean" title="Pacific Ocean">Pacific</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Ocean" title="Southern Ocean">Southern</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td>  <a href="https://en.wikipedia.org/wiki/Sea" title="Sea">World Ocean</a> </td> 
</tr> 
<tr> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:Five_oceans" title="Template:Five oceans"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:Five_oceans" title="Template talk:Five oceans"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:Five_oceans&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> 
<p>The <b>Arctic Ocean</b> (also known as the <b>Northern Ocean</b>), located in the <a href="https://en.wikipedia.org/wiki/Northern_Hemisphere" title="Northern Hemisphere">Northern Hemisphere</a> and mostly in the <a href="https://en.wikipedia.org/wiki/Arctic" title="Arctic">Arctic</a> <a href="https://en.wikipedia.org/wiki/North_Pole" title="North Pole">north polar</a> region, is the smallest and shallowest of the world's five major <a href="https://en.wikipedia.org/wiki/Ocean" title="Ocean">oceanic</a> divisions.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Pidwirny-1"><span>[</span>1<span>]</span></a></sup> The <a href="https://en.wikipedia.org/wiki/International_Hydrographic_Organization" title="International Hydrographic Organization">International Hydrographic Organization</a> (IHO) recognizes it as an ocean, although some <a href="https://en.wikipedia.org/wiki/Oceanography" title="Oceanography">oceanographers</a> call it the <b>Arctic Mediterranean Sea</b> or simply the <b>Arctic Sea</b>, classifying it a <a href="https://en.wikipedia.org/wiki/Mediterranean_sea_(oceanography)" title="Mediterranean sea (oceanography)">mediterranean sea</a> or an <a href="https://en.wikipedia.org/wiki/Estuary" title="Estuary">estuary</a> of the <a href="https://en.wikipedia.org/wiki/Atlantic_Ocean" title="Atlantic Ocean">Atlantic Ocean</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-2"><span>[</span>2<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-3"><span>[</span>3<span>]</span></a></sup> Alternatively, the Arctic Ocean can be seen as the northernmost part of the all-encompassing <a href="https://en.wikipedia.org/wiki/World_Ocean" title="World Ocean">World Ocean</a>.</p> 
<p>Almost completely surrounded by <a href="https://en.wikipedia.org/wiki/Eurasia" title="Eurasia">Eurasia</a> and <a href="https://en.wikipedia.org/wiki/North_America" title="North America">North America</a>, the Arctic Ocean is partly covered by <a href="https://en.wikipedia.org/wiki/Sea_ice" title="Sea ice">sea ice</a> throughout the year<sup><a href="https://en.wikipedia.org/wiki#cite_note-4"><span>[</span>4<span>]</span></a></sup> (and almost completely in <a href="https://en.wikipedia.org/wiki/Winter" title="Winter">winter</a>). The Arctic Ocean's <a href="https://en.wikipedia.org/wiki/Sea_surface_temperature" title="Sea surface temperature">surface temperature</a> and <a href="https://en.wikipedia.org/wiki/Salinity" title="Salinity">salinity</a> vary seasonally as the <a href="https://en.wikipedia.org/wiki/Polar_ice_packs" title="Polar ice packs">ice cover</a> melts and freezes;<sup><a href="https://en.wikipedia.org/wiki#cite_note-5"><span>[</span>5<span>]</span></a></sup> its salinity is the lowest on average of the five major oceans, due to low <a href="https://en.wikipedia.org/wiki/Evaporation" title="Evaporation">evaporation</a>, heavy <a href="https://en.wikipedia.org/wiki/Fresh_water" title="Fresh water">fresh water</a> inflow from rivers and streams, and limited connection and outflow to surrounding oceanic waters with higher salinities. The summer shrinking of the ice has been quoted at 50%.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Pidwirny-1"><span>[</span>1<span>]</span></a></sup> The US <a href="https://en.wikipedia.org/wiki/National_Snow_and_Ice_Data_Center" title="National Snow and Ice Data Center">National Snow and Ice Data Center</a> (NSIDC) uses satellite data to provide a daily record of Arctic sea ice cover and the rate of melting compared to an average period and specific past years.</p> 
<p></p> 
<div> 
<div> 
<h2>Contents</h2> 
</div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki#History"><span>1</span> <span>History</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Geography"><span>2</span> <span>Geography</span></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki#Extent_and_major_ports"><span>2.1</span> <span>Extent and major ports</span></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki#United_States"><span>2.1.1</span> <span>United States</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Canada"><span>2.1.2</span> <span>Canada</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Greenland"><span>2.1.3</span> <span>Greenland</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Norway"><span>2.1.4</span> <span>Norway</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Russia"><span>2.1.5</span> <span>Russia</span></a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki#Arctic_shelves"><span>2.2</span> <span>Arctic shelves</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Underwater_features"><span>2.3</span> <span>Underwater features</span></a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki#Oceanography"><span>3</span> <span>Oceanography</span></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki#Water_flow"><span>3.1</span> <span>Water flow</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Sea_ice"><span>3.2</span> <span>Sea ice</span></a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki#Climate"><span>4</span> <span>Climate</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Animal_and_plant_life"><span>5</span> <span>Animal and plant life</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Natural_resources"><span>6</span> <span>Natural resources</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Environmental_concerns"><span>7</span> <span>Environmental concerns</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#See_also"><span>8</span> <span>See also</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#References"><span>9</span> <span>References</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#Further_reading"><span>10</span> <span>Further reading</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki#External_links"><span>11</span> <span>External links</span></a></li> 
</ul> 
</div> 
<p></p> 
<h2><span>History</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=1" title="Edit section: History">edit</a><span>]</span></span></h2> 
<p>For much of <a href="https://en.wikipedia.org/wiki/History_of_Europe" title="History of Europe">European history</a>, the north <a href="https://en.wikipedia.org/wiki/Polar_region" title="Polar region">polar regions</a> remained largely unexplored and their geography conjectural. <a href="https://en.wikipedia.org/wiki/Pytheas" title="Pytheas">Pytheas</a> of <a href="https://en.wikipedia.org/wiki/Marseille" title="Marseille">Massilia</a> recorded an account of a journey northward in 325 BC, to a land he called "<a href="https://en.wikipedia.org/wiki/Thule" title="Thule">Eschate Thule</a>," where the Sun only set for three hours each day and the water was replaced by a congealed substance "on which one can neither walk nor sail." He was probably describing loose sea ice known today as "<a href="https://en.wikipedia.org/wiki/Iceberg" title="Iceberg">growlers</a>" or "bergy bits;" his "Thule" was probably <a href="https://en.wikipedia.org/wiki/Norway" title="Norway">Norway</a>, though the <a href="https://en.wikipedia.org/wiki/Faroe_Islands" title="Faroe Islands">Faroe Islands</a> or <a href="https://en.wikipedia.org/wiki/Shetland" title="Shetland">Shetland</a> have also been suggested.<sup><a href="https://en.wikipedia.org/wiki#cite_note-6"><span>[</span>6<span>]</span></a></sup></p> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Map_of_the_Arctic,_1780s_-_B%26W.jpeg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Map_of_the_Arctic%2C_1780s_-_B%26W.jpeg/220px-Map_of_the_Arctic%2C_1780s_-_B%26W.jpeg" width="220" height="189"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Map_of_the_Arctic,_1780s_-_B%26W.jpeg" title="Enlarge"></a>
</div> 
<a href="https://en.wikipedia.org/wiki/Emanuel_Bowen" title="Emanuel Bowen">Emanuel Bowen</a>'s 1780s map of the Arctic features a "Northern Ocean".
</div> 
</div> 
</div> 
<p>Early <a href="https://en.wikipedia.org/wiki/Cartography" title="Cartography">cartographers</a> were unsure whether to draw the region around the North Pole as land (as in <a href="https://en.wikipedia.org/wiki/Johannes_Ruysch" title="Johannes Ruysch">Johannes Ruysch</a>'s <a href="https://en.wikipedia.org/wiki/File:Ruysch_map.jpg" title="File:Ruysch map.jpg">map of 1507</a>, or <a href="https://en.wikipedia.org/wiki/Gerardus_Mercator" title="Gerardus Mercator">Gerardus Mercator</a>'s <a href="https://en.wikipedia.org/wiki/File:Mercator_Septentrionalium_Terrarum_descriptio.jpg" title="File:Mercator Septentrionalium Terrarum descriptio.jpg">map of 1595</a>) or water (as with <a href="https://en.wikipedia.org/wiki/Martin_Waldseem%C3%BCller" title="Martin Waldseemüller">Martin Waldseemüller</a>'s <a href="https://en.wikipedia.org/wiki/File:UniversalisCosmographia.jpg" title="File:UniversalisCosmographia.jpg">world map of 1507</a>). The fervent desire of European merchants for a northern passage, the <a href="https://en.wikipedia.org/wiki/Northern_Sea_Route" title="Northern Sea Route">Northern Sea Route</a> or the <a href="https://en.wikipedia.org/wiki/Northwest_Passage" title="Northwest Passage">Northwest Passage</a>, to "<a href="https://en.wikipedia.org/wiki/Cathay" title="Cathay">Cathay</a>" (<a href="https://en.wikipedia.org/wiki/China" title="China">China</a>) caused water to win out, and by 1723 mapmakers such as <a href="https://en.wikipedia.org/wiki/Johann_Homann" title="Johann Homann">Johann Homann</a> featured an extensive "Oceanus Septentrionalis" at the northern edge of their charts.</p> 
<p>The few expeditions to penetrate much beyond the <a href="https://en.wikipedia.org/wiki/Arctic_Circle" title="Arctic Circle">Arctic Circle</a> in this era added only small islands, such as <a href="https://en.wikipedia.org/wiki/Novaya_Zemlya" title="Novaya Zemlya">Novaya Zemlya</a> (11th century) and <a href="https://en.wikipedia.org/wiki/Spitsbergen" title="Spitsbergen">Spitsbergen</a> (1596), though since these were often surrounded by <a href="https://en.wikipedia.org/wiki/Drift_ice" title="Drift ice">pack-ice</a>, their northern limits were not so clear. The makers of <a href="https://en.wikipedia.org/wiki/Nautical_chart" title="Nautical chart">navigational charts</a>, more conservative than some of the more fanciful cartographers, tended to leave the region blank, with only fragments of known coastline sketched in.</p> 
<p>This lack of knowledge of what lay north of the shifting barrier of ice gave rise to a number of conjectures. In England and other European nations, the <a href="https://en.wikipedia.org/wiki/Mythology" title="Mythology">myth</a> of an "<a href="https://en.wikipedia.org/wiki/Open_Polar_Sea" title="Open Polar Sea">Open Polar Sea</a>" was persistent. <a href="https://en.wikipedia.org/wiki/Sir_John_Barrow,_1st_Baronet" title="Sir John Barrow, 1st Baronet">John Barrow</a>, longtime Second Secretary of the British <a href="https://en.wikipedia.org/wiki/Admiralty" title="Admiralty">Admiralty</a>, <a href="https://en.wikipedia.org/wiki/Arctic_exploration" title="Arctic exploration">promoted exploration</a> of the region from 1818 to 1845 in search of this.</p> 
<p>In the <a href="https://en.wikipedia.org/wiki/United_States" title="United States">United States</a> in the 1850s and 1860s, the explorers <a href="https://en.wikipedia.org/wiki/Elisha_Kane" title="Elisha Kane">Elisha Kane</a> and <a href="https://en.wikipedia.org/wiki/Isaac_Israel_Hayes" title="Isaac Israel Hayes">Isaac Israel Hayes</a> both claimed to have seen part of this elusive body of water. Even quite late in the century, the eminent authority <a href="https://en.wikipedia.org/wiki/Matthew_Fontaine_Maury" title="Matthew Fontaine Maury">Matthew Fontaine Maury</a> included a description of the Open Polar Sea in his textbook <i>The Physical Geography of the Sea</i> (1883). Nevertheless, as all the explorers who travelled closer and closer to the pole reported, the <a href="https://en.wikipedia.org/wiki/Polar_ice_cap" title="Polar ice cap">polar ice cap</a> is quite thick, and persists year-round.</p> 
<p><a href="https://en.wikipedia.org/wiki/Fridtjof_Nansen" title="Fridtjof Nansen">Fridtjof Nansen</a> was the first to make a <a href="https://en.wikipedia.org/wiki/Seamanship" title="Seamanship">nautical</a> crossing of the Arctic Ocean, in 1896. The first surface crossing of the ocean was led by <a href="https://en.wikipedia.org/wiki/Wally_Herbert" title="Wally Herbert">Wally Herbert</a> in 1969, in a <a href="https://en.wikipedia.org/wiki/Dog_sled" title="Dog sled">dog sled</a> expedition from <a href="https://en.wikipedia.org/wiki/Alaska" title="Alaska">Alaska</a> to <a href="https://en.wikipedia.org/wiki/Svalbard" title="Svalbard">Svalbard</a>, with air support.<sup><a href="https://en.wikipedia.org/wiki#cite_note-7"><span>[</span>7<span>]</span></a></sup> The first nautical transit of the north pole was made in 1958 by the submarine <a href="https://en.wikipedia.org/wiki/USS_Nautilus_(SSN-571)" title="USS Nautilus (SSN-571)">USS Nautilus</a>, and the first surface nautical transit occurred in 1977 by the <a href="https://en.wikipedia.org/wiki/Icebreaker" title="Icebreaker">icebreaker</a> <a href="https://en.wikipedia.org/wiki/Arktika_(icebreaker)" title="Arktika (icebreaker)">NS Arktika</a>.</p> 
<p>Since 1937, Soviet and Russian manned <a href="https://en.wikipedia.org/wiki/Drifting_ice_station" title="Drifting ice station">drifting ice stations</a> have extensively monitored the Arctic Ocean. Scientific settlements were established on the drift ice and carried thousands of kilometres by ice floes.<sup><a href="https://en.wikipedia.org/wiki#cite_note-8"><span>[</span>8<span>]</span></a></sup></p> 
<p>In World War II the European region of the Arctic Ocean was heavily contested&nbsp;: the Allied commitment to resupply the Soviet Union via its northern ports was opposed by German naval and air forces.</p> 
<h2><span>Geography</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=2" title="Edit section: Geography">edit</a><span>]</span></span></h2> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Arctic.svg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Arctic.svg/400px-Arctic.svg.png" width="400" height="501"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Arctic.svg" title="Enlarge"></a>
</div> The 
<a href="https://en.wikipedia.org/wiki/Arctic" title="Arctic">Arctic region</a>; of note, the region's southerly border on this map is depicted by a red 
<a href="https://en.wikipedia.org/wiki/Contour_line#Temperature_and_related_subjects" title="Contour line">isotherm</a>, with all territory to the north having an average temperature of less than 10&nbsp;°C (50&nbsp;°F) in July.
</div> 
</div> 
</div> 
<p>The Arctic Ocean occupies a roughly circular basin and covers an area of about 14,056,000&nbsp;km<sup>2</sup> (5,427,000&nbsp;sq&nbsp;mi), almost the size of <a href="https://en.wikipedia.org/wiki/Russia" title="Russia">Russia</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-nyt-9"><span>[</span>9<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-Oceans_of_the_World-10"><span>[</span>10<span>]</span></a></sup> The coastline is 45,390&nbsp;km (28,200&nbsp;mi) long.<sup><a href="https://en.wikipedia.org/wiki#cite_note-nyt-9"><span>[</span>9<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-Arctic_Ocean_Fast_Facts-11"><span>[</span>11<span>]</span></a></sup> It is surrounded by the land masses of Eurasia, North America, <a href="https://en.wikipedia.org/wiki/Greenland" title="Greenland">Greenland</a>, and by <a href="https://en.wikipedia.org/wiki/Arctic_Islands_(disambiguation)" title="Arctic Islands (disambiguation)">several islands</a>.</p> 
<p>It is generally taken to include <a href="https://en.wikipedia.org/wiki/Baffin_Bay" title="Baffin Bay">Baffin Bay</a>, <a href="https://en.wikipedia.org/wiki/Barents_Sea" title="Barents Sea">Barents Sea</a>, <a href="https://en.wikipedia.org/wiki/Beaufort_Sea" title="Beaufort Sea">Beaufort Sea</a>, <a href="https://en.wikipedia.org/wiki/Chukchi_Sea" title="Chukchi Sea">Chukchi Sea</a>, <a href="https://en.wikipedia.org/wiki/East_Siberian_Sea" title="East Siberian Sea">East Siberian Sea</a>, <a href="https://en.wikipedia.org/wiki/Greenland_Sea" title="Greenland Sea">Greenland Sea</a>, <a href="https://en.wikipedia.org/wiki/Hudson_Bay" title="Hudson Bay">Hudson Bay</a>, <a href="https://en.wikipedia.org/wiki/Hudson_Strait" title="Hudson Strait">Hudson Strait</a>, <a href="https://en.wikipedia.org/wiki/Kara_Sea" title="Kara Sea">Kara Sea</a>, <a href="https://en.wikipedia.org/wiki/Laptev_Sea" title="Laptev Sea">Laptev Sea</a>, <a href="https://en.wikipedia.org/wiki/White_Sea" title="White Sea">White Sea</a> and other tributary bodies of water. It is connected to the <a href="https://en.wikipedia.org/wiki/Pacific_Ocean" title="Pacific Ocean">Pacific Ocean</a> by the <a href="https://en.wikipedia.org/wiki/Bering_Strait" title="Bering Strait">Bering Strait</a> and to the Atlantic Ocean through the Greenland Sea and <a href="https://en.wikipedia.org/wiki/Labrador_Sea" title="Labrador Sea">Labrador Sea</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Pidwirny-1"><span>[</span>1<span>]</span></a></sup></p> 
<p>Countries bordering the Arctic Ocean are: Russia, Norway, Iceland, Greenland, Canada and the United States.</p> 
<h3><span>Extent and major ports</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=3" title="Edit section: Extent and major ports">edit</a><span>]</span></span></h3> 
<div>
Main article: 
<a href="https://en.wikipedia.org/wiki/Borders_of_the_oceans#Arctic_Ocean" title="Borders of the oceans">Borders of the oceans § Arctic Ocean</a>
</div> 
<p>There are several ports and <a href="https://en.wikipedia.org/wiki/Harbor" title="Harbor">harbors</a> around the Arctic Ocean<sup><a href="https://en.wikipedia.org/wiki#cite_note-CIA-12"><span>[</span>12<span>]</span></a></sup></p> 
<h4><span>United States</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=4" title="Edit section: United States">edit</a><span>]</span></span></h4> 
<p>In Alaska, the main ports are <a href="https://en.wikipedia.org/wiki/Barrow,_Alaska" title="Barrow, Alaska">Barrow</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=71_17_44_N_156_45_59_W_type:city_region:US&amp;title=Barrow"><span><span><span>71°17′44″N</span> <span>156°45′59″W</span></span></span><span>﻿ / ﻿</span><span><span><span>71.29556°N 156.76639°W</span><span>﻿ / <span>71.29556; -156.76639</span></span><span>﻿ (<span>Barrow</span>)</span></span></span></a></span>) and <a href="https://en.wikipedia.org/wiki/Prudhoe_Bay,_Alaska" title="Prudhoe Bay, Alaska">Prudhoe Bay</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=70_19_32_N_148_42_41_W_type:city_region:US&amp;title=Prudhoe"><span><span><span>70°19′32″N</span> <span>148°42′41″W</span></span></span><span>﻿ / ﻿</span><span><span><span>70.32556°N 148.71139°W</span><span>﻿ / <span>70.32556; -148.71139</span></span><span>﻿ (<span>Prudhoe</span>)</span></span></span></a></span>).</p> 
<h4><span>Canada</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=5" title="Edit section: Canada">edit</a><span>]</span></span></h4> 
<p>In <a href="https://en.wikipedia.org/wiki/Canada" title="Canada">Canada</a>, ships may anchor at <a href="https://en.wikipedia.org/wiki/Churchill,_Manitoba" title="Churchill, Manitoba">Churchill</a> (<a href="https://en.wikipedia.org/wiki/Port_of_Churchill" title="Port of Churchill">Port of Churchill</a>) (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=58_46_28_N_094_11_37_W_type:city_region:CA-MB&amp;title=Port+of+Churchill"><span><span><span>58°46′28″N</span> <span>094°11′37″W</span></span></span><span>﻿ / ﻿</span><span><span><span>58.77444°N 94.19361°W</span><span>﻿ / <span>58.77444; -94.19361</span></span><span>﻿ (<span>Port of Churchill</span>)</span></span></span></a></span>) in <a href="https://en.wikipedia.org/wiki/Manitoba" title="Manitoba">Manitoba</a>, <a href="https://en.wikipedia.org/wiki/Nanisivik" title="Nanisivik">Nanisivik</a> (<a href="https://en.wikipedia.org/wiki/Nanisivik_Naval_Facility" title="Nanisivik Naval Facility">Nanisivik Naval Facility</a>) (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=73_04_08_N_084_32_57_W_type:city_region:CA-MB&amp;title=Nanisivik+Naval+Facility"><span><span><span>73°04′08″N</span> <span>084°32′57″W</span></span></span><span>﻿ / ﻿</span><span><span><span>73.06889°N 84.54917°W</span><span>﻿ / <span>73.06889; -84.54917</span></span><span>﻿ (<span>Nanisivik Naval Facility</span>)</span></span></span></a></span>) in <a href="https://en.wikipedia.org/wiki/Nunavut" title="Nunavut">Nunavut</a>,<sup><a href="https://en.wikipedia.org/wiki#cite_note-13"><span>[</span>13<span>]</span></a></sup> <a href="https://en.wikipedia.org/wiki/Tuktoyaktuk" title="Tuktoyaktuk">Tuktoyaktuk</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=69_26_34_N_133_01_52_W_&amp;title=Tuktoyaktuk"><span><span><span>69°26′34″N</span> <span>133°01′52″W</span></span></span><span>﻿ / ﻿</span><span><span><span>69.44278°N 133.03111°W</span><span>﻿ / <span>69.44278; -133.03111</span></span><span>﻿ (<span>Tuktoyaktuk</span>)</span></span></span></a></span>) or <a href="https://en.wikipedia.org/wiki/Inuvik" title="Inuvik">Inuvik</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=68_21_42_N_133_43_50_W_type:city_region:CA-NT&amp;title=Inuvik"><span><span><span>68°21′42″N</span> <span>133°43′50″W</span></span></span><span>﻿ / ﻿</span><span><span><span>68.36167°N 133.73056°W</span><span>﻿ / <span>68.36167; -133.73056</span></span><span>﻿ (<span>Inuvik</span>)</span></span></span></a></span>) in the <a href="https://en.wikipedia.org/wiki/Northwest_territories" title="Northwest territories">Northwest territories</a>.</p> 
<h4><span>Greenland</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=6" title="Edit section: Greenland">edit</a><span>]</span></span></h4> 
<p>In Greenland, the main port is at <a href="https://en.wikipedia.org/wiki/Nuuk" title="Nuuk">Nuuk</a> (<a href="https://en.wikipedia.org/wiki/Nuuk_Port_and_Harbour" title="Nuuk Port and Harbour">Nuuk Port and Harbour</a>) (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=64_10_15_N_051_43_15_W_type:city_region:GL&amp;title=Nuuk+Port+and+Harbour"><span><span><span>64°10′15″N</span> <span>051°43′15″W</span></span></span><span>﻿ / ﻿</span><span><span><span>64.17083°N 51.72083°W</span><span>﻿ / <span>64.17083; -51.72083</span></span><span>﻿ (<span>Nuuk Port and Harbour</span>)</span></span></span></a></span>).</p> 
<h4><span>Norway</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=7" title="Edit section: Norway">edit</a><span>]</span></span></h4> 
<p>In Norway, <a href="https://en.wikipedia.org/wiki/Kirkenes" title="Kirkenes">Kirkenes</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=69_43_37_N_030_02_44_E_region:NO_type:city&amp;title=Kirkenes"><span><span><span>69°43′37″N</span> <span>030°02′44″E</span></span></span><span>﻿ / ﻿</span><span><span><span>69.72694°N 30.04556°E</span><span>﻿ / <span>69.72694; 30.04556</span></span><span>﻿ (<span>Kirkenes</span>)</span></span></span></a></span>) and <a href="https://en.wikipedia.org/wiki/Vard%C3%B8" title="Vardø">Vardø</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=70_22_14_N_031_06_27_E_region:NO_type:city&amp;title=Vard%C3%B8"><span><span><span>70°22′14″N</span> <span>031°06′27″E</span></span></span><span>﻿ / ﻿</span><span><span><span>70.37056°N 31.10750°E</span><span>﻿ / <span>70.37056; 31.10750</span></span><span>﻿ (<span>Vardø</span>)</span></span></span></a></span>) are ports on the mainland. Also, there is <a href="https://en.wikipedia.org/wiki/Longyearbyen" title="Longyearbyen">Longyearbyen</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=78_13_12_N_15_39_00_E_region:NO_type:city&amp;title=Longyearbyen"><span><span><span>78°13′12″N</span> <span>15°39′00″E</span></span></span><span>﻿ / ﻿</span><span><span><span>78.22000°N 15.65000°E</span><span>﻿ / <span>78.22000; 15.65000</span></span><span>﻿ (<span>Longyearbyen</span>)</span></span></span></a></span>) on the island of Svalbard next to <a href="https://en.wikipedia.org/wiki/Fram_Strait" title="Fram Strait">Fram Strait</a>.</p> 
<h4><span>Russia</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=8" title="Edit section: Russia">edit</a><span>]</span></span></h4> 
<p>In Russia, major ports sorted by the different sea areas are:</p> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Murmansk" title="Murmansk">Murmansk</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=68_58_N_033_05_E_type:city_region:RU&amp;title=Murmansk"><span><span><span>68°58′N</span> <span>033°05′E</span></span></span><span>﻿ / ﻿</span><span><span><span>68.967°N 33.083°E</span><span>﻿ / <span>68.967; 33.083</span></span><span>﻿ (<span>Murmansk</span>)</span></span></span></a></span>) in the Barents Sea</li> 
<li><a href="https://en.wikipedia.org/wiki/Arkhangelsk" title="Arkhangelsk">Arkhangelsk</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=64_32_N_040_32_E_type:city_region:RU&amp;title=Arkhangelsk"><span><span><span>64°32′N</span> <span>040°32′E</span></span></span><span>﻿ / ﻿</span><span><span><span>64.533°N 40.533°E</span><span>﻿ / <span>64.533; 40.533</span></span><span>﻿ (<span>Arkhangelsk</span>)</span></span></span></a></span>) in the White Sea</li> 
<li><a href="https://en.wikipedia.org/wiki/Labytnangi" title="Labytnangi">Labytnangi</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=66_39_26_N_066_25_06_E_type:city_region:RU&amp;title=Labytnangi"><span><span><span>66°39′26″N</span> <span>066°25′06″E</span></span></span><span>﻿ / ﻿</span><span><span><span>66.65722°N 66.41833°E</span><span>﻿ / <span>66.65722; 66.41833</span></span><span>﻿ (<span>Labytnangi</span>)</span></span></span></a></span>) <a href="https://en.wikipedia.org/wiki/Salekhard" title="Salekhard">Salekhard</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=66_32_N_066_36_E_type:city_region:RU&amp;title=Salekhard"><span><span><span>66°32′N</span> <span>066°36′E</span></span></span><span>﻿ / ﻿</span><span><span><span>66.533°N 66.600°E</span><span>﻿ / <span>66.533; 66.600</span></span><span>﻿ (<span>Salekhard</span>)</span></span></span></a></span>), <a href="https://en.wikipedia.org/wiki/Dudinka" title="Dudinka">Dudinka</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=69_24_N_086_11_E_type:city_region:RU&amp;title=Dudinka"><span><span><span>69°24′N</span> <span>086°11′E</span></span></span><span>﻿ / ﻿</span><span><span><span>69.400°N 86.183°E</span><span>﻿ / <span>69.400; 86.183</span></span><span>﻿ (<span>Dudinka</span>)</span></span></span></a></span>), <a href="https://en.wikipedia.org/wiki/Igarka" title="Igarka">Igarka</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=67_28_N_86_35_E_type:city_region:RU&amp;title=Igarka"><span><span><span>67°28′N</span> <span>86°35′E</span></span></span><span>﻿ / ﻿</span><span><span><span>67.467°N 86.583°E</span><span>﻿ / <span>67.467; 86.583</span></span><span>﻿ (<span>Igarka</span>)</span></span></span></a></span>) and <a href="https://en.wikipedia.org/wiki/Dikson_(urban-type_settlement)" title="Dikson (urban-type settlement)">Dikson</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=73_30_N_080_31_E_type:city_region:RU&amp;title=Dikson"><span><span><span>73°30′N</span> <span>080°31′E</span></span></span><span>﻿ / ﻿</span><span><span><span>73.500°N 80.517°E</span><span>﻿ / <span>73.500; 80.517</span></span><span>﻿ (<span>Dikson</span>)</span></span></span></a></span>) in the Kara Sea</li> 
<li><a href="https://en.wikipedia.org/wiki/Tiksi" title="Tiksi">Tiksi</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=71_38_N_128_52_E_type:city_region:RU&amp;title=Tiksi%2C+city+of+the+Polar+Heros"><span><span><span>71°38′N</span> <span>128°52′E</span></span></span><span>﻿ / ﻿</span><span><span><span>71.633°N 128.867°E</span><span>﻿ / <span>71.633; 128.867</span></span><span>﻿ (<span>Tiksi, city of the Polar Heros</span>)</span></span></span></a></span>) in the Laptev Sea</li> 
<li><a href="https://en.wikipedia.org/wiki/Pevek" title="Pevek">Pevek</a> (<span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=69_42_N_170_17_E_type:city_region:RU&amp;title=Pevek"><span><span><span>69°42′N</span> <span>170°17′E</span></span></span><span>﻿ / ﻿</span><span><span><span>69.700°N 170.283°E</span><span>﻿ / <span>69.700; 170.283</span></span><span>﻿ (<span>Pevek</span>)</span></span></span></a></span>) in the East Siberian Sea</li> 
</ul> 
<h3><span><span></span>Arctic shelves</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=9" title="Edit section: Arctic shelves">edit</a><span>]</span></span></h3> 
<p>The ocean's Arctic shelf comprises a number of <a href="https://en.wikipedia.org/wiki/Continental_shelf" title="Continental shelf">continental shelves</a>, including the Canadian Arctic shelf, underlying the <a href="https://en.wikipedia.org/wiki/Canadian_Arctic_Archipelago" title="Canadian Arctic Archipelago">Canadian Arctic Archipelago</a>, and the <a href="https://en.wikipedia.org/wiki/Continental_shelf_of_Russia" title="Continental shelf of Russia">Russian continental shelf</a>, which is sometimes simply called the "Arctic Shelf" because it is greater in extent. The Russian continental shelf consists of three separate, smaller shelves, the <a href="https://en.wikipedia.org/w/index.php?title=Barents_Shelf&amp;action=edit&amp;redlink=1" title="Barents Shelf (page does not exist)">Barents Shelf</a>, <a href="https://en.wikipedia.org/wiki/Chukchi_Sea_Shelf" title="Chukchi Sea Shelf">Chukchi Sea Shelf</a> and <a href="https://en.wikipedia.org/wiki/Siberian_Shelf" title="Siberian Shelf">Siberian Shelf</a>. Of these three, the Siberian Shelf is the largest such shelf in the world. The Siberian Shelf holds large oil and gas reserves, and the Chukchi shelf forms the border between Russian and the United States as stated in the <a href="https://en.wikipedia.org/wiki/USSR%E2%80%93USA_Maritime_Boundary_Agreement" title="USSR–USA Maritime Boundary Agreement">USSR–USA Maritime Boundary Agreement</a>. The whole area is subject to international <a href="https://en.wikipedia.org/wiki/Territorial_claims_in_the_Arctic" title="Territorial claims in the Arctic">territorial claims</a>.</p> 
<h3><span>Underwater features</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=10" title="Edit section: Underwater features">edit</a><span>]</span></span></h3> 
<p>An <a href="https://en.wikipedia.org/wiki/Mid-ocean_ridge" title="Mid-ocean ridge">underwater ridge</a>, the <a href="https://en.wikipedia.org/wiki/Lomonosov_Ridge" title="Lomonosov Ridge">Lomonosov Ridge</a>, divides the deep sea <a href="https://en.wikipedia.org/wiki/Arctic_Basin" title="Arctic Basin">North Polar Basin</a> into two <a href="https://en.wikipedia.org/wiki/Oceanic_basin" title="Oceanic basin">oceanic basins</a>: the <a href="https://en.wikipedia.org/wiki/Eurasian_Basin" title="Eurasian Basin">Eurasian Basin</a>, which is between 4,000 and 4,500&nbsp;m (13,100 and 14,800&nbsp;ft) deep, and the <a href="https://en.wikipedia.org/wiki/Amerasian_Basin" title="Amerasian Basin">Amerasian Basin</a> (sometimes called the North American, or Hyperborean Basin), which is about 4,000&nbsp;m (13,000&nbsp;ft) deep. The <a href="https://en.wikipedia.org/wiki/Bathymetry" title="Bathymetry">bathymetry</a> of the ocean bottom is marked by <a href="https://en.wikipedia.org/wiki/Fault_block" title="Fault block">fault block</a> ridges, <a href="https://en.wikipedia.org/wiki/Abyssal_plain" title="Abyssal plain">abyssal plains</a>, <a href="https://en.wikipedia.org/wiki/Oceanic_trench" title="Oceanic trench">ocean deeps</a>, and basins. The average depth of the Arctic Ocean is 1,038&nbsp;m (3,406&nbsp;ft).<sup><a href="https://en.wikipedia.org/wiki#cite_note-14"><span>[</span>14<span>]</span></a></sup> The deepest point is <a href="https://en.wikipedia.org/wiki/Litke_Deep" title="Litke Deep">Litke Deep</a> in the Eurasian Basin, at 5,450&nbsp;m (17,880&nbsp;ft).</p> 
<p>The two major basins are further subdivided by ridges into the <a href="https://en.wikipedia.org/wiki/Canada_Basin" title="Canada Basin">Canada Basin</a> (between Alaska/Canada and the <a href="https://en.wikipedia.org/wiki/Alpha_Ridge" title="Alpha Ridge">Alpha Ridge</a>), <a href="https://en.wikipedia.org/wiki/Makarov_Basin" title="Makarov Basin">Makarov Basin</a> (between the Alpha and Lomonosov Ridges), <a href="https://en.wikipedia.org/wiki/Nansen_Basin" title="Nansen Basin">Nansen Basin</a> (between Lomonosov and <a href="https://en.wikipedia.org/wiki/Gakkel_Ridge" title="Gakkel Ridge">Gakkel</a> ridges), and Nansen Basin (<a href="https://en.wikipedia.org/wiki/Amundsen_Basin" title="Amundsen Basin">Amundsen Basin</a>) (between the Gakkel Ridge and the continental shelf that includes the <a href="https://en.wikipedia.org/wiki/Franz_Josef_Land" title="Franz Josef Land">Franz Josef Land</a>).</p> 
<h2><span>Oceanography</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=11" title="Edit section: Oceanography">edit</a><span>]</span></span></h2> 
<h3><span>Water flow</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=12" title="Edit section: Water flow">edit</a><span>]</span></span></h3> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:BrnBld_BeringToFram.svg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/BrnBld_BeringToFram.svg/650px-BrnBld_BeringToFram.svg.png" width="650" height="200"></a> 
<div>
Distribution of the major 
<a href="https://en.wikipedia.org/wiki/Water_mass" title="Water mass">water mass</a> in the Arctic Ocean. The section sketches the different water masses along a vertical section from 
<a href="https://en.wikipedia.org/wiki/Bering_Strait" title="Bering Strait">Bering Strait</a> over the geographic 
<a href="https://en.wikipedia.org/wiki/North_Pole" title="North Pole">North Pole</a> to 
<a href="https://en.wikipedia.org/wiki/Fram_Strait" title="Fram Strait">Fram Strait</a>. As the 
<a href="https://en.wikipedia.org/wiki/Stratification_(water)" title="Stratification (water)">stratification</a> is stable, deeper water masses are more dense than the layers above.
</div> 
</div> 
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Temperature_and_salinity_profiles_in_the_Arctic_Ocean.svg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Temperature_and_salinity_profiles_in_the_Arctic_Ocean.svg/220px-Temperature_and_salinity_profiles_in_the_Arctic_Ocean.svg.png" width="220" height="155"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Temperature_and_salinity_profiles_in_the_Arctic_Ocean.svg" title="Enlarge"></a>
</div> Density structure of the upper 1,200&nbsp;m (3,900&nbsp;ft) in the Arctic Ocean. Profiles of temperature and salinity for the Amundsen Basin, the Canadian Basin and the Greenland Sea are sketched in this cartoon.
</div> 
</div> 
</div> 
<p>In large parts of the Arctic Ocean, the top layer (about 50&nbsp;m (160&nbsp;ft)) is of lower salinity and lower temperature than the rest. It remains relatively stable, because the salinity effect on density is bigger than the temperature effect. It is fed by the freshwater input of the big Siberian and Canadian streams (<a href="https://en.wikipedia.org/wiki/Ob_River" title="Ob River">Ob</a>, <a href="https://en.wikipedia.org/wiki/Yenisei_River" title="Yenisei River">Yenisei</a>, <a href="https://en.wikipedia.org/wiki/Lena_River" title="Lena River">Lena</a>, <a href="https://en.wikipedia.org/wiki/Mackenzie_River" title="Mackenzie River">Mackenzie</a>), the water of which quasi floats on the saltier, denser, deeper ocean water. Between this lower salinity layer and the bulk of the ocean lies the so-called <a href="https://en.wikipedia.org/wiki/Halocline" title="Halocline">halocline</a>, in which both salinity and temperature are rising with increasing depth.</p> 
<p>Due to its relative isolation from other oceans, the Arctic Ocean has a uniquely complex system of water flow. It is classified as a mediterranean sea, which as “a part of the world ocean which has only limited communication with the major ocean basins (these being the Pacific, Atlantic, and Indian Oceans) and where the circulation is dominated by thermohaline forcing”.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> The Arctic Ocean has a total volume of 18.07×10<sup>6</sup>&nbsp;km<sup>3</sup>, equal to about 1.3% of the World Ocean. Mean surface circulation is predominately cyclonic on the <a href="https://en.wikipedia.org/wiki/Eurasian" title="Eurasian">Eurasian</a> side and anticyclonic in the <a href="https://en.wikipedia.org/wiki/Canadian_Basin" title="Canadian Basin">Canadian Basin</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Talley-16"><span>[</span>16<span>]</span></a></sup></p> 
<p>Water enters from both the Pacific and Atlantic Oceans and can be divided into three unique water masses. The deepest water mass is called Arctic Bottom Water and begins around 900 meters depth.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> It is composed of the densest water in the World Ocean and has two main sources: Arctic shelf water and Greenland Sea Deep Water. Water in the shelf region that begins as inflow from the Pacific passes through the narrow <a href="https://en.wikipedia.org/wiki/Bering_Strait" title="Bering Strait">Bering Strait</a> at an average rate of 0.8 Sverdrups and reaches the <a href="https://en.wikipedia.org/wiki/Chukchi_Sea" title="Chukchi Sea">Chukchi Sea</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Nature-17"><span>[</span>17<span>]</span></a></sup> During the winter, cold Alaskan winds blow over the Chukchi Sea, freezing the surface water and pushing this newly formed ice out to the Pacific. The speed of the ice drift is roughly 1–4&nbsp;cm/s.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Talley-16"><span>[</span>16<span>]</span></a></sup> This process leaves dense, salty waters in the sea that sink over the continental shelf into the western Arctic Ocean and create a <a href="https://en.wikipedia.org/wiki/Halocline" title="Halocline">halocline</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Polar-18"><span>[</span>18<span>]</span></a></sup></p> 
<p>This water is met by Greenland Sea Deep Water, which forms during the passage of winter storms. As temperatures cool dramatically in the winter, ice forms and intense vertical convection allows the water to become dense enough to sink below the warm saline water below.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> Arctic Bottom Water is critically important because of its outflow, which contributes to the formation of Atlantic Deep Water. The overturning of this water plays a key role in global circulation and the moderation of climate.</p> 
<p>In the depth range of 150–900 meters is a water mass referred to as Atlantic Water. Inflow from the <a href="https://en.wikipedia.org/wiki/North_Atlantic_Current" title="North Atlantic Current">North Atlantic Current</a> enters through the <a href="https://en.wikipedia.org/wiki/Fram_Strait" title="Fram Strait">Fram Strait</a>, cooling and sinking to form the deepest layer of the halocline, where it circles the <a href="https://en.wikipedia.org/wiki/Arctic_Basin" title="Arctic Basin">Arctic Basin</a> counter-clockwise. This is the highest volumetric inflow to the Arctic Ocean, equaling about 10 times that of the Pacific inflow, and it creates the Arctic Ocean Boundary Current.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Nature-17"><span>[</span>17<span>]</span></a></sup> It flows slowly, at about 0.02&nbsp;m/s.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> Atlantic Water has the same salinity as Arctic Bottom Water but is much warmer (up to 3&nbsp;°C). In fact, this water mass is actually warmer than the surface water, and remains submerged only due the role of salinity in density.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> When water reaches the basin it is pushed by strong winds into a large circular current called the <a href="https://en.wikipedia.org/wiki/Beaufort_Gyre" title="Beaufort Gyre">Beaufort Gyre</a>. Water in the Beaufort Gyre is far less saline than that of the Chukchi Sea due to inflow from large Canadian and Siberian rivers.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Polar-18"><span>[</span>18<span>]</span></a></sup></p> 
<p>The final defined water mass in the Arctic Ocean is called Arctic Surface Water and is found from 150–200 meters. The most important feature of this water mass is a section referred to as the sub-surface layer. It is a product of Atlantic water that enters through canyons and is subjected to intense mixing on the <a href="https://en.wikipedia.org/wiki/Siberian_Shelf" title="Siberian Shelf">Siberian Shelf</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> As it is entrained, it cools and acts a heat shield for the surface layer. This insulation keeps the warm Atlantic Water from melting the surface ice. Additionally, this water forms the swiftest currents of the Arctic, with speed of around 0.3-0.6&nbsp;m/s.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> Complementing the water from the canyons, some Pacific water that does not sink to the shelf region after passing through the Bering Strait also contributes to this water mass.</p> 
<p>Waters originating in the Pacific and Atlantic both exit through the Fram Strait between <a href="https://en.wikipedia.org/wiki/Greenland" title="Greenland">Greenland</a> and <a href="https://en.wikipedia.org/wiki/Svalbard_Island" title="Svalbard Island">Svalbard Island</a>, which is about 2700 meters deep and 350 kilometers wide. This outflow is about 9 Sv.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Nature-17"><span>[</span>17<span>]</span></a></sup> The width of the Fram Strait is what allows for both inflow and outflow on the Atlantic side of the Arctic Ocean. Because of this, it is influenced by the <a href="https://en.wikipedia.org/wiki/Coriolis_force" title="Coriolis force">Coriolis force</a>, which concentrates outflow to the East Greenland Current on the western side and inflow to the <a href="https://en.wikipedia.org/wiki/Norwegian_Current" title="Norwegian Current">Norwegian Current</a> on the eastern side.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Tomczak-15"><span>[</span>15<span>]</span></a></sup> Pacific water also exits along the west coast of Greenland and the <a href="https://en.wikipedia.org/wiki/Hudson_Strait" title="Hudson Strait">Hudson Strait</a> (1-2 Sv), providing nutrients to the Canadian Archipelago.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Nature-17"><span>[</span>17<span>]</span></a></sup></p> 
<p>As noted, the process of ice formation and movement is a key driver in Arctic Ocean circulation and the formation of water masses. With this dependence, the Arctic Ocean experiences variations due to seasonal changes in sea ice cover. Sea ice movement is the result of wind forcing, which is related to a number of meteorological conditions that the Arctic experiences throughout the year. For example, the Beaufort High—an extension of the <a href="https://en.wikipedia.org/wiki/Siberian_High" title="Siberian High">Siberian High</a> system—is a pressure system that drives the anticyclonic motion of the Beaufort Gyre.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Talley-16"><span>[</span>16<span>]</span></a></sup> During the summer, this area of high pressure is pushed out closer to its Siberian and Canadian sides. In addition, there is a <a href="https://en.wikipedia.org/wiki/Sea_level_pressure" title="Sea level pressure">sea level pressure</a> (SLP) ridge over Greenland that drives strong northerly winds through the Fram Strait, facilitating ice export. In the summer, the SLP contrast is smaller, producing weaker winds. A final example of seasonal pressure system movement is the low pressure system that exists over the Nordic and Barents Seas. It is an extension of the <a href="https://en.wikipedia.org/wiki/Icelandic_Low" title="Icelandic Low">Icelandic Low</a>, which creates cyclonic ocean circulation in this area. The low shifts to center over the North Pole in the summer. These variations in the Arctic all contribute to ice drift reaching its weakest point during the summer months. There is also evidence that the drift is associated with the phase of the Arctic Oscillation and <a href="https://en.wikipedia.org/wiki/Atlantic_Multidecadal_Oscillation" title="Atlantic Multidecadal Oscillation">Atlantic Multidecadal Oscillation</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-Talley-16"><span>[</span>16<span>]</span></a></sup></p> 
<h3><span>Sea ice</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=13" title="Edit section: Sea ice">edit</a><span>]</span></span></h3> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:2007_Arctic_Sea_Ice.jpg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/2007_Arctic_Sea_Ice.jpg/300px-2007_Arctic_Sea_Ice.jpg" width="300" height="251"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:2007_Arctic_Sea_Ice.jpg" title="Enlarge"></a>
</div> Sea cover in the Arctic Ocean, showing the median, 2005 and 2007 coverage 
<sup><a href="https://en.wikipedia.org/wiki#cite_note-19"><span>[</span>19<span>]</span></a></sup>
</div> 
</div> 
</div> 
<div>
Main article: 
<a href="https://en.wikipedia.org/wiki/Arctic_ice_pack" title="Arctic ice pack">Arctic ice pack</a>
</div> 
<p>Much of the Arctic Ocean is covered by sea ice which varies in extent and thickness seasonally. The mean extent of the ice is decreasing since 1980 from the average winter value of 15,600,000&nbsp;km<sup>2</sup> (6,023,200&nbsp;sq&nbsp;mi) at a rate of 3% per decade. The seasonal variations are about 7,000,000&nbsp;km<sup>2</sup> (2,702,700&nbsp;sq&nbsp;mi) with the maximum in April and minimum in September. The sea ice is affected by wind and ocean currents which can move and rotate very large areas of ice. Zones of compression also arise, where the ice piles up to form pack ice.<sup><a href="https://en.wikipedia.org/wiki#cite_note-20"><span>[</span>20<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-21"><span>[</span>21<span>]</span></a></sup></p> 
<p>Icebergs occasionally break away from northern <a href="https://en.wikipedia.org/wiki/Ellesmere_Island" title="Ellesmere Island">Ellesmere Island</a>, and icebergs are formed from <a href="https://en.wikipedia.org/wiki/Glacier" title="Glacier">glaciers</a> in western Greenland and extreme northeastern Canada. These icebergs pose a hazard to ships, of which the <a href="https://en.wikipedia.org/wiki/RMS_Titanic" title="RMS Titanic"><i>Titanic</i></a> is one of the most famous. <a href="https://en.wikipedia.org/wiki/Permafrost" title="Permafrost">Permafrost</a> is found on most islands. The ocean is virtually icelocked from October to June, and the <a href="https://en.wikipedia.org/wiki/Superstructure" title="Superstructure">superstructure</a> of ships are subject to <a href="https://en.wikipedia.org/wiki/Icing_(nautical)" title="Icing (nautical)">icing</a> from October to May.<sup><a href="https://en.wikipedia.org/wiki#cite_note-CIA-12"><span>[</span>12<span>]</span></a></sup> Before the advent of modern <a href="https://en.wikipedia.org/wiki/Icebreaker" title="Icebreaker">icebreakers</a>, ships sailing the Arctic Ocean risked being trapped or crushed by sea ice (although the <i><a href="https://en.wikipedia.org/wiki/SS_Baychimo" title="SS Baychimo">Baychimo</a></i> drifted through the Arctic Ocean untended for decades despite these hazards).</p> 
<h2><span>Climate</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=14" title="Edit section: Climate">edit</a><span>]</span></span></h2> 
<div>
See also: 
<a href="https://en.wikipedia.org/wiki/Climate_change_in_the_Arctic" title="Climate change in the Arctic">Climate change in the Arctic</a>
</div> 
<div> 
<div> 
<div>
<img alt="File:North Pole Sea Ice 1990-1999.ogg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/North_Pole_Sea_Ice_1990-1999.ogg/210px--North_Pole_Sea_Ice_1990-1999.ogg.jpg">
<a href="https://upload.wikimedia.org/wikipedia/commons/9/98/North_Pole_Sea_Ice_1990-1999.ogg" title="Play media"><span><span>Play media</span></span></a>
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:North_Pole_Sea_Ice_1990-1999.ogg" title="Enlarge"></a>
</div> Changes in ice between 1990–1999
</div> 
</div> 
</div> 
<p>Under the influence of the <a href="https://en.wikipedia.org/wiki/Quaternary_glaciation" title="Quaternary glaciation">Quaternary glaciation</a>, the Arctic Ocean is contained in a <a href="https://en.wikipedia.org/wiki/Polar_climate" title="Polar climate">polar climate</a> characterized by persistent cold and relatively narrow annual temperature ranges. Winters are characterized by the <a href="https://en.wikipedia.org/wiki/Polar_night" title="Polar night">polar night</a>, cold and stable weather conditions, and clear skies; summers are characterized by continuous <a href="https://en.wikipedia.org/wiki/Daylight" title="Daylight">daylight</a> (<a href="https://en.wikipedia.org/wiki/Midnight_sun" title="Midnight sun">midnight sun</a>), damp and foggy weather, and weak <a href="https://en.wikipedia.org/wiki/Cyclone" title="Cyclone">cyclones</a> with rain or snow<sup>[<i><a href="https://en.wikipedia.org/wiki/Wikipedia:Citation_needed" title="Wikipedia:Citation needed"><span>citation needed</span></a></i>]</sup></p> 
<p>The temperature of the surface of the Arctic Ocean is fairly constant, near the <a href="https://en.wikipedia.org/wiki/Melting_point" title="Melting point">freezing point</a> of <a href="https://en.wikipedia.org/wiki/Seawater" title="Seawater">seawater</a>. Because the Arctic Ocean consists of saltwater, the temperature must reach −1.8&nbsp;°C (28.8&nbsp;°F) before freezing occurs.</p> 
<p>The <a href="https://en.wikipedia.org/wiki/Density" title="Density">density</a> of sea water, in contrast to fresh water, increases as it nears the freezing point and thus it tends to sink. It is generally necessary that the upper 100–150&nbsp;m (330–490&nbsp;ft) of ocean water cools to the freezing point for sea ice to form.<sup><a href="https://en.wikipedia.org/wiki#cite_note-22"><span>[</span>22<span>]</span></a></sup> In the winter the relatively warm ocean water exerts a moderating influence, even when covered by ice. This is one reason why the Arctic does not experience the extreme temperatures seen on the <a href="https://en.wikipedia.org/wiki/Antarctica" title="Antarctica">Antarctic continent</a>.</p> 
<p>There is considerable seasonal variation in how much pack ice of the Arctic ice pack covers the Arctic Ocean. Much of the Arctic ice pack is also covered in snow for about 10 months of the year. The maximum snow cover is in March or April — about 20 to 50&nbsp;cm (7.9 to 19.7&nbsp;in) over the frozen ocean.</p> 
<p>The climate of the Arctic region has varied significantly in the past. As recently as 55 million years ago, during the <a href="https://en.wikipedia.org/wiki/Paleocene%E2%80%93Eocene_Thermal_Maximum" title="Paleocene–Eocene Thermal Maximum">Paleocene–Eocene Thermal Maximum</a>, the region reached an average annual temperature of 10–20&nbsp;°C (50–68&nbsp;°F).<sup><a href="https://en.wikipedia.org/wiki#cite_note-Shellito2003-23"><span>[</span>23<span>]</span></a></sup> The surface waters of the northernmost<sup><a href="https://en.wikipedia.org/wiki#cite_note-24"><span>[</span>24<span>]</span></a></sup> Arctic ocean warmed, seasonally at least, enough to support tropical lifeforms<sup><a href="https://en.wikipedia.org/wiki#cite_note-25"><span>[</span>25<span>]</span></a></sup> requiring surface temperatures of over 22&nbsp;°C (72&nbsp;°F).<sup><a href="https://en.wikipedia.org/wiki#cite_note-Sluijs2006-26"><span>[</span>26<span>]</span></a></sup></p> 
<h2><span>Animal and plant life</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=15" title="Edit section: Animal and plant life">edit</a><span>]</span></span></h2> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Polar_bears_near_north_pole.jpg"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Polar_bears_near_north_pole.jpg/220px-Polar_bears_near_north_pole.jpg" width="220" height="165"></a> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/File:Polar_bears_near_north_pole.jpg" title="Enlarge"></a>
</div> Three 
<a href="https://en.wikipedia.org/wiki/Polar_bear" title="Polar bear">polar bears</a> approach 
<a href="https://en.wikipedia.org/wiki/USS_Honolulu_(SSN-718)" title="USS Honolulu (SSN-718)">USS <i>Honolulu</i></a> near the 
<a href="https://en.wikipedia.org/wiki/North_Pole" title="North Pole">North Pole</a>.
</div> 
</div> 
</div> 
<p>Endangered marine species in the Arctic Ocean include <a href="https://en.wikipedia.org/wiki/Walrus" title="Walrus">walruses</a> and <a href="https://en.wikipedia.org/wiki/Whale" title="Whale">whales</a>. The area has a fragile <a href="https://en.wikipedia.org/wiki/Ecosystem" title="Ecosystem">ecosystem</a> which is slow to change and slow to recover from disruptions or damage.<sup><a href="https://en.wikipedia.org/wiki#cite_note-CIA-12"><span>[</span>12<span>]</span></a></sup> <a href="https://en.wikipedia.org/wiki/Lion%27s_mane_jellyfish" title="Lion's mane jellyfish">Lion's mane jellyfish</a> are abundant in the waters of the Arctic, and the <a href="https://en.wikipedia.org/wiki/Banded_gunnel" title="Banded gunnel">banded gunnel</a> is the only species of <a href="https://en.wikipedia.org/wiki/Pholidae" title="Pholidae">gunnel</a> that lives in the ocean.</p> 
<p>The Arctic Ocean has relatively little plant life except for <a href="https://en.wikipedia.org/wiki/Phytoplankton" title="Phytoplankton">phytoplankton</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-27"><span>[</span>27<span>]</span></a></sup> Phytoplankton are a crucial part of the ocean and there are massive amounts of them in the Arctic, where they feed on nutrients from rivers and the <a href="https://en.wikipedia.org/wiki/Ocean_current" title="Ocean current">currents</a> of the Atlantic and Pacific oceans.<sup><a href="https://en.wikipedia.org/wiki#cite_note-NOAA-28"><span>[</span>28<span>]</span></a></sup> During summer, the sun is out day and night, thus enabling the phytoplankton to <a href="https://en.wikipedia.org/wiki/Photosynthesis" title="Photosynthesis">photosynthesize</a> for long periods of time and reproduce quickly. However, the reverse is true in winter when they struggle to get enough light to survive.<sup><a href="https://en.wikipedia.org/wiki#cite_note-NOAA-28"><span>[</span>28<span>]</span></a></sup></p> 
<h2><span>Natural resources</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=16" title="Edit section: Natural resources">edit</a><span>]</span></span></h2> 
<div>
See also: 
<a href="https://en.wikipedia.org/wiki/Natural_resources_of_the_Arctic" title="Natural resources of the Arctic">Natural resources of the Arctic</a>, 
<a href="https://en.wikipedia.org/wiki/Territorial_claims_in_the_Arctic" title="Territorial claims in the Arctic">Territorial claims in the Arctic</a> and 
<a href="https://en.wikipedia.org/wiki/Marine_mammal" title="Marine mammal">Marine mammal</a>
</div> 
<p><a href="https://en.wikipedia.org/wiki/Petroleum" title="Petroleum">Petroleum</a> and <a href="https://en.wikipedia.org/wiki/Natural_gas" title="Natural gas">natural gas</a> <a href="https://en.wikipedia.org/wiki/Natural_gas_field" title="Natural gas field">fields</a>, <a href="https://en.wikipedia.org/wiki/Placer_deposit" title="Placer deposit">placer deposits</a>, <a href="https://en.wikipedia.org/wiki/Manganese_nodule" title="Manganese nodule">polymetallic nodules</a>, sand and gravel <a href="https://en.wikipedia.org/wiki/Construction_aggregate" title="Construction aggregate">aggregates</a>, fish, seals and whales can all be found in abundance in the region.<sup><a href="https://en.wikipedia.org/wiki#cite_note-CIA-12"><span>[</span>12<span>]</span></a></sup></p> 
<p>The political dead zone near the center of the sea is also the focus of a mounting dispute between the United States, Russia, Canada, Norway, and Denmark.<sup><a href="https://en.wikipedia.org/wiki#cite_note-29"><span>[</span>29<span>]</span></a></sup> It is significant for the global <a href="https://en.wikipedia.org/wiki/Energy_market" title="Energy market">energy market</a> because it may hold 25% or more of the world's undiscovered oil and gas resources.<sup><a href="https://en.wikipedia.org/wiki#cite_note-30"><span>[</span>30<span>]</span></a></sup></p> 
<h2><span>Environmental concerns</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=17" title="Edit section: Environmental concerns">edit</a><span>]</span></span></h2> 
<div>
Main articles: 
<a href="https://en.wikipedia.org/wiki/Climate_change_in_the_Arctic" title="Climate change in the Arctic">Climate change in the Arctic</a>, 
<a href="https://en.wikipedia.org/wiki/Ozone_depletion" title="Ozone depletion">ozone depletion</a> and 
<a href="https://en.wikipedia.org/wiki/Pollution_in_the_Arctic_Ocean" title="Pollution in the Arctic Ocean">Pollution in the Arctic Ocean</a>
</div> 
<p>The Arctic ice pack is thinning, and in many years there is also a seasonal hole in the <a href="https://en.wikipedia.org/wiki/Ozone_layer" title="Ozone layer">ozone layer</a>.<sup><a href="https://en.wikipedia.org/wiki#cite_note-31"><span>[</span>31<span>]</span></a></sup> Reduction of the area of Arctic sea ice reduces the planet's average <a href="https://en.wikipedia.org/wiki/Albedo" title="Albedo">albedo</a>, possibly resulting in <a href="https://en.wikipedia.org/wiki/Global_warming" title="Global warming">global warming</a> in a positive feedback mechanism.<sup><a href="https://en.wikipedia.org/wiki#cite_note-R.Black-32"><span>[</span>32<span>]</span></a></sup> Research shows that the Arctic may become ice free for the first time in human history by 2040.<sup><a href="https://en.wikipedia.org/wiki#cite_note-33"><span>[</span>33<span>]</span></a></sup></p> 
<p>Warming temperatures in the Arctic may cause large amounts of fresh <a href="https://en.wikipedia.org/wiki/Meltwater" title="Meltwater">meltwater</a> to enter the north Atlantic, possibly disrupting global <a href="https://en.wikipedia.org/wiki/Thermohaline_circulation" title="Thermohaline circulation">ocean current patterns</a>. Potentially severe changes in the Earth's <a href="https://en.wikipedia.org/wiki/Climate" title="Climate">climate</a> might then ensue.<sup><a href="https://en.wikipedia.org/wiki#cite_note-R.Black-32"><span>[</span>32<span>]</span></a></sup></p> 
<p>As the extent of sea ice diminishes and sea level rises, the effect of storms such as the <a href="https://en.wikipedia.org/wiki/Great_Arctic_Cyclone_of_2012" title="Great Arctic Cyclone of 2012">Great Arctic Cyclone of 2012</a> on open water increases, as does possible salt-water damage to vegetation on shore at locations such as the Mackenzie's <a href="https://en.wikipedia.org/wiki/River_delta" title="River delta">river delta</a> as stronger <a href="https://en.wikipedia.org/wiki/Storm_surge" title="Storm surge">storm surges</a> become more likely.<sup><a href="https://en.wikipedia.org/wiki#cite_note-CC03513-34"><span>[</span>34<span>]</span></a></sup></p> 
<p>Other <a href="https://en.wikipedia.org/wiki/Environmentalism" title="Environmentalism">environmental concerns</a> relate to the <a href="https://en.wikipedia.org/wiki/Radioactive_contamination" title="Radioactive contamination">radioactive contamination</a> of the Arctic Ocean from, for example, Russian <a href="https://en.wikipedia.org/wiki/Radioactive_waste" title="Radioactive waste">radioactive waste</a> dump sites in the Kara Sea<sup><a href="https://en.wikipedia.org/wiki#cite_note-35"><span>[</span>35<span>]</span></a></sup> and <a href="https://en.wikipedia.org/wiki/Cold_War" title="Cold War">Cold War</a> <a href="https://en.wikipedia.org/wiki/Nuclear_weapons_testing" title="Nuclear weapons testing">nuclear test sites</a> such as Novaya Zemlya.<sup><a href="https://en.wikipedia.org/wiki#cite_note-36"><span>[</span>36<span>]</span></a></sup> In addition, Shell planned to drill exploratory wells in the Chukchi and Beaufort seas during the summer of 2012, which environmental groups filed a lawsuit about in an attempt to protect native communities, endangered wildlife, and the Arctic Ocean in the event of a major oil spill.<sup><a href="https://en.wikipedia.org/wiki#cite_note-37"><span>[</span>37<span>]</span></a></sup></p> 
<p>On July 16, 2015, five nations (United States of America, Russia, Canada, Norway, Denmark/Greenland) signed a declaration committing to keep their fishing vessels out of a 1.1 million square mile zone in the central Arctic Ocean near the North Pole. The agreement calls for those nations to refrain from fishing there until there is better scientific knowledge about the marine resources and until a regulatory system is in place to protect those resources.<sup><a href="https://en.wikipedia.org/wiki#cite_note-38"><span>[</span>38<span>]</span></a></sup><sup><a href="https://en.wikipedia.org/wiki#cite_note-39"><span>[</span>39<span>]</span></a></sup></p> 
<h2><span>See also</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=18" title="Edit section: See also">edit</a><span>]</span></span></h2> 
<div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/File:Ibca_gebco_comp_cover.jpg"><img alt="Portal icon" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Ibca_gebco_comp_cover.jpg/28px-Ibca_gebco_comp_cover.jpg" width="28" height="28"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Portal:Arctic" title="Portal:Arctic">Arctic portal</a></td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/File:Terrestrial_globe.svg"><img alt="Portal icon" src="https://upload.wikimedia.org/wikipedia/en/thumb/6/6b/Terrestrial_globe.svg/29px-Terrestrial_globe.svg.png" width="29" height="28"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Portal:Geography" title="Portal:Geography">Geography portal</a></td> 
</tr> 
</tbody>
</table> 
</div> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Bridge" title="Arctic Bridge">Arctic Bridge</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_cooperation_and_politics" title="Arctic cooperation and politics">Arctic cooperation and politics</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_sea_ice_ecology_and_history" title="Arctic sea ice ecology and history">Arctic sea ice ecology and history</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Chukchi_Cap" title="Chukchi Cap">Chukchi Cap</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Explorers_of_the_Arctic" title="Category:Explorers of the Arctic">Explorers of the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Extreme_points_of_the_Arctic" title="Extreme points of the Arctic">Extreme points of the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Fauna_of_the_Arctic" title="Category:Fauna of the Arctic">Fauna of the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/International_Arctic_Science_Committee" title="International Arctic Science Committee">International Arctic Science Committee</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nordicity" title="Nordicity">Nordicity</a></li> 
<li><a href="https://en.wikipedia.org/wiki/North_Atlantic_Current" title="North Atlantic Current">North Atlantic Current</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Seven_Seas" title="Seven Seas">Seven Seas</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Subarctic" title="Subarctic">Subarctic</a></li> 
</ul> 
</div> 
<h2><span>References</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=19" title="Edit section: References">edit</a><span>]</span></span></h2> 
<div> 
<ol> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-Pidwirny_1-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Pidwirny_1-1"><sup><i><b>b</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Pidwirny_1-2"><sup><i><b>c</b></i></sup></a></span> <span><span>Michael Pidwirny (2006). <a href="http://www.physicalgeography.net/fundamentals/8o.html">"Introduction to the Oceans"</a>. <i>www.physicalgeography.net</i>. <a href="http://web.archive.org/web/20061209125035/http://www.physicalgeography.net/fundamentals/8o.html">Archived</a> from the original on 9 December 2006<span>. Retrieved <span>2006-12-07</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-2">^</a></b></span> <span><span>Tomczak, Matthias; Godfrey, J. Stuart (2003). <a href="http://www.es.flinders.edu.au/~mattom/regoc/"><i>Regional Oceanography: an Introduction</i></a> (2 ed.). Delhi: Daya Publishing House. <a href="https://en.wikipedia.org/wiki/International_Standard_Book_Number" title="International Standard Book Number">ISBN</a>&nbsp;<a href="https://en.wikipedia.org/wiki/Special:BookSources/81-7035-306-8" title="Special:BookSources/81-7035-306-8">81-7035-306-8</a>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-3">^</a></b></span> <span><span><a href="http://www.britannica.com/EBchecked/topic/33188/Arctic-Ocean/57838/Oceanography">"<span>'</span>Arctic Ocean' - Encyclopædia Britannica"</a><span>. Retrieved <span>2012-07-02</span></span>. <q>As an approximation, the Arctic Ocean may be regarded as an estuary of the Atlantic Ocean.</q></span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-4">^</a></b></span> <span>Since the beginning of the 21st century, sea ice covers only 1/3 to 1/2 the surface of the Arctic Ocean at the end of summer.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-5">^</a></b></span> <span><a href="http://psc.apl.washington.edu/HLD/Lomo/OM2001AagaardWoodgate.pdf">Some Thoughts on the Freezing and Melting of Sea Ice and Their Effects on the Ocean</a> K. Aagaard and R. A. Woodgate, Polar Science Center, Applied Physics Laboratory University of Washington, January 2001. Retrieved 7 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-6">^</a></b></span> <span><a href="http://www.win.tue.nl/~engels/discovery/pytheas.html">Pytheas</a> Andre Engels. Retrieved 16 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-7">^</a></b></span> <span><a href="http://www.channel4.com/news/articles/uk/sir+wally+herbert+dies/558357">Channel 4, "Sir Wally Herbert dies" 13 June 2007</a></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-8">^</a></b></span> <span><a href="http://www.whoi.edu/beaufortgyre/history/history_drifting.html">North Pole drifting stations (1930s–1980s)</a></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-nyt_9-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-nyt_9-1"><sup><i><b>b</b></i></sup></a></span> <span><span>Wright, John W., ed. (2006). <i>The New York Times Almanac</i> (2007 ed.). New York, New York: Penguin Books. p.&nbsp;455. <a href="https://en.wikipedia.org/wiki/International_Standard_Book_Number" title="International Standard Book Number">ISBN</a>&nbsp;<a href="https://en.wikipedia.org/wiki/Special:BookSources/0-14-303820-6" title="Special:BookSources/0-14-303820-6">0-14-303820-6</a>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-Oceans_of_the_World_10-0">^</a></b></span> <span><span><a href="http://mset.rst2.edu/portfolios/d/drewes_c/Integrating%20Technologies/Oceans%20of%20the%20World.pdf">"Oceans of the World"</a> <span>(PDF)</span>. rst2.edu<span>. Retrieved <span>2010-10-28</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-Arctic_Ocean_Fast_Facts_11-0">^</a></b></span> <span><span><a href="http://wwf.panda.org/what_we_do/where_we_work/arctic/area/species/polarbear/habitat/">"Arctic Ocean Fast Facts"</a>. wwf.pandora.org (World Wildlife Foundation). <a href="http://web.archive.org/web/20101029234119/http://wwf.panda.org/what_we_do/where_we_work/arctic/area/species/polarbear/habitat/">Archived</a> from the original on 29 October 2010<span>. Retrieved <span>2010-10-28</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-CIA_12-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-CIA_12-1"><sup><i><b>b</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-CIA_12-2"><sup><i><b>c</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-CIA_12-3"><sup><i><b>d</b></i></sup></a></span> <span><a href="https://www.cia.gov/library/publications/the-world-factbook/geos/xq.html">CIA World Fact Book: Arctic Ocean. Retrieved 11 November 2013.</a></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-13">^</a></b></span> <span><span><a href="http://www.pm.gc.ca/eng/media.asp?id=1785">"Backgrounder – Expanding Canadian Forces Operations in the Arctic"</a><span>. Retrieved <span>2007-08-17</span></span>.</span><span><span>&nbsp;</span></span> <a href="http://www.webcitation.org/query?url=http%3A%2F%2Fwww.pm.gc.ca%2Feng%2Fmedia.asp%3Fid%3D1785&amp;date=2008-08-10">mirror</a></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-14">^</a></b></span> <span><span><a href="http://www.marianatrench.com/mariana_trench-oceanography.htm">"The Mariana Trench – Oceanography"</a>. <i>www.marianatrench.com</i>. 2003-04-04. <a href="http://web.archive.org/web/20061207210451/http://www.marianatrench.com/mariana_trench-oceanography.htm">Archived</a> from the original on 7 December 2006<span>. Retrieved <span>2006-12-02</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-1"><sup><i><b>b</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-2"><sup><i><b>c</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-3"><sup><i><b>d</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-4"><sup><i><b>e</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-5"><sup><i><b>f</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-6"><sup><i><b>g</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Tomczak_15-7"><sup><i><b>h</b></i></sup></a></span> <span>[Regional Oceanography: An Introduction. Tomczak, Godfrey. Retrieved 18 November 2013.]</span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-Talley_16-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Talley_16-1"><sup><i><b>b</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Talley_16-2"><sup><i><b>c</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Talley_16-3"><sup><i><b>d</b></i></sup></a></span> <span>[Descriptive Physical Oceanography. Talley, Pickard, Emery, Swift. Retrieved 2 November 2013.]</span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-Nature_17-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Nature_17-1"><sup><i><b>b</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Nature_17-2"><sup><i><b>c</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Nature_17-3"><sup><i><b>d</b></i></sup></a></span> <span><a href="http://www.nature.com/scitable/knowledge/library/arctic-ocean-circulation-going-around-at-the-102811553">Arctic Ocean Circulation: Going Around at the Top of the World. Retrieved 2 November 2013.</a></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-Polar_18-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-Polar_18-1"><sup><i><b>b</b></i></sup></a></span> <span><a href="http://polardiscovery.whoi.edu/arctic/circulation.html">Polar Discovery: Arctic Ocean Circulation. Retrieved 2 November 2013.</a></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-19">^</a></b></span> <span><a href="http://earthobservatory.nasa.gov/Newsroom/NewImages/images.php3?img_id=17047">Continued Sea Ice Decline in 2005</a> Robert Simmon, <a href="https://en.wikipedia.org/wiki/Earth_Observatory" title="Earth Observatory">Earth Observatory</a>, and Walt Meier, <a href="https://en.wikipedia.org/wiki/NSIDC" title="NSIDC">NSIDC</a>. Retrieved 7 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-20">^</a></b></span> <span><a href="http://nsidc.org/data/seaice_index/">Sea Ice Index</a>. Nsidc.org. Retrieved on 2011-03-06.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-21">^</a></b></span> <span><a href="http://arctic.atmos.uiuc.edu/cryosphere/">Polar Sea Ice Cap and Snow – Cryosphere Today</a>. Arctic.atmos.uiuc.edu (2007-09-23). Retrieved on 2011-03-06.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-22">^</a></b></span> <span><span><a href="http://nsidc.org/seaice/intro.html">"NSIDC sea ice"</a>. <a href="http://web.archive.org/web/20100117114629/http://nsidc.org/seaice/intro.html">Archived</a> from the original on 17 January 2010<span>. Retrieved <span>2010-02-10</span></span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-Shellito2003_23-0">^</a></b></span> <span><span>Shellito, C.J.; Sloan, L.C.; Huber, M. (2003). "Climate model sensitivity to atmospheric CO<sub>2</sub> levels in the Early-Middle Paleogene". <i>Palaeogeography, Palaeoclimatology, Palaeoecology</i> <b>193</b> (1): 113–123. <a href="https://en.wikipedia.org/wiki/Digital_object_identifier" title="Digital object identifier">doi</a>:<a href="https://dx.doi.org/10.1016%2FS0031-0182%2802%2900718-6">10.1016/S0031-0182(02)00718-6</a>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-24">^</a></b></span> <span>Drill cores were recovered from the <a href="https://en.wikipedia.org/wiki/Lomonosov_Ridge" title="Lomonosov Ridge">Lomonosov Ridge</a>, presently at 87°N</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-25">^</a></b></span> <span>the <a href="https://en.wikipedia.org/wiki/Dinoflagellate" title="Dinoflagellate">dinoflagellates</a> <i>Apectodinium augustum</i></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-Sluijs2006_26-0">^</a></b></span> <span><span>Sluijs, A.; Schouten, S.; Pagani, M.; Woltering, M.; Brinkhuis, H.; Damsté, J.S.S.; Dickens, G.R.; Huber, M.; Reichart, G.J.; Stein, R. et al. (2006). "Subtropical Arctic Ocean temperatures during the Palaeocene/Eocene thermal maximum". <i>Nature</i> <b>441</b> (7093): 610–613. <a href="https://en.wikipedia.org/wiki/Digital_object_identifier" title="Digital object identifier">doi</a>:<a href="https://dx.doi.org/10.1038%2Fnature04668">10.1038/nature04668</a>. <a href="https://en.wikipedia.org/wiki/PubMed_Identifier" title="PubMed Identifier">PMID</a>&nbsp;<a href="https://www.ncbi.nlm.nih.gov/pubmed/16752441">16752441</a>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-27">^</a></b></span> <span><a href="http://www.sciencenews.org/view/generic/id/341342/title/Microbes_flourish_under_Arctic_sea_ice"><i>Microbes flourish under Arctic sea ice; Scientists shocked to find phytoplankton thriving under frozen surface</i></a> July 28th, 2012; Vol.182 #2 (p. 17) <a href="https://en.wikipedia.org/wiki/Science_News" title="Science News">Science News</a></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-NOAA_28-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-NOAA_28-1"><sup><i><b>b</b></i></sup></a></span> <span><a href="http://oceanexplorer.noaa.gov/explorations/02arctic/background/physical/physical.html">Physical Nutrients and Primary Productivity</a> Professor Terry Whiteledge. National Oceanic and Atmospheric Administration. Retrieved 7 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-29">^</a></b></span> <span><a href="http://news.bbc.co.uk/2/hi/business/4354036.stm#map">The Arctic's New Gold Rush – BBC</a></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-30">^</a></b></span> <span><a href="http://www.oxfordenergy.org/wpcms/wp-content/uploads/2011/01/Aug2007-TheBattleforthenextenergyfrontier-ShamilYenikeyeff-and-TimothyFentonKrysiek.pdf">The Battle for the Next Energy Frontier: The Russian Polar Expedition and the Future of Arctic Hydrocarbons</a>, by Shamil Yenikeyeff and Timothy Fenton Krysiek, <a href="https://en.wikipedia.org/wiki/Oxford_Institute_for_Energy_Studies" title="Oxford Institute for Energy Studies">Oxford Institute for Energy Studies</a>, August 2007</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-31">^</a></b></span> <span><a href="http://www.ec.gc.ca/cleanair-airpur/Linking_Today_into_Tomorrow-WS4D339983-1_En.htm">Clean Air Online – Linking Today into Tomorrow</a></span></li> 
<li><span>^ <a href="https://en.wikipedia.org/wiki#cite_ref-R.Black_32-0"><sup><i><b>a</b></i></sup></a> <a href="https://en.wikipedia.org/wiki#cite_ref-R.Black_32-1"><sup><i><b>b</b></i></sup></a></span> <span><a href="http://news.bbc.co.uk/2/hi/science/nature/4315968.stm">Earth – melting in the heat?</a> Richard Black, 7 October 2005. BBC News. Retrieved 7 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-33">^</a></b></span> <span><a href="http://www.theaustralian.news.com.au/story/0,25197,24659919-2703,00.html">Russia the next climate recalcitrant</a> Peter Wilson, 17 November 2008, <a href="https://en.wikipedia.org/wiki/The_Australian" title="The Australian">The Australian</a>. Retrieved 2 February 2009.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-CC03513_34-0">^</a></b></span> <span><span>Lauren Morello (March 5, 2013). <a href="http://www.climatecentral.org/news/warmer-arctic-with-less-ice-increases-storm-surge-15689">"Warmer Arctic with Less Ice Increases Storm Surge"</a>. <i>Climate Central</i><span>. Retrieved <span>March 8,</span> 2013</span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-35">^</a></b></span> <span><a href="http://bellona.org/english_import_area/international/russia/nuke_industry/siberia/mayak/21636">400 million cubic meters of radioactive waste threaten the Arctic area</a> Thomas Nilsen, Bellona, 24 August 2001. Retrieved 7 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-36">^</a></b></span> <span><a href="http://www.gso.uri.edu/maritimes/Text_Only/00Summer/text/arctic.html">Plutonium in the Russian Arctic, or How We Learned to Love the Bomb</a> Bradley Moran, John N. Smith. Retrieved 7 December 2006.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-37">^</a></b></span> <span>Tim Phillips, <a href="http://activistdefense.wordpress.com/2012/07/11/alaska-natives-sue-federal-government-for-approving-shells-insufficient-clean-up-plan-for-a-potential-oil-spill-in-the-arctic-ocean/">"Alaska Natives Sue Federal Government for Approving Shell's Insufficient Clean-Up Plan for a Potential Oil Spill in the Arctic Ocean"</a>, Activist Defense, July 11, 2012.</span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-38">^</a></b></span> <span><span><a href="http://www.bbc.com/news/world-europe-33549606">"Arctic deal bans North Pole fishing"</a>. BBC News. 16 July 2015<span>. Retrieved <span>16 July</span> 2015</span>.</span><span><span>&nbsp;</span></span></span></li> 
<li><span><b><a href="https://en.wikipedia.org/wiki#cite_ref-39">^</a></b></span> <span><span>Rosen, Yereth (16 July 2015). <a href="https://www.adn.com/article/20150716/5-nations-sign-declaration-protect-arctic-donut-hole-unregulated-fishing">"5 nations sign declaration to protect Arctic 'donut hole' from unregulated fishing"</a>. Alaska Dispatch News<span>. Retrieved <span>16 July</span> 2015</span>.</span><span><span>&nbsp;</span></span></span></li> 
</ol> 
</div> 
<h2><span>Further reading</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=20" title="Edit section: Further reading">edit</a><span>]</span></span></h2> 
<ul> 
<li>Neatby, Leslie H., <i>Discovery in Russian and Siberian Waters</i> 1973 <a href="https://en.wikipedia.org/wiki/Special:BookSources/0821401246">ISBN 0-8214-0124-6</a></li> 
<li>Ray, L., and bacon, B., eds., <i>The Arctic Ocean</i> 1982 <a href="https://en.wikipedia.org/wiki/Special:BookSources/0333310179">ISBN 0-333-31017-9</a></li> 
<li>Thorén, Ragnar V. A., <i>Picture Atlas of the Arctic</i> 1969 <a href="https://en.wikipedia.org/wiki/Special:BookSources/0821401246">ISBN 0-8214-0124-6</a></li> 
</ul> 
<h2><span>External links</span><span><span>[</span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit&amp;section=21" title="Edit section: External links">edit</a><span>]</span></span></h2> 
<table> 
<tbody>
<tr> 
<td><img alt="" src="https://upload.wikimedia.org/wikipedia/en/thumb/4/4a/Commons-logo.svg/30px-Commons-logo.svg.png" width="30" height="40"></td> 
<td>Wikimedia Commons has media related to <i><b><a href="https://commons.wikimedia.org/wiki/Category:Arctic_Ocean" title="commons:Category:Arctic Ocean">Arctic Ocean</a></b></i>.</td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Wiktionary-logo-en.svg/37px-Wiktionary-logo-en.svg.png" width="37" height="40"></td> 
<td>Look up <i><b><a href="https://en.wiktionary.org/wiki/Special:Search/arctic_ocean" title="wiktionary:Special:Search/arctic ocean">arctic ocean</a></b></i> in Wiktionary, the free dictionary.</td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/38px-Wikisource-logo.svg.png" width="38" height="40"></td> 
<td><a href="https://en.wikipedia.org/wiki/Wikisource" title="Wikisource">Wikisource</a> has original text related to this article: 
<div>
<b><a href="https://en.wikisource.org/wiki/CIA_World_Fact_Book,_2004/Arctic_Ocean" title="wikisource:CIA World Fact Book, 2004/Arctic Ocean">CIA World Fact Book, 2004/Arctic Ocean</a></b>
</div> </td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<th><a href="https://tools.wmflabs.org/osm4wiki/cgi-bin/wiki/wiki-osm.pl?project=en&amp;article=Arctic_Ocean">Map all coordinates using OSM</a><br> <a href="https://tools.wmflabs.org/kmlexport?article=Arctic_Ocean&amp;redir=bing">Map up to 200 coordinates using Bing</a></th> 
</tr> 
<tr> 
<td><a href="https://tools.wmflabs.org/kmlexport?article=Arctic_Ocean">Export all coordinates</a> as <a href="https://en.wikipedia.org/wiki/Keyhole_Markup_Language" title="Keyhole Markup Language">KML</a></td> 
</tr> 
<tr> 
<td><a href="http://maps.bing.com/GeoCommunity.asjx?action=retrieverss&amp;mkt=en&amp;mapurl=http%3A%2F%2Ftools.wmflabs.org%2Fkmlexport%3Farticle%3DArctic_Ocean">Export all coordinates</a> as <a href="https://en.wikipedia.org/wiki/GeoRSS" title="GeoRSS">GeoRSS</a></td> 
</tr> 
<tr> 
<td><a href="http://tools.tripgang.com/kml2gpx/http%3A%2F%2Ftools.wmflabs.org%2Fkmlexport%3Farticle%3DArctic_Ocean?gpx=1">Export all coordinates</a> as <a href="https://en.wikipedia.org/wiki/GPS_eXchange_Format" title="GPS eXchange Format">GPX</a></td> 
</tr> 
<tr> 
<td><a href="http://maps.google.com/maps?q=http%3A%2F%2Fmicroform.at%2Fgeo%2Fhttp%3A%2F%2Fen.wikipedia.org%2Fwiki%2FArctic_Ocean">Map all microformatted coordinates</a></td> 
</tr> 
<tr> 
<td><a href="http://microform.at/?type=hcard-rdf&amp;url=http://en.wikipedia.org/wiki/Arctic_Ocean">Place data as RDF</a></td> 
</tr> 
</tbody>
</table> 
<ul> 
<li><a href="http://oceanexplorer.noaa.gov/explorations/05arctic/welcome.html">The Hidden Ocean Arctic 2005</a> Daily logs, photos and video from exploration mission.</li> 
<li><a href="http://www.whoi.edu/imageOfDay.do">Oceanography Image of the Day</a>, from the <a href="https://en.wikipedia.org/wiki/Woods_Hole_Oceanographic_Institution" title="Woods Hole Oceanographic Institution">Woods Hole Oceanographic Institution</a></li> 
<li><a href="http://www.arctic-council.org">Arctic Council</a></li> 
<li><a href="http://www.northernforum.org">The Northern Forum</a></li> 
<li><a href="http://vitalgraphics.grida.no/arcticmap">Arctic Environmental Atlas</a> Interactive map</li> 
<li><a href="http://www.arctic.noaa.gov">NOAA Arctic Theme Page</a></li> 
<li><a href="https://www.cia.gov/library/publications/the-world-factbook/geos/xq.html">Arctic Ocean</a> entry at <i><a href="https://en.wikipedia.org/wiki/The_World_Factbook" title="The World Factbook">The World Factbook</a></i></li> 
<li><a href="http://nsidc.org/data/nsidc-0060.html">Daily Arctic Ocean Rawinsonde Data from Soviet Drifting Ice Stations (1954–1990)</a> at NSIDC</li> 
<li><a href="http://www.arctic.noaa.gov/gallery_np.html">NOAA North Pole Web Cam</a> Images from Web Cams deployed in spring on an ice floe</li> 
<li><a href="http://www.arctic.noaa.gov/gallery_np_weatherdata.html">NOAA Near-realtime North Pole Weather Data</a> Data from instruments deployed on an ice floe</li> 
<li><a href="http://www.wired.com/news/technology/0,1282,63980,00.html"><i>Search for Arctic Life Heats Up</i> by Stephen Leahy</a></li> 
<li><a href="http://www.polarfoundation.org/">International Polar Foundation</a></li> 
<li><a href="http://nsidc.org/arcticseaicenews/">National Snow and Ice Data Center – Daily report of Arctic ice cover based on satellite data</a></li> 
<li><a href="http://www.marbef.org/wiki/Arctic_Ocean">Marine Biodiversity Wiki</a></li> 
</ul> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:Arctic_topics" title="Template:Arctic topics"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:Arctic_topics" title="Template talk:Arctic topics"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:Arctic_topics&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> 
<div>
<a href="https://en.wikipedia.org/wiki/Arctic" title="Arctic">Arctic</a> topics
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Category:History_of_the_Arctic" title="Category:History of the Arctic">History</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Category:Arctic_research" title="Category:Arctic research">Arctic research</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Exploration_of_the_Arctic" title="Category:Exploration of the Arctic">Exploration of the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/History_of_whaling" title="History of whaling">History of whaling</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Category:Government_of_the_Arctic" title="Category:Government of the Arctic">Government</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Council" title="Arctic Council">Arctic Council</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_cooperation_and_politics" title="Arctic cooperation and politics">Arctic cooperation and politics</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Ocean_Conference" title="Arctic Ocean Conference">Arctic Ocean Conference</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Chief_Directorate_of_the_Northern_Sea_Route" title="Chief Directorate of the Northern Sea Route">Chief Directorate of the Northern Sea Route</a></li> 
<li><a href="https://en.wikipedia.org/wiki/United_Nations_Convention_on_the_Law_of_the_Sea" title="United Nations Convention on the Law of the Sea">United Nations Convention on the Law of the Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ilulissat_Declaration" title="Ilulissat Declaration">Ilulissat Declaration</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Inuit_Circumpolar_Council" title="Inuit Circumpolar Council">Inuit Circumpolar Council</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Saami_Council" title="Saami Council">Saami Council</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Territorial_claims_in_the_Arctic" title="Territorial claims in the Arctic">Territorial claims in the Arctic</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Category:Geography_of_the_Arctic" title="Category:Geography of the Arctic">Geography</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Circle" title="Arctic Circle">Arctic Circle</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_ecology" title="Arctic ecology">Arctic ecology</a></li> 
<li><strong>Arctic Ocean</strong></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Arctic_geography_terminology" title="Category:Arctic geography terminology">Arctic geography terminology</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Greenland_ice_sheet" title="Greenland ice sheet">Greenland ice sheet</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Impact_craters_of_the_Arctic" title="Category:Impact craters of the Arctic">Impact craters of the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/North_Pole" title="North Pole">North Pole</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Populated_places_in_the_Arctic" title="Category:Populated places in the Arctic">Populated places in the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Tundra" title="Tundra">Tundra</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nordicity" title="Nordicity">Nordicity</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Category:Regions_of_the_Arctic" title="Category:Regions of the Arctic">Regions</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Alaska" title="Arctic Alaska">Arctic Alaska</a></li> 
<li><a href="https://en.wikipedia.org/wiki/British_Arctic_Territories" title="British Arctic Territories">British Arctic Territories</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Canadian_Arctic_Archipelago" title="Canadian Arctic Archipelago">Canadian Arctic Archipelago</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Finnmark" title="Finnmark">Finnmark</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Greenland" title="Greenland">Greenland</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northern_Canada" title="Northern Canada">Northern Canada</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northwest_Territories" title="Northwest Territories">Northwest Territories</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nunavik" title="Nunavik">Nunavik</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nunavut" title="Nunavut">Nunavut</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Russian_Arctic" title="Russian Arctic">Russian Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/S%C3%A1pmi_(area)" title="Sápmi (area)">Sápmi (area)</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yukon" title="Yukon">Yukon</a></li> 
<li><a href="https://en.wikipedia.org/wiki/North_American_Arctic" title="North American Arctic">North American Arctic</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Climate_of_the_Arctic" title="Climate of the Arctic">Climate</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Climate_Impact_Assessment" title="Arctic Climate Impact Assessment">Arctic Climate Impact Assessment</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_dipole_anomaly" title="Arctic dipole anomaly">Arctic dipole anomaly</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_sea_ice_ecology_and_history" title="Arctic sea ice ecology and history">Arctic sea ice ecology and history</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_ice_pack" title="Arctic ice pack">Arctic ice pack</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_sea_ice_decline" title="Arctic sea ice decline">Arctic sea ice decline</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Climate_of_Alaska" title="Climate of Alaska">Climate of Alaska</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Polar_climate" title="Polar climate">Polar climate</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Effects_of_climate_change_on_marine_mammals" title="Effects of climate change on marine mammals">Effects of climate change on marine mammals</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Polar_amplification" title="Polar amplification">Polar amplification</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Fauna" title="Fauna">Fauna</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Walrus" title="Walrus">Walrus</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Narwhal" title="Narwhal">Narwhal</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bowhead_whale" title="Bowhead whale">Bowhead whale</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Polar_bear" title="Polar bear">Polar bear</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_fox" title="Arctic fox">Arctic fox</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Snowy_owl" title="Snowy owl">Snowy owl</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Reindeer" title="Reindeer">Reindeer</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Beluga_whale" title="Beluga whale">Beluga whale</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Lemming" title="Lemming">Lemming</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Muskox" title="Muskox">Muskox</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ribbon_seal" title="Ribbon seal">Ribbon seal</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bearded_seal" title="Bearded seal">Bearded seal</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Hooded_seal" title="Hooded seal">Hooded seal</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Harp_seal" title="Harp seal">Harp seal</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ringed_seal" title="Ringed seal">Ringed seal</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Culture" title="Culture">Culture</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Evenks" title="Evenks">Evenks</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Inuit" title="Inuit">Inuit</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Chukotka_Autonomous_Okrug" title="Chukotka Autonomous Okrug">Chukotka</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Koryaks" title="Koryaks">Koryaks</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nenets_people" title="Nenets people">Nenets</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Khanty_people" title="Khanty people">Khanty</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Chukchi_people" title="Chukchi people">Chukchi</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sami_people" title="Sami people">Sami</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yukaghir_people" title="Yukaghir people">Yukaghir people</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row">Economy</th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Refuge_drilling_controversy" title="Arctic Refuge drilling controversy">Arctic Refuge drilling controversy</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Protected_areas_of_the_Arctic" title="Category:Protected areas of the Arctic">Parks, reserves and refuges</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Category:Transport_in_the_Arctic" title="Category:Transport in the Arctic">Transportation in the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Petroleum_exploration_in_the_Arctic" title="Petroleum exploration in the Arctic">Petroleum exploration in the Arctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Natural_resources_of_the_Arctic" title="Natural resources of the Arctic">Natural resources of the Arctic</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Category:Transport_in_the_Arctic" title="Category:Transport in the Arctic">Transport</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_shipping_routes" title="Arctic shipping routes">Arctic shipping routes</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Bridge" title="Arctic Bridge">Arctic Bridge</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northeast_Passage" title="Northeast Passage">Northeast Passage</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northwest_Passage" title="Northwest Passage">Northwest Passage</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northern_Sea_Route" title="Northern Sea Route">Northern Sea Route</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Transpolar_Sea_Route" title="Transpolar Sea Route">Transpolar Sea Route</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Polar_route" title="Polar route">Polar air route</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_Search_and_Rescue_Agreement" title="Arctic Search and Rescue Agreement">Search and rescue</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div> 
<ul> 
<li><b><img alt="Category" src="https://upload.wikimedia.org/wikipedia/en/thumb/4/48/Folder_Hexagonal_Icon.svg/16px-Folder_Hexagonal_Icon.svg.png" title="Category" width="16" height="14"> <a href="https://en.wikipedia.org/wiki/Category:Arctic" title="Category:Arctic">Category</a></b></li> 
<li><b><img alt="Portal" src="https://upload.wikimedia.org/wikipedia/en/thumb/f/fd/Portal-puzzle.svg/16px-Portal-puzzle.svg.png" title="Portal" width="16" height="14"> <a href="https://en.wikipedia.org/wiki/Portal:Arctic" title="Portal:Arctic">Portal</a></b></li> 
<li><b><img alt="WikiProject" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/People_icon.svg/16px-People_icon.svg.png" title="WikiProject" width="16" height="16"> <a href="https://en.wikipedia.org/wiki/Wikipedia:WikiProject_Arctic" title="Wikipedia:WikiProject Arctic">WikiProject</a></b></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:List_of_seas" title="Template:List of seas"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:List_of_seas" title="Template talk:List of seas"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:List_of_seas&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> 
<div>
<a href="https://en.wikipedia.org/wiki/Earth" title="Earth">Earth</a>'s 
<a href="https://en.wikipedia.org/wiki/Ocean" title="Ocean">oceans</a> and 
<a href="https://en.wikipedia.org/wiki/List_of_seas" title="List of seas">seas</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><strong>Arctic Ocean</strong></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Amundsen_Gulf" title="Amundsen Gulf">Amundsen Gulf</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Barents_Sea" title="Barents Sea">Barents Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Beaufort_Sea" title="Beaufort Sea">Beaufort Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Chukchi_Sea" title="Chukchi Sea">Chukchi Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/East_Siberian_Sea" title="East Siberian Sea">East Siberian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Greenland_Sea" title="Greenland Sea">Greenland Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Boothia" title="Gulf of Boothia">Gulf of Boothia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Kara_Sea" title="Kara Sea">Kara Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Laptev_Sea" title="Laptev Sea">Laptev Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Lincoln_Sea" title="Lincoln Sea">Lincoln Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Prince_Gustav_Adolf_Sea" title="Prince Gustav Adolf Sea">Prince Gustav Adolf Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pechora_Sea" title="Pechora Sea">Pechora Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wandel_Sea" title="Wandel Sea">Wandel Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/White_Sea" title="White Sea">White Sea</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Atlantic_Ocean" title="Atlantic Ocean">Atlantic Ocean</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Adriatic_Sea" title="Adriatic Sea">Adriatic Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Aegean_Sea" title="Aegean Sea">Aegean Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alboran_Sea" title="Alboran Sea">Alboran Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Archipelago_Sea" title="Archipelago Sea">Archipelago Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Argentine_Sea" title="Argentine Sea">Argentine Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Baffin_Bay" title="Baffin Bay">Baffin Bay</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Balearic_Sea" title="Balearic Sea">Balearic Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Baltic_Sea" title="Baltic Sea">Baltic Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bay_of_Biscay" title="Bay of Biscay">Bay of Biscay</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bothnian_Bay" title="Bothnian Bay">Bay of Bothnia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bay_of_Campeche" title="Bay of Campeche">Bay of Campeche</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bay_of_Fundy" title="Bay of Fundy">Bay of Fundy</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Black_Sea" title="Black Sea">Black Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bothnian_Sea" title="Bothnian Sea">Bothnian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Caribbean_Sea" title="Caribbean Sea">Caribbean Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Celtic_Sea" title="Celtic Sea">Celtic Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/English_Channel" title="English Channel">English Channel</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Foxe_Basin" title="Foxe Basin">Foxe Basin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Greenland_Sea" title="Greenland Sea">Greenland Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Bothnia" title="Gulf of Bothnia">Gulf of Bothnia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Finland" title="Gulf of Finland">Gulf of Finland</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Lion" title="Gulf of Lion">Gulf of Lion</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Guinea" title="Gulf of Guinea">Gulf of Guinea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Maine" title="Gulf of Maine">Gulf of Maine</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Mexico" title="Gulf of Mexico">Gulf of Mexico</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Saint_Lawrence" title="Gulf of Saint Lawrence">Gulf of Saint Lawrence</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Sidra" title="Gulf of Sidra">Gulf of Sidra</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Venezuela" title="Gulf of Venezuela">Gulf of Venezuela</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Hudson_Bay" title="Hudson Bay">Hudson Bay</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ionian_Sea" title="Ionian Sea">Ionian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Irish_Sea" title="Irish Sea">Irish Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Irminger_Sea" title="Irminger Sea">Irminger Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/James_Bay" title="James Bay">James Bay</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Labrador_Sea" title="Labrador Sea">Labrador Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Levantine_Sea" title="Levantine Sea">Levantine Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Libyan_Sea" title="Libyan Sea">Libyan Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ligurian_Sea" title="Ligurian Sea">Ligurian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_Marmara" title="Sea of Marmara">Marmara Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mediterranean_Sea" title="Mediterranean Sea">Mediterranean Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Myrtoan_Sea" title="Myrtoan Sea">Myrtoan Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/North_Sea" title="North Sea">North Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Norwegian_Sea" title="Norwegian Sea">Norwegian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sargasso_Sea" title="Sargasso Sea">Sargasso Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_%C3%85land" title="Sea of Åland">Sea of Åland</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_Azov" title="Sea of Azov">Sea of Azov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_Crete" title="Sea of Crete">Sea of Crete</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_the_Hebrides" title="Sea of the Hebrides">Sea of the Hebrides</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Thracian_Sea" title="Thracian Sea">Thracian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Tyrrhenian_Sea" title="Tyrrhenian Sea">Tyrrhenian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wadden_Sea" title="Wadden Sea">Wadden Sea</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Indian_Ocean" title="Indian Ocean">Indian Ocean</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Andaman_Sea" title="Andaman Sea">Andaman Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arabian_Sea" title="Arabian Sea">Arabian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bay_of_Bengal" title="Bay of Bengal">Bay of Bengal</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Tadjoura" title="Gulf of Tadjoura">Gulf of Tadjoura</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Aden" title="Gulf of Aden">Gulf of Aden</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Aqaba" title="Gulf of Aqaba">Gulf of Aqaba</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Khambhat" title="Gulf of Khambhat">Gulf of Khambhat</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Kutch" title="Gulf of Kutch">Gulf of Kutch</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Oman" title="Gulf of Oman">Gulf of Oman</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Suez" title="Gulf of Suez">Gulf of Suez</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Laccadive_Sea" title="Laccadive Sea">Laccadive Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mozambique_Channel" title="Mozambique Channel">Mozambique Channel</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Persian_Gulf" title="Persian Gulf">Persian Gulf</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Red_Sea" title="Red Sea">Red Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Timor_Sea" title="Timor Sea">Timor Sea</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Pacific_Ocean" title="Pacific Ocean">Pacific Ocean</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Arafura_Sea" title="Arafura Sea">Arafura Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bali_Sea" title="Bali Sea">Bali Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Banda_Sea" title="Banda Sea">Banda Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bering_Sea" title="Bering Sea">Bering Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bismarck_Sea" title="Bismarck Sea">Bismarck Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bohai_Sea" title="Bohai Sea">Bohai Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bohol_Sea" title="Bohol Sea">Bohol Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Camotes_Sea" title="Camotes Sea">Camotes Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Celebes_Sea" title="Celebes Sea">Celebes Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ceram_Sea" title="Ceram Sea">Ceram Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Chilean_Sea" title="Chilean Sea">Chilean Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Coral_Sea" title="Coral Sea">Coral Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/East_China_Sea" title="East China Sea">East China Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Flores_Sea" title="Flores Sea">Flores Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Alaska" title="Gulf of Alaska">Gulf of Alaska</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Anadyr" title="Gulf of Anadyr">Gulf of Anadyr</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_California" title="Gulf of California">Gulf of California</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Carpentaria" title="Gulf of Carpentaria">Gulf of Carpentaria</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Fonseca" title="Gulf of Fonseca">Gulf of Fonseca</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Panama" title="Gulf of Panama">Gulf of Panama</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Thailand" title="Gulf of Thailand">Gulf of Thailand</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gulf_of_Tonkin" title="Gulf of Tonkin">Gulf of Tonkin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Halmahera_Sea" title="Halmahera Sea">Halmahera Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Java_Sea" title="Java Sea">Java Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Koro_Sea" title="Koro Sea">Koro Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mar_de_Grau" title="Mar de Grau">Mar de Grau</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Molucca_Sea" title="Molucca Sea">Molucca Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Moro_Gulf" title="Moro Gulf">Moro Gulf</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Philippine_Sea" title="Philippine Sea">Philippine Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Salish_Sea" title="Salish Sea">Salish Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Savu_Sea" title="Savu Sea">Savu Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_Japan" title="Sea of Japan">Sea of Japan</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sea_of_Okhotsk" title="Sea of Okhotsk">Sea of Okhotsk</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Seto_Inland_Sea" title="Seto Inland Sea">Seto Inland Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sibuyan_Sea" title="Sibuyan Sea">Sibuyan Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Solomon_Sea" title="Solomon Sea">Solomon Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/South_China_Sea" title="South China Sea">South China Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sulu_Sea" title="Sulu Sea">Sulu Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Tasman_Sea" title="Tasman Sea">Tasman Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Visayan_Sea" title="Visayan Sea">Visayan Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yellow_Sea" title="Yellow Sea">Yellow Sea</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Southern_Ocean" title="Southern Ocean">Southern Ocean</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Amundsen_Sea" title="Amundsen Sea">Amundsen Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bellingshausen_Sea" title="Bellingshausen Sea">Bellingshausen Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Cooperation_Sea" title="Cooperation Sea">Cooperation Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Cosmonauts_Sea" title="Cosmonauts Sea">Cosmonauts Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Davis_Sea" title="Davis Sea">Davis Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/D%27Urville_Sea" title="D'Urville Sea">D'Urville Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Great_Australian_Bight" title="Great Australian Bight">Great Australian Bight</a></li> 
<li><a href="https://en.wikipedia.org/wiki/King_Haakon_VII_Sea" title="King Haakon VII Sea">King Haakon VII Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Lazarev_Sea" title="Lazarev Sea">Lazarev Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Riiser-Larsen_Sea" title="Riiser-Larsen Sea">Riiser-Larsen Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mawson_Sea" title="Mawson Sea">Mawson Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ross_Sea" title="Ross Sea">Ross Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Scotia_Sea" title="Scotia Sea">Scotia Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Somov_Sea" title="Somov Sea">Somov Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Weddell_Sea" title="Weddell Sea">Weddell Sea</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row">Landlocked seas</th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Aral_Sea" title="Aral Sea">Aral Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Caspian_Sea" title="Caspian Sea">Caspian Sea</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Dead_Sea" title="Dead Sea">Dead Sea</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div>
<b><img alt="Wikipedia book" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Symbol_book_class2.svg/16px-Symbol_book_class2.svg.png" title="Wikipedia book" width="16" height="16"> <a href="https://en.wikipedia.org/wiki/Book:Seas" title="Book:Seas">Book</a></b>&nbsp;
<b>·</b> 
<b><img alt="Category" src="https://upload.wikimedia.org/wikipedia/en/thumb/4/48/Folder_Hexagonal_Icon.svg/16px-Folder_Hexagonal_Icon.svg.png" title="Category" width="16" height="14"> <a href="https://en.wikipedia.org/wiki/Category:Seas" title="Category:Seas">Category</a></b>
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:Regions_of_the_world" title="Template:Regions of the world"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:Regions_of_the_world" title="Template talk:Regions of the world"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:Regions_of_the_world&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> 
<div>
<a href="https://en.wikipedia.org/wiki/United_Nations_statistical_divisions" title="United Nations statistical divisions">Regions</a> of the 
<a href="https://en.wikipedia.org/wiki/Earth" title="Earth">world</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div> 
<table> 
<tbody>
<tr> 
<td> 
<div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Africa" title="Africa"><img alt="LocationAfrica.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/LocationAfrica.png/60px-LocationAfrica.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Africa" title="Africa">Africa</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/North_Africa" title="North Africa">Northern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Maghreb" title="Maghreb">Maghreb</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Sub-Saharan_Africa" title="Sub-Saharan Africa">Sub-Saharan</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/West_Africa" title="West Africa">Western</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/East_Africa" title="East Africa">East</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Central_Africa" title="Central Africa">Central</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Southern_Africa" title="Southern Africa">Southern</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Horn_of_Africa" title="Horn of Africa">Horn</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Islands_of_Africa" title="Islands of Africa">Islands</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/North_America" title="North America"><img alt="LocationNorthAmerica.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationNorthAmerica.png/60px-LocationNorthAmerica.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/North_America" title="North America">North<br> America</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Northern_America" title="Northern America">Northern</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Caribbean" title="Caribbean">Caribbean</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Central_America" title="Central America">Central</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Middle_America_(Americas)" title="Middle America (Americas)">Middle</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Anglo-America" title="Anglo-America">Anglo</a></li> 
<li><a href="https://en.wikipedia.org/wiki/French_America" title="French America">French</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Latin_America" title="Latin America">Latin</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Hispanic_America" title="Hispanic America">Hispanic</a></span>)</li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/South_America" title="South America"><img alt="LocationSouthAmerica.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/LocationSouthAmerica.png/60px-LocationSouthAmerica.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/South_America" title="South America">South<br> America</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Cone" title="Southern Cone">Southern</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northern_South_America" title="Northern South America">Northern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/The_Guianas" title="The Guianas">Guianan states</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Andean_states" title="Andean states">Western</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Latin_America" title="Latin America">Latin</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Hispanic_America" title="Hispanic America">Hispanic</a></span>)</li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Asia" title="Asia"><img alt="LocationAsia.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/LocationAsia.svg/60px-LocationAsia.svg.png" width="60" height="30"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Asia" title="Asia">Asia</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Central_Asia" title="Central Asia">Central</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Far_East" title="Far East">Far East</a></li> 
<li><a href="https://en.wikipedia.org/wiki/East_Asia" title="East Asia">Eastern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Northeast_Asia" title="Northeast Asia">Northeastern</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Southeast_Asia" title="Southeast Asia">Southeastern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Mainland_Southeast_Asia" title="Mainland Southeast Asia">Mainland</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Maritime_Southeast_Asia" title="Maritime Southeast Asia">Maritime</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/North_Asia" title="North Asia">Northern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Siberia" title="Siberia">Siberia</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/South_Asia" title="South Asia">Southern</a>&nbsp;(<span><a href="https://en.wikipedia.org/wiki/Indian_subcontinent" title="Indian subcontinent">Indian subcontinent</a></span>)</li> 
<li><a href="https://en.wikipedia.org/wiki/Western_Asia" title="Western Asia">Western</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/South_Caucasus" title="South Caucasus">South Caucasus</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Middle_East" title="Middle East">Middle East</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Near_East" title="Near East">Near East</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Asia-Pacific" title="Asia-Pacific">Asia-Pacific</a></li> 
</ul> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
<td> 
<div> 
<table> 
<tbody>
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Europe" title="Europe"><img alt="LocationEurope.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/LocationEurope.png/60px-LocationEurope.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Europe" title="Europe">Europe</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Central_Europe" title="Central Europe">Central</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Northern_Europe" title="Northern Europe">Northern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Nordic_countries" title="Nordic countries">Nordic</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Scandinavia" title="Scandinavia">Scandinavia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Scandinavian_Peninsula" title="Scandinavian Peninsula">Scandinavian Peninsula</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Baltic_countries" title="Baltic countries">Baltic</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Eastern_Europe" title="Eastern Europe">Eastern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Southeast_Europe" title="Southeast Europe">Southeastern</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Balkans" title="Balkans">Balkans</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/North_Caucasus" title="North Caucasus">North Caucasus</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Middle_East" title="Middle East">Middle East</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Europe" title="Southern Europe">Southern</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Iberian_Peninsula" title="Iberian Peninsula">Iberia</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Western_Europe" title="Western Europe">Western</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Northwestern_Europe" title="Northwestern Europe">Northwestern</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/British_Isles" title="British Isles">British Isles</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Germanic-speaking_Europe" title="Germanic-speaking Europe">Germanic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Romance-speaking_Europe" title="Romance-speaking Europe">Romance</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Oceania" title="Oceania"><img alt="LocationOceania.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/LocationOceania.png/60px-LocationOceania.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Oceania" title="Oceania">Oceania</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Australasia" title="Australasia">Australasia</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Australia_(continent)" title="Australia (continent)">Australia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/New_Guinea" title="New Guinea">New Guinea</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Zealandia_(continent)" title="Zealandia (continent)">Zealandia</a></span></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Pacific_Islands" title="Pacific Islands">Pacific Islands</a> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Micronesia" title="Micronesia">Micronesia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Melanesia" title="Melanesia">Melanesia</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Polynesia" title="Polynesia">Polynesia</a></span></li> 
</ul> </li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Polar_regions_of_Earth" title="Polar regions of Earth"><img alt="LocationPolarRegions.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/LocationPolarRegions.png/60px-LocationPolarRegions.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Polar_regions_of_Earth" title="Polar regions of Earth">Polar</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Antarctic" title="Antarctic">Antarctic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic" title="Arctic">Arctic</a></li> 
</ul> </td> 
</tr> 
<tr> 
<td><a href="https://en.wikipedia.org/wiki/Ocean" title="Ocean"><img alt="LocationOceans.png" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/LocationOceans.png/60px-LocationOceans.png" width="60" height="31"></a></td> 
<td><a href="https://en.wikipedia.org/wiki/Ocean" title="Ocean">Oceans</a></td> 
<td> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Sea" title="Sea">World (Sea)</a></li> 
<li><strong>Arctic</strong></li> 
<li><a href="https://en.wikipedia.org/wiki/Atlantic_Ocean" title="Atlantic Ocean">Atlantic</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Indian_Ocean" title="Indian Ocean">Indian</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pacific_Ocean" title="Pacific Ocean">Pacific</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Southern_Ocean" title="Southern Ocean">Southern</a></li> 
<li><a href="https://en.wikipedia.org/wiki/List_of_seas" title="List of seas">List of seas</a></li> 
</ul> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
</tbody>
</table> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div> 
<ul> 
<li><img alt="Template" src="https://upload.wikimedia.org/wikipedia/en/thumb/5/5c/Symbol_template_class.svg/16px-Symbol_template_class.svg.png" title="Template" width="16" height="16"> <a href="https://en.wikipedia.org/wiki/Template:Continents_of_the_world" title="Template:Continents of the world">Continents of the world</a>&nbsp;/ <a href="https://en.wikipedia.org/wiki/Template:List_of_seas" title="Template:List of seas">List of seas</a>&nbsp;/ <a href="https://en.wikipedia.org/wiki/Template:Physical_Earth" title="Template:Physical Earth">Physical Earth</a></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Template:Polar_exploration" title="Template:Polar exploration"><span>v</span></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Template_talk:Polar_exploration" title="Template talk:Polar exploration"><span>t</span></a></li> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Template:Polar_exploration&amp;action=edit"><span>e</span></a></li> 
</ul> 
</div> 
<div>
<a href="https://en.wikipedia.org/wiki/List_of_polar_explorers" title="List of polar explorers">Polar exploration</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"><span>&nbsp;</span> 
<div>
<a href="https://en.wikipedia.org/wiki/Arctic" title="Arctic">Arctic</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<td colspan="2"> 
<div> 
<ul> 
<li><strong>Ocean</strong></li> 
<li><a href="https://en.wikipedia.org/wiki/Arctic_exploration" title="Arctic exploration">History</a></li> 
<li><a href="https://en.wikipedia.org/wiki/List_of_Arctic_expeditions" title="List of Arctic expeditions">Expeditions</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Farthest_North" title="Farthest North">Farthest North</a><br> <a href="https://en.wikipedia.org/wiki/North_Pole" title="North Pole">North Pole</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Willem_Barentsz" title="Willem Barentsz">Barentsz</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Hudson" title="Henry Hudson">Hudson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Thomas_Marmaduke" title="Thomas Marmaduke">Marmaduke</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Joris_Carolus" title="Joris Carolus">Carolus</a></li> 
<li><a href="https://en.wikipedia.org/wiki/William_Parry_(explorer)" title="William Parry (explorer)">Parry</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/North_Magnetic_Pole" title="North Magnetic Pole">North Magnetic Pole</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/John_Ross_(Arctic_explorer)" title="John Ross (Arctic explorer)">J. Ross</a></li> 
<li><a href="https://en.wikipedia.org/wiki/James_Clark_Ross" title="James Clark Ross">J. C. Ross</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Elisha_Kane" title="Elisha Kane">Kane</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Isaac_Israel_Hayes" title="Isaac Israel Hayes">Hayes</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Polaris_expedition" title="Polaris expedition">Polaris</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/USS_Periwinkle_(1864)" title="USS Periwinkle (1864)">Polaris</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Charles_Francis_Hall" title="Charles Francis Hall">C. F. Hall</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/British_Arctic_Expedition" title="British Arctic Expedition">British Arctic Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Alert_(1856)" title="HMS Alert (1856)">HMS <i>Alert</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/George_Nares" title="George Nares">Nares</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Discovery_(1874)" title="HMS Discovery (1874)">HMS <i>Discovery</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Frederick_Stephenson" title="Henry Frederick Stephenson">Stephenson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Albert_Hastings_Markham" title="Albert Hastings Markham">Markham</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Lady_Franklin_Bay_Expedition" title="Lady Franklin Bay Expedition">Lady Franklin Bay Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Adolphus_Greely" title="Adolphus Greely">Greely</a></li> 
<li><a href="https://en.wikipedia.org/wiki/James_Booth_Lockwood" title="James Booth Lockwood">Lockwood</a></li> 
<li><a href="https://en.wikipedia.org/wiki/David_Legge_Brainard" title="David Legge Brainard">Brainard</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Nansen%27s_Fram_expedition" title="Nansen's Fram expedition">1st Fram expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Fram" title="Fram">Fram</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Fridtjof_Nansen" title="Fridtjof Nansen">Nansen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Hjalmar_Johansen" title="Hjalmar Johansen">Johansen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Otto_Sverdrup" title="Otto Sverdrup">Sverdrup</a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/Jason_(ship)" title="Jason (ship)">Jason</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Prince_Luigi_Amedeo,_Duke_of_the_Abruzzi" title="Prince Luigi Amedeo, Duke of the Abruzzi">Amedeo</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Frederick_Cook" title="Frederick Cook">F. Cook</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Robert_Peary" title="Robert Peary">Peary</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Georgy_Sedov" title="Georgy Sedov">Sedov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Richard_E._Byrd" title="Richard E. Byrd">Byrd</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Norge_(airship)" title="Norge (airship)">Airship <i>Norge</i></a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Roald_Amundsen" title="Roald Amundsen">Amundsen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Umberto_Nobile" title="Umberto Nobile">Nobile</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Oscar_Wisting" title="Oscar Wisting">Wisting</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Hjalmar_Riiser-Larsen" title="Hjalmar Riiser-Larsen">Riiser-Larsen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Lincoln_Ellsworth" title="Lincoln Ellsworth">Ellsworth</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Airship_Italia" title="Airship Italia">Airship <i>Italia</i></a></b></li> 
<li><i><a href="https://en.wikipedia.org/wiki/USS_O-12_(SS-73)" title="USS O-12 (SS-73)">Nautilus</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Hubert_Wilkins" title="Hubert Wilkins">Wilkins</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Tupolev_ANT-25" title="Tupolev ANT-25">ANT-25</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Valery_Chkalov" title="Valery Chkalov">Chkalov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Georgy_Baydukov" title="Georgy Baydukov">Baydukov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alexander_Vasilyevich_Belyakov" title="Alexander Vasilyevich Belyakov">Belyakov</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Drifting_ice_station" title="Drifting ice station">"North Pole" manned drifting ice stations</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/North_Pole-1" title="North Pole-1">NP-1</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Ivan_Papanin" title="Ivan Papanin">Papanin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pyotr_Shirshov" title="Pyotr Shirshov">Shirshov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yevgeny_Fyodorov" title="Yevgeny Fyodorov">E. Fyodorov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ernst_Krenkel" title="Ernst Krenkel">Krenkel</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/North_Pole-36" title="North Pole-36">NP-36</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/North_Pole-37" title="North Pole-37">NP-37</a></b></li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Georgiy_Sedov_(icebreaker)" title="Georgiy Sedov (icebreaker)">Sedov</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Konstantin_Badygin" title="Konstantin Badygin">Badygin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vladimir_Wiese" title="Vladimir Wiese">Wiese</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/USS_Nautilus_(SSN-571)" title="USS Nautilus (SSN-571)">USS <i>Nautilus</i></a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/USS_Skate_(SSN-578)" title="USS Skate (SSN-578)">USS <i>Skate</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ralph_Plaisted" title="Ralph Plaisted">Plaisted</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wally_Herbert" title="Wally Herbert">Herbert</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Arktika_(icebreaker)" title="Arktika (icebreaker)">NS <i>Arktika</i></a></b></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Barneo" title="Barneo">Barneo</a></i></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Arktika_2007" title="Arktika 2007">Arktika 2007</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Mir_(submersible)" title="Mir (submersible)"><i>Mir</i> submersibles</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Anatoly_Sagalevich" title="Anatoly Sagalevich">Sagalevich</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Artur_Chilingarov" title="Artur Chilingarov">Chilingarov</a></li> 
</ul> </li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Iceland" title="Iceland">Iceland</a><br> <a href="https://en.wikipedia.org/wiki/Greenland" title="Greenland">Greenland</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Pytheas" title="Pytheas">Pytheas</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Brendan" title="Brendan">Brendan</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Papar" title="Papar">Papar</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Viking_expansion" title="Viking expansion">Vikings</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Naddodd" title="Naddodd">Naddodd</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gar%C3%B0ar_Svavarsson" title="Garðar Svavarsson">Svavarsson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ing%C3%B3lfr_Arnarson" title="Ingólfr Arnarson">Arnarson</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Norse_colonization_of_the_Americas" title="Norse colonization of the Americas">Norse colonization of the Americas</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Gunnbj%C3%B6rn_Ulfsson" title="Gunnbjörn Ulfsson">Ulfsson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sn%C3%A6bj%C3%B6rn_Galti" title="Snæbjörn Galti">Galti</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Erik_the_Red" title="Erik the Red">Erik the Red</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Christian_IV%27s_expeditions_to_Greenland" title="Christian IV's expeditions to Greenland">Christian IV's expeditions</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_Hall_(explorer)" title="James Hall (explorer)">J. Hall</a></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Cunningham_(explorer)" title="John Cunningham (explorer)">Cunningham</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Godske_Lindenov" title="Godske Lindenov">Lindenov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Carsten_Richardson" title="Carsten Richardson">C. Richardson</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Danish_colonization_of_the_Americas" title="Danish colonization of the Americas">Danish colonization</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Hans_Egede" title="Hans Egede">Egede</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/William_Scoresby" title="William Scoresby">Scoresby</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Jason_(ship)" title="Jason (ship)">Jason</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Fridtjof_Nansen" title="Fridtjof Nansen">Nansen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Otto_Sverdrup" title="Otto Sverdrup">Sverdrup</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Robert_Peary" title="Robert Peary">Peary</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Knud_Rasmussen" title="Knud Rasmussen">Rasmussen</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Northwest_Passage" title="Northwest Passage">Northwest Passage</a><br> <a href="https://en.wikipedia.org/wiki/Northern_Canada" title="Northern Canada">Northern Canada</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/John_Cabot" title="John Cabot">Cabot</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Gaspar_Corte-Real" title="Gaspar Corte-Real">G. Corte-Real</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Miguel_Corte-Real" title="Miguel Corte-Real">M. Corte-Real</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Martin_Frobisher" title="Martin Frobisher">Frobisher</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Humphrey_Gilbert" title="Humphrey Gilbert">Gilbert</a></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Davis_(English_explorer)" title="John Davis (English explorer)">Davis</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Hudson" title="Henry Hudson">Hudson</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Discovery_(1602_ship)" title="Discovery (1602 ship)">Discovery</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Robert_Bylot" title="Robert Bylot">Bylot</a></li> 
<li><a href="https://en.wikipedia.org/wiki/William_Baffin" title="William Baffin">Baffin</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Jens_Munk" title="Jens Munk">Munk</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ivan_Fyodorov_(navigator)" title="Ivan Fyodorov (navigator)">I. Fyodorov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mikhail_Gvozdev" title="Mikhail Gvozdev">Gvozdev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Resolution_(1771)" title="HMS Resolution (1771)">HMS <i>Resolution</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_Cook" title="James Cook">J. Cook</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Discovery_(1774)" title="HMS Discovery (1774)">HMS <i>Discovery</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Charles_Clerke" title="Charles Clerke">Clerke</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Alexander_Mackenzie_(explorer)" title="Alexander Mackenzie (explorer)">Mackenzie</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Otto_von_Kotzebue" title="Otto von Kotzebue">Kotzebue</a></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Ross_(Arctic_explorer)" title="John Ross (Arctic explorer)">J. Ross</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Griper_(1813)" title="HMS Griper (1813)">HMS <i>Griper</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/William_Parry_(explorer)" title="William Parry (explorer)">Parry</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Hecla_(1815)" title="HMS Hecla (1815)">HMS <i>Hecla</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/George_Francis_Lyon" title="George Francis Lyon">Lyon</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Fury_(1814)" title="HMS Fury (1814)">HMS <i>Fury</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Parkyns_Hoppner" title="Henry Parkyns Hoppner">Hoppner</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Francis_Crozier" title="Francis Crozier">Crozier</a></li> 
<li><a href="https://en.wikipedia.org/wiki/James_Clark_Ross" title="James Clark Ross">J. C. Ross</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Coppermine_Expedition_of_1819%E2%80%9322" title="Coppermine Expedition of 1819–22">Coppermine Expedition</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Franklin" title="John Franklin">Franklin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/George_Back" title="George Back">Back</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Peter_Warren_Dease" title="Peter Warren Dease">Dease</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Thomas_Simpson_(explorer)" title="Thomas Simpson (explorer)">Simpson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Blossom_(1806)" title="HMS Blossom (1806)">HMS <i>Blossom</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Frederick_William_Beechey" title="Frederick William Beechey">Beechey</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Franklin%27s_lost_expedition" title="Franklin's lost expedition">Franklin's lost expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Erebus_(1826)" title="HMS Erebus (1826)">HMS <i>Erebus</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Terror_(1813)" title="HMS Terror (1813)">HMS <i>Terror</i></a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Richard_Collinson" title="Richard Collinson">Collinson</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Rae%E2%80%93Richardson_Arctic_Expedition" title="Rae–Richardson Arctic Expedition">Rae–Richardson Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/John_Rae_(explorer)" title="John Rae (explorer)">Rae</a></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Richardson_(naturalist)" title="John Richardson (naturalist)">J. Richardson</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Horatio_Thomas_Austin" title="Horatio Thomas Austin">Austin</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/McClure_Arctic_Expedition" title="McClure Arctic Expedition">McClure Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Investigator_(1848)" title="HMS Investigator (1848)">HMS <i>Investigator</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Robert_McClure" title="Robert McClure">McClure</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Resolute_(1850)" title="HMS Resolute (1850)">HMS <i>Resolute</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Kellett" title="Henry Kellett">Kellett</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Edward_Belcher" title="Edward Belcher">Belcher</a></li> 
<li><a href="https://en.wikipedia.org/wiki/William_Kennedy_(explorer)" title="William Kennedy (explorer)">Kennedy</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Joseph_Ren%C3%A9_Bellot" title="Joseph René Bellot">Bellot</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Auxiliary_Steamship_Isabel_(1850)" title="Auxiliary Steamship Isabel (1850)">Isabel</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Edward_Augustus_Inglefield" title="Edward Augustus Inglefield">Inglefield</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Second_Grinnell_Expedition" title="Second Grinnell Expedition">2nd Grinnell Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/USS_Advance_(1847)" title="USS Advance (1847)">USS <i>Advance</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Elisha_Kane" title="Elisha Kane">Kane</a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/Fox_(ship)" title="Fox (ship)">Fox</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Francis_Leopold_McClintock" title="Francis Leopold McClintock">McClintock</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/USS_Jeannette_(1878)" title="USS Jeannette (1878)">HMS <i>Pandora</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Allen_Young" title="Allen Young">Young</a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/Fram" title="Fram">Fram</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Otto_Sverdrup" title="Otto Sverdrup">Sverdrup</a></li> 
</ul> </li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Gj%C3%B8a" title="Gjøa">Gjøa</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Roald_Amundsen" title="Roald Amundsen">Amundsen</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Knud_Rasmussen" title="Knud Rasmussen">Rasmussen</a></li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Last_voyage_of_the_Karluk" title="Last voyage of the Karluk">Karluk</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Vilhjalmur_Stefansson" title="Vilhjalmur Stefansson">Stefansson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Robert_Bartlett_(explorer)" title="Robert Bartlett (explorer)">Bartlett</a></li> 
</ul> </li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/St._Roch_(ship)" title="St. Roch (ship)">St. Roch</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Larsen_(explorer)" title="Henry Larsen (explorer)">H. Larsen</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/David_Scott_Cowper" title="David Scott Cowper">Cowper</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Northern_Sea_Route" title="Northern Sea Route">North East Passage</a><br> <a href="https://en.wikipedia.org/wiki/Extreme_North" title="Extreme North">Russian Arctic</a></th> 
<td> 
<div> 
<ul> 
<li><b><a href="https://en.wikipedia.org/wiki/Pomors" title="Pomors">Pomors</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Koch_(boat)" title="Koch (boat)">Koch boats</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Hugh_Willoughby" title="Hugh Willoughby">Willoughby</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Richard_Chancellor" title="Richard Chancellor">Chancellor</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Willem_Barentsz" title="Willem Barentsz">Barentsz</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Mangazeya" title="Mangazeya">Mangazeya</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Hudson" title="Henry Hudson">Hudson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Jonas_Poole" title="Jonas Poole">Poole</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Siberian_Cossacks" title="Siberian Cossacks">Siberian Cossacks</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Ilya_Perfilyev" title="Ilya Perfilyev">Perfilyev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mikhail_Stadukhin" title="Mikhail Stadukhin">Stadukhin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Semyon_Dezhnev" title="Semyon Dezhnev">Dezhnev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Fedot_Alekseyevich_Popov" title="Fedot Alekseyevich Popov">Popov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Kurbat_Ivanov" title="Kurbat Ivanov">Ivanov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Merkury_Vagin" title="Merkury Vagin">Vagin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yakov_Permyakov" title="Yakov Permyakov">Permyakov</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Great_Northern_Expedition" title="Great Northern Expedition">Great Northern Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Vitus_Bering" title="Vitus Bering">Bering</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Aleksei_Chirikov" title="Aleksei Chirikov">Chirikov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Stepan_Malygin" title="Stepan Malygin">Malygin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Dmitry_Ovtsyn" title="Dmitry Ovtsyn">Ovtsyn</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Fyodor_Minin" title="Fyodor Minin">Minin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vasili_Pronchishchev" title="Vasili Pronchishchev">V. Pronchishchev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Maria_Pronchishcheva" title="Maria Pronchishcheva">M. Pronchishcheva</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Semion_Chelyuskin" title="Semion Chelyuskin">Chelyuskin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Khariton_Laptev" title="Khariton Laptev">Kh. Laptev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Dmitry_Laptev" title="Dmitry Laptev">D. Laptev</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Vasily_Chichagov" title="Vasily Chichagov">Chichagov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ivan_Lyakhov" title="Ivan Lyakhov">Lyakhov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Joseph_Billings" title="Joseph Billings">Billings</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yakov_Sannikov" title="Yakov Sannikov">Sannikov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Matvei_Gedenschtrom" title="Matvei Gedenschtrom">Gedenschtrom</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ferdinand_von_Wrangel" title="Ferdinand von Wrangel">Wrangel</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Fyodor_Matyushkin" title="Fyodor Matyushkin">Matyushkin</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pyotr_Anjou" title="Pyotr Anjou">Anjou</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Fyodor_Litke" title="Fyodor Litke">Litke</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Mikhail_Lavrov" title="Mikhail Lavrov">Lavrov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Pyotr_Pakhtusov" title="Pyotr Pakhtusov">Pakhtusov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Avgust_Tsivolko" title="Avgust Tsivolko">Tsivolko</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alexander_von_Middendorff" title="Alexander von Middendorff">Middendorff</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Austro-Hungarian_North_Pole_Expedition" title="Austro-Hungarian North Pole Expedition">Austro-Hungarian Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Karl_Weyprecht" title="Karl Weyprecht">Weyprecht</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Julius_von_Payer" title="Julius von Payer">Payer</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Vega_Expedition" title="Vega Expedition">Vega Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Adolf_Erik_Nordenski%C3%B6ld" title="Adolf Erik Nordenskiöld">A. E. Nordenskiöld</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Louis_Palander" title="Louis Palander">Palander</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/USS_Jeannette_(1878)" title="USS Jeannette (1878)">USS <i>Jeannette</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/George_W._DeLong" title="George W. DeLong">DeLong</a></li> 
</ul> </li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Yermak_(1898_icebreaker)" title="Yermak (1898 icebreaker)">Yermak</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Stepan_Makarov" title="Stepan Makarov">Makarov</a></li> 
</ul> </li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Zarya_(polar_ship)" title="Zarya (polar ship)">Zarya</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Eduard_Toll" title="Eduard Toll">Toll</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nikolai_Kolomeitsev" title="Nikolai Kolomeitsev">Kolomeitsev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Fyodor_Matisen" title="Fyodor Matisen">Matisen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alexander_Kolchak" title="Alexander Kolchak">Kolchak</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Georgy_Sedov" title="Georgy Sedov">Sedov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vladimir_Rusanov" title="Vladimir Rusanov">Rusanov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alexander_Kuchin" title="Alexander Kuchin">Kuchin</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Brusilov_Expedition" title="Brusilov Expedition">Brusilov Expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Svyataya_Anna" title="Svyataya Anna">Sv. Anna</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Georgy_Brusilov" title="Georgy Brusilov">Brusilov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Valerian_Albanov" title="Valerian Albanov">Albanov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alexander_Konrad" title="Alexander Konrad">Konrad</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Vladimir_Wiese" title="Vladimir Wiese">Wiese</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Jan_Nag%C3%B3rski" title="Jan Nagórski">Nagórski</a></li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Taymyr_(icebreaker)" title="Taymyr (icebreaker)">Taymyr</a></b></i> / <i><b><a href="https://en.wikipedia.org/wiki/Vaygach_(icebreaker)" title="Vaygach (icebreaker)">Vaygach</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Boris_Vilkitsky" title="Boris Vilkitsky">Vilkitsky</a></li> 
</ul> </li> 
<li><i><b><a href="https://en.wikipedia.org/wiki/Maud_(ship)" title="Maud (ship)">Maud</a></b></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Roald_Amundsen" title="Roald Amundsen">Amundsen</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Arctic_and_Antarctic_Research_Institute" title="Arctic and Antarctic Research Institute">AARI</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Rudolf_Samoylovich" title="Rudolf Samoylovich">Samoylovich</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Nikifor_Begichev" title="Nikifor Begichev">Begichev</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nikolay_Urvantsev" title="Nikolay Urvantsev">Urvantsev</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Sadko_(icebreaker)" title="Sadko (icebreaker)">Sadko</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Georgy_Ushakov" title="Georgy Ushakov">Ushakov</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Chief_Directorate_of_the_Northern_Sea_Route" title="Chief Directorate of the Northern Sea Route">Glavsevmorput</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Otto_Schmidt" title="Otto Schmidt">Schmidt</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Aviaarktika" title="Aviaarktika">Aviaarktika</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Mark_Shevelev" title="Mark Shevelev">Shevelev</a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/A._Sibiryakov_(icebreaker)" title="A. Sibiryakov (icebreaker)">Sibiryakov</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Vladimir_Voronin_(captain)" title="Vladimir Voronin (captain)">Voronin</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/SS_Chelyuskin" title="SS Chelyuskin"><i>Chelyuskin</i></a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Krassin_(1917_icebreaker)" title="Krassin (1917 icebreaker)">Krassin</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Yakov_Gakkel" title="Yakov Gakkel">Gakkel</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nuclear-powered_icebreaker" title="Nuclear-powered icebreaker">Nuclear-powered icebreakers</a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Lenin_(nuclear_icebreaker)" title="Lenin (nuclear icebreaker)">NS <i>Lenin</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arktika-class_icebreaker" title="Arktika-class icebreaker"><i>Arktika</i> class</a></li> 
</ul> </li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<th scope="col" colspan="2"><span>&nbsp;</span> 
<div>
<a href="https://en.wikipedia.org/wiki/Antarctic" title="Antarctic">Antarctic</a>
</div> </th> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<td colspan="2"> 
<div></div> 
<table> 
<tbody>
<tr> 
<td colspan="2"> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Antarctica" title="Antarctica">Continent</a></li> 
<li><a href="https://en.wikipedia.org/wiki/History_of_Antarctica" title="History of Antarctica">History</a></li> 
<li><a href="https://en.wikipedia.org/wiki/List_of_Antarctic_expeditions" title="List of Antarctic expeditions">Expeditions</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Southern_Ocean" title="Southern Ocean">Southern Ocean</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Anthony_de_la_Roch%C3%A9" title="Anthony de la Roché">Roché</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Jean-Baptiste_Charles_Bouvet_de_Lozier" title="Jean-Baptiste Charles Bouvet de Lozier">Bouvet</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yves-Joseph_de_Kerguelen-Tr%C3%A9marec" title="Yves-Joseph de Kerguelen-Trémarec">Kerguelen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Resolution_(1771)" title="HMS Resolution (1771)">HMS <i>Resolution</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_Cook" title="James Cook">J. Cook</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Adventure_(1771)" title="HMS Adventure (1771)">HMS <i>Adventure</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Tobias_Furneaux" title="Tobias Furneaux">Furneaux</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/William_Smith_(mariner)" title="William Smith (mariner)">Smith</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/San_Telmo_(ship)" title="San Telmo (ship)">San Telmo</a></i></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Vostok_(sloop-of-war)" title="Vostok (sloop-of-war)">Vostok</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Fabian_Gottlieb_von_Bellingshausen" title="Fabian Gottlieb von Bellingshausen">Bellingshausen</a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/Mirny_(sloop-of-war)" title="Mirny (sloop-of-war)">Mirny</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Mikhail_Lazarev" title="Mikhail Lazarev">Lazarev</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Edward_Bransfield" title="Edward Bransfield">Bransfield</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Nathaniel_Palmer" title="Nathaniel Palmer">Palmer</a></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Davis_(sealer)" title="John Davis (sealer)">Davis</a></li> 
<li><a href="https://en.wikipedia.org/wiki/James_Weddell" title="James Weddell">Weddell</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Benjamin_Morrell" title="Benjamin Morrell">Morrell</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/French_ship_Astrolabe_(1811)" title="French ship Astrolabe (1811)">Astrolabe</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Jules_Dumont_d%27Urville" title="Jules Dumont d'Urville">Dumont d'Urville</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/United_States_Exploring_Expedition" title="United States Exploring Expedition">United States Exploring Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/USS_Vincennes_(1826)" title="USS Vincennes (1826)">USS <i>Vincennes</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Charles_Wilkes" title="Charles Wilkes">Wilkes</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/USS_Porpoise_(1836)" title="USS Porpoise (1836)">USS <i>Porpoise</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Cadwalader_Ringgold" title="Cadwalader Ringgold">Ringgold</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Erebus_(1826)" title="HMS Erebus (1826)">HMS <i>Erebus</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_Clark_Ross" title="James Clark Ross">J. C. Ross</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Terror_(1813)" title="HMS Terror (1813)">HMS <i>Terror</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Francis_Crozier" title="Francis Crozier">Crozier</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Mercator_Cooper" title="Mercator Cooper">Cooper</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Challenger_expedition" title="Challenger expedition">Challenger expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Challenger_(1858)" title="HMS Challenger (1858)">HMS <i>Challenger</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/George_Nares" title="George Nares">Nares</a></li> 
<li><a href="https://en.wikipedia.org/wiki/John_Murray_(oceanographer)" title="John Murray (oceanographer)">Murray</a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/Jason_(ship)" title="Jason (ship)">Jason</a></i> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Carl_Anton_Larsen" title="Carl Anton Larsen">C. A. Larsen</a></li> 
</ul> </li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><span>"</span><a href="https://en.wikipedia.org/wiki/Heroic_Age_of_Antarctic_Exploration" title="Heroic Age of Antarctic Exploration">Heroic Age</a><span>"</span></th> 
<td> 
<div> 
<ul> 
<li><b><a href="https://en.wikipedia.org/wiki/Belgian_Antarctic_Expedition" title="Belgian Antarctic Expedition">Belgian Antarctic Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/RV_Belgica_(1884)" title="RV Belgica (1884)"><i>Belgica</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Adrien_de_Gerlache" title="Adrien de Gerlache">de Gerlache</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Georges_Lecointe_(explorer)" title="Georges Lecointe (explorer)">Lecointe</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Roald_Amundsen" title="Roald Amundsen">Amundsen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Frederick_Cook" title="Frederick Cook">Cook</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Henryk_Arctowski" title="Henryk Arctowski">Arctowski</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Emil_Racovi%C8%9B%C4%83" title="Emil Racoviță">Racoviță</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Antoni_Boles%C5%82aw_Dobrowolski" title="Antoni Bolesław Dobrowolski">Dobrowolski</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Southern_Cross_Expedition" title="Southern Cross Expedition">Southern Cross</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/SS_Southern_Cross_(1886)" title="SS Southern Cross (1886)"><i>Southern Cross</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Carsten_Borchgrevink" title="Carsten Borchgrevink">Borchgrevink</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Discovery_Expedition" title="Discovery Expedition">Discovery</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/RRS_Discovery" title="RRS Discovery">Discovery</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Discovery_Hut" title="Discovery Hut">Discovery Hut</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Gauss_expedition" title="Gauss expedition">Gauss</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Gauss_(ship)" title="Gauss (ship)">Gauss</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Erich_von_Drygalski" title="Erich von Drygalski">Drygalski</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Swedish_Antarctic_Expedition" title="Swedish Antarctic Expedition">Swedish Antarctic Expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Antarctic_(ship)" title="Antarctic (ship)">Antarctic</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Otto_Nordenskj%C3%B6ld" title="Otto Nordenskjöld">O. Nordenskjöld</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Carl_Anton_Larsen" title="Carl Anton Larsen">C. A. Larsen</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Scottish_National_Antarctic_Expedition" title="Scottish National Antarctic Expedition">Scottish Antarctic Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/William_Speirs_Bruce" title="William Speirs Bruce">Bruce</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Scotia_(barque)" title="Scotia (barque)"><i>Scotia</i></a></li> 
</ul> </li> 
<li><i><a href="https://en.wikipedia.org/wiki/Orcadas_Base" title="Orcadas Base">Orcadas Base</a></i></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Nimrod_Expedition" title="Nimrod Expedition">Nimrod Expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Nimrod_(ship)" title="Nimrod (ship)">Nimrod</a></i></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/French_Antarctic_Expedition" title="French Antarctic Expedition">French Antarctic Expeditions</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Pourquoi-Pas_(1908)" title="Pourquoi-Pas (1908)">Pourquoi-Pas</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Jean-Baptiste_Charcot" title="Jean-Baptiste Charcot">Charcot</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Japanese_Antarctic_Expedition" title="Japanese Antarctic Expedition">Japanese Antarctic Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Shirase_Nobu" title="Shirase Nobu">Shirase</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Amundsen%27s_South_Pole_expedition" title="Amundsen's South Pole expedition">Amundsen's South Pole expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Fram" title="Fram">Fram</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Roald_Amundsen" title="Roald Amundsen">Amundsen</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Framheim" title="Framheim">Framheim</a></i></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Polheim" title="Polheim">Polheim</a></i></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Terra_Nova_Expedition" title="Terra Nova Expedition">Terra Nova</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Terra_Nova_(ship)" title="Terra Nova (ship)">Terra Nova</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Robert_Falcon_Scott" title="Robert Falcon Scott">Scott</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Edward_Adrian_Wilson" title="Edward Adrian Wilson">Wilson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Edward_Evans,_1st_Baron_Mountevans" title="Edward Evans, 1st Baron Mountevans">E. R. Evans</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Tom_Crean_(explorer)" title="Tom Crean (explorer)">Crean</a></li> 
<li><a href="https://en.wikipedia.org/wiki/William_Lashly" title="William Lashly">Lashly</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Wilhelm_Filchner" title="Wilhelm Filchner">Filchner</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Australasian_Antarctic_Expedition" title="Australasian Antarctic Expedition">Australasian Antarctic Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/SY_Aurora" title="SY Aurora">SY <i>Aurora</i></a></li> 
<li><a href="https://en.wikipedia.org/wiki/Douglas_Mawson" title="Douglas Mawson">Mawson</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Far_Eastern_Party" title="Far Eastern Party">Far Eastern Party</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Imperial_Trans-Antarctic_Expedition" title="Imperial Trans-Antarctic Expedition">Imperial Trans-Antarctic Expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Endurance_(1912_ship)" title="Endurance (1912 ship)">Endurance</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Ernest_Shackleton" title="Ernest Shackleton">Ernest Shackleton</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Frank_Wild" title="Frank Wild">Wild</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Voyage_of_the_James_Caird" title="Voyage of the James Caird"><i>James Caird</i></a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Ross_Sea_party" title="Ross Sea party">Ross Sea party</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Aeneas_Mackintosh" title="Aeneas Mackintosh">Mackintosh</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Shackleton%E2%80%93Rowett_Expedition" title="Shackleton–Rowett Expedition">Shackleton–Rowett Expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Quest_(ship)" title="Quest (ship)">Quest</a></i></li> 
</ul> </li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/International_Polar_Year" title="International Polar Year">IPY</a> · <a href="https://en.wikipedia.org/wiki/International_Geophysical_Year" title="International Geophysical Year">IGY</a><br> <a href="https://en.wikipedia.org/wiki/Research_stations_in_Antarctica" title="Research stations in Antarctica">Modern research</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Lars_Christensen" title="Lars Christensen">Christensen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Richard_E._Byrd" title="Richard E. Byrd">Byrd</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/British_Australian_and_New_Zealand_Antarctic_Research_Expedition" title="British Australian and New Zealand Antarctic Research Expedition">BANZARE</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/British_Graham_Land_Expedition" title="British Graham Land Expedition">BGLE</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/John_Rymill" title="John Rymill">Rymill</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/New_Swabia" title="New Swabia">New Swabia</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Alfred_Ritscher" title="Alfred Ritscher">Ritscher</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Operation_Tabarin" title="Operation Tabarin">Operation Tabarin</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_William_Slessor_Marr" title="James William Slessor Marr">Marr</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Operation_Highjump" title="Operation Highjump">Operation Highjump</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Captain_Arturo_Prat_Base" title="Captain Arturo Prat Base">Captain Arturo Prat Base</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/British_Antarctic_Survey" title="British Antarctic Survey">British Antarctic Survey</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Operation_Windmill" title="Operation Windmill">Operation Windmill</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Gerald_Ketchum" title="Gerald Ketchum">Ketchum</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Ronne_Antarctic_Research_Expedition" title="Ronne Antarctic Research Expedition">Ronne Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Finn_Ronne" title="Finn Ronne">F. Ronne</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Jackie_Ronne" title="Jackie Ronne">E. Ronne</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Isaac_Schlossbach" title="Isaac Schlossbach">Schlossbach</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Operation_Deep_Freeze" title="Operation Deep Freeze">Operation Deep Freeze</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/McMurdo_Station" title="McMurdo Station">McMurdo Station</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Commonwealth_Trans-Antarctic_Expedition" title="Commonwealth Trans-Antarctic Expedition">Commonwealth Trans-Antarctic Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Edmund_Hillary" title="Edmund Hillary">Hillary</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vivian_Fuchs" title="Vivian Fuchs">V. Fuchs</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Soviet_Antarctic_Expedition" title="Soviet Antarctic Expedition">Soviet Antarctic Expeditions</a></b> 
<ul> 
<li><b><a href="https://en.wikipedia.org/wiki/1st_Soviet_Antarctic_Expedition" title="1st Soviet Antarctic Expedition">1st</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Mikhail_Somov" title="Mikhail Somov">Somov</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Maria_Klenova" title="Maria Klenova">Klenova</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Mirny_Station" title="Mirny Station">Mirny</a></i></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/2nd_Soviet_Antarctic_Expedition" title="2nd Soviet Antarctic Expedition">2nd</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Alexey_Tryoshnikov" title="Alexey Tryoshnikov">Tryoshnikov</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/3rd_Soviet_Antarctic_Expedition" title="3rd Soviet Antarctic Expedition">3rd</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Yevgeny_Tolstikov" title="Yevgeny Tolstikov">Tolstikov</a></li> 
</ul> </li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Antarctic_Treaty_System" title="Antarctic Treaty System">Antarctic Treaty System</a></b></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Transglobe_Expedition" title="Transglobe Expedition">Transglobe Expedition</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Ranulph_Fiennes" title="Ranulph Fiennes">Fiennes</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Charles_R._Burton" title="Charles R. Burton">Burton</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Lake_Vostok" title="Lake Vostok">Lake Vostok</a></b></li> 
<li><a href="https://en.wikipedia.org/wiki/Andrey_Kapitsa" title="Andrey Kapitsa">Kapitsa</a></li> 
</ul> 
</div> </td> 
</tr> 
<tr> 
<td colspan="2"></td> 
</tr> 
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Farthest_South" title="Farthest South">Farthest South</a><br> <a href="https://en.wikipedia.org/wiki/South_Pole" title="South Pole">South Pole</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Resolution_(1771)" title="HMS Resolution (1771)">HMS <i>Resolution</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_Cook" title="James Cook">J. Cook</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Adventure_(1771)" title="HMS Adventure (1771)">HMS <i>Adventure</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Tobias_Furneaux" title="Tobias Furneaux">Furneaux</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/James_Weddell" title="James Weddell">Weddell</a></li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Erebus_(1826)" title="HMS Erebus (1826)">HMS <i>Erebus</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/James_Clark_Ross" title="James Clark Ross">J. C. Ross</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/HMS_Terror_(1813)" title="HMS Terror (1813)">HMS <i>Terror</i></a> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Francis_Crozier" title="Francis Crozier">Crozier</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Southern_Cross_Expedition" title="Southern Cross Expedition">Southern Cross</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Carsten_Borchgrevink" title="Carsten Borchgrevink">Borchgrevink</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Discovery_Expedition" title="Discovery Expedition">Discovery</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Michael_Barne" title="Michael Barne">Barne</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Nimrod_Expedition" title="Nimrod Expedition">Nimrod</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Ernest_Shackleton" title="Ernest Shackleton">Shackleton</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Frank_Wild" title="Frank Wild">Wild</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Eric_Marshall" title="Eric Marshall">Marshall</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Jameson_Adams" title="Jameson Adams">Adams</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/South_Magnetic_Pole" title="South Magnetic Pole">South Magnetic Pole</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Douglas_Mawson" title="Douglas Mawson">Mawson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Edgeworth_David" title="Edgeworth David">David</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Alistair_Mackay" title="Alistair Mackay">Mackay</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Amundsen%27s_South_Pole_expedition" title="Amundsen's South Pole expedition">Amundsen's South Pole expedition</a></b> 
<ul> 
<li><i><a href="https://en.wikipedia.org/wiki/Fram" title="Fram">Fram</a></i></li> 
<li><a href="https://en.wikipedia.org/wiki/Roald_Amundsen" title="Roald Amundsen">Amundsen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Olav_Bjaaland" title="Olav Bjaaland">Bjaaland</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Helmer_Hanssen" title="Helmer Hanssen">Helmer</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Sverre_Hassel" title="Sverre Hassel">Hassel</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Oscar_Wisting" title="Oscar Wisting">Wisting</a></li> 
<li><i><a href="https://en.wikipedia.org/wiki/Polheim" title="Polheim">Polheim</a></i></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Terra_Nova_Expedition" title="Terra Nova Expedition">Terra Nova</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Robert_Falcon_Scott" title="Robert Falcon Scott">Scott</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Edgar_Evans" title="Edgar Evans">E. Evans</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Lawrence_Oates" title="Lawrence Oates">Oates</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Edward_Adrian_Wilson" title="Edward Adrian Wilson">Wilson</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Henry_Robertson_Bowers" title="Henry Robertson Bowers">Bowers</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Richard_E._Byrd" title="Richard E. Byrd">Byrd</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Bernt_Balchen" title="Bernt Balchen">Balchen</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Ashley_Chadbourne_McKinley" title="Ashley Chadbourne McKinley">McKinley</a></li> 
<li><a href="https://en.wikipedia.org/wiki/George_J._Dufek" title="George J. Dufek">Dufek</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Amundsen%E2%80%93Scott_South_Pole_Station" title="Amundsen–Scott South Pole Station">Amundsen–Scott South Pole Station</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Edmund_Hillary" title="Edmund Hillary">Hillary</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Vivian_Fuchs" title="Vivian Fuchs">V. Fuchs</a></li> 
<li><b><a href="https://en.wikipedia.org/wiki/Pole_of_Cold" title="Pole of Cold">Pole of Cold</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Vostok_Station" title="Vostok Station">Vostok Station</a></li> 
</ul> </li> 
<li><b><a href="https://en.wikipedia.org/wiki/Pole_of_inaccessibility" title="Pole of inaccessibility">Pole of inaccessibility</a></b> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Pole_of_Inaccessibility_(Antarctic_research_station)" title="Pole of Inaccessibility (Antarctic research station)">Pole of Inaccessibility Station</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Yevgeny_Tolstikov" title="Yevgeny Tolstikov">Tolstikov</a></li> 
</ul> </li> 
<li><a href="https://en.wikipedia.org/wiki/Albert_P._Crary" title="Albert P. Crary">Crary</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Arved_Fuchs" title="Arved Fuchs">A. Fuchs</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Reinhold_Messner" title="Reinhold Messner">Messner</a></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table> 
<p><span><span><a href="https://en.wikipedia.org/wiki/Geographic_coordinate_system" title="Geographic coordinate system">Coordinates</a>: <span><a href="https://tools.wmflabs.org/geohack/geohack.php?pagename=Arctic_Ocean&amp;params=90_N_0_E_type:waterbody_scale:50000000"><span><span><span>90°N</span> <span>0°E</span></span></span><span>﻿ / ﻿</span><span><span>90°N 0°E</span><span>﻿ / <span>90; 0</span></span></span></a></span></span></span></p> 
<table> 
<tbody>
<tr> 
<td> 
<table> 
<tbody>
<tr> 
<th scope="row"><a href="https://en.wikipedia.org/wiki/Help:Authority_control" title="Help:Authority control">Authority control</a></th> 
<td> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Virtual_International_Authority_File" title="Virtual International Authority File">VIAF</a>: <span><a href="https://viaf.org/viaf/260253700">260253700</a></span></li> 
<li><a href="https://en.wikipedia.org/wiki/Integrated_Authority_File" title="Integrated Authority File">GND</a>: <span><a href="http://d-nb.info/gnd/4042569-1">4042569-1</a></span></li> 
<li><a href="https://en.wikipedia.org/wiki/National_Diet_Library" title="National Diet Library">NDL</a>: <span><a href="http://id.ndl.go.jp/auth/ndlna/00563373">00563373</a></span></li> 
</ul> 
</div> </td> 
</tr> 
</tbody>
</table> </td> 
</tr> 
</tbody>
</table>    
<img src="https://en.wikipedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1">
</div> 
<div>
 Retrieved from "
<a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;oldid=674756080">https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;oldid=674756080</a>" 
</div> 
<div>
<div>
<a href="https://en.wikipedia.org/wiki/Help:Category" title="Help:Category">Categories</a>: 
<ul>
<li><a href="https://en.wikipedia.org/wiki/Category:Arctic_Ocean" title="Category:Arctic Ocean">Arctic Ocean</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Oceans" title="Category:Oceans">Oceans</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Extreme_points_of_Earth" title="Category:Extreme points of Earth">Extreme points of Earth</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Landforms_of_the_Arctic_Ocean" title="Category:Landforms of the Arctic Ocean">Landforms of the Arctic Ocean</a></li>
</ul>
</div>
<div>
Hidden categories: 
<ul>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_indefinitely_move-protected_pages" title="Category:Wikipedia indefinitely move-protected pages">Wikipedia indefinitely move-protected pages</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:All_articles_with_unsourced_statements" title="Category:All articles with unsourced statements">All articles with unsourced statements</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_with_unsourced_statements_from_February_2012" title="Category:Articles with unsourced statements from February 2012">Articles with unsourced statements from February 2012</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Commons_category_with_local_link_same_as_on_Wikidata" title="Category:Commons category with local link same as on Wikidata">Commons category with local link same as on Wikidata</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Lists_of_coordinates" title="Category:Lists of coordinates">Lists of coordinates</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Geographic_coordinate_lists" title="Category:Geographic coordinate lists">Geographic coordinate lists</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_with_Geo" title="Category:Articles with Geo">Articles with Geo</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Coordinates_on_Wikidata" title="Category:Coordinates on Wikidata">Coordinates on Wikidata</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_articles_with_VIAF_identifiers" title="Category:Wikipedia articles with VIAF identifiers">Wikipedia articles with VIAF identifiers</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Wikipedia_articles_with_GND_identifiers" title="Category:Wikipedia articles with GND identifiers">Wikipedia articles with GND identifiers</a></li>
<li><a href="https://en.wikipedia.org/wiki/Category:Articles_containing_video_clips" title="Category:Articles containing video clips">Articles containing video clips</a></li>
</ul>
</div>
</div> 
<div></div> 
</div> 
</div> 
<div> 
<h2>Navigation menu</h2> 
<div> 
<div> 
<h3>Personal tools</h3> 
<ul> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:UserLogin&amp;returnto=Arctic+Ocean&amp;type=signup" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:UserLogin&amp;returnto=Arctic+Ocean" title="You're encouraged to log in; however, it's not mandatory. [o]">Log in</a></li> 
</ul> 
</div> 
<div> 
<div> 
<h3>Namespaces</h3> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Arctic_Ocean" title="View the content page [c]">Article</a></span></li> 
<li><span><a href="https://en.wikipedia.org/wiki/Talk:Arctic_Ocean" title="Discussion about the content page [t]">Talk</a></span></li> 
</ul> 
</div> 
<div> 
<h3> <span>Variants</span><a href="https://en.wikipedia.org/wiki#"></a> </h3> 
<div> 
<ul> 
</ul> 
</div> 
</div> 
</div> 
<div> 
<div> 
<h3>Views</h3> 
<ul> 
<li><span><a href="https://en.wikipedia.org/wiki/Arctic_Ocean">Read</a></span></li> 
<li><span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=edit" title="Edit this page [e]">Edit</a></span></li> 
<li><span><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=history" title="Past versions of this page [h]">View history</a></span></li> 
</ul> 
</div> 
<div> 
<h3><span>More</span><a href="https://en.wikipedia.org/wiki#"></a></h3> 
<div> 
<ul> 
</ul> 
</div> 
</div> 
<div> 
<h3> Search </h3>  
<div>  
</div>  
</div> 
</div> 
</div> 
<div> 
<div>
<a href="https://en.wikipedia.org/wiki/Main_Page" title="Visit the main page"></a>
</div> 
<div> 
<h3>Navigation</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Main_Page" title="Visit the main page [z]">Main page</a></li>
<li><a href="https://en.wikipedia.org/wiki/Portal:Contents" title="Guides to browsing Wikipedia">Contents</a></li>
<li><a href="https://en.wikipedia.org/wiki/Portal:Featured_content" title="Featured content – the best of Wikipedia">Featured content</a></li>
<li><a href="https://en.wikipedia.org/wiki/Portal:Current_events" title="Find background information on current events">Current events</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:Random" title="Load a random article [x]">Random article</a></li>
<li><a href="https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&amp;utm_medium=sidebar&amp;utm_campaign=C13_en.wikipedia.org&amp;uselang=en" title="Support us">Donate to Wikipedia</a></li>
<li><a href="https://shop.wikimedia.org" title="Visit the Wikimedia store">Wikipedia store</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Interaction</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Help:Contents" title="Guidance on how to use and edit Wikipedia">Help</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:About" title="Find out about Wikipedia">About Wikipedia</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]">Recent changes</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact page</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Tools</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/wiki/Special:WhatLinksHere/Arctic_Ocean" title="List of all English Wikipedia pages containing links to this page [j]">What links here</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:RecentChangesLinked/Arctic_Ocean" title="Recent changes in pages linked from this page [k]">Related changes</a></li>
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:File_Upload_Wizard" title="Upload files [u]">Upload file</a></li>
<li><a href="https://en.wikipedia.org/wiki/Special:SpecialPages" title="A list of all special pages [q]">Special pages</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;oldid=674756080" title="Permanent link to this revision of the page">Permanent link</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;action=info" title="More information about this page">Page information</a></li>
<li><a href="https://www.wikidata.org/wiki/Q788" title="Link to connected data repository item [g]">Wikidata item</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:CiteThisPage&amp;page=Arctic_Ocean&amp;id=674756080" title="Information on how to cite this page">Cite this page</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Print/export</h3> 
<div> 
<ul> 
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:Book&amp;bookcmd=book_creator&amp;referer=Arctic+Ocean">Create a book</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Special:Book&amp;bookcmd=render_article&amp;arttitle=Arctic+Ocean&amp;oldid=674756080&amp;writer=rdf2latex">Download as PDF</a></li>
<li><a href="https://en.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;printable=yes" title="Printable version of this page [p]">Printable version</a></li> 
</ul> 
</div> 
</div> 
<div> 
<h3>Languages</h3> 
<div> 
<ul> 
<li><a href="https://ace.wikipedia.org/wiki/La%27%C3%B4t_Arktik" title="La'ôt Arktik – Achinese">Acèh</a></li>
<li><a href="https://kbd.wikipedia.org/wiki/%D0%90%D1%80%D0%BA%D1%82%D0%B8%D0%BA%D1%8D_%D0%A5%D1%8B%D1%88%D1%85%D1%83%D1%8D" title="Арктикэ Хышхуэ – Kabardian">Адыгэбзэ</a></li>
<li><a href="https://af.wikipedia.org/wiki/Arktiese_Oseaan" title="Arktiese Oseaan – Afrikaans">Afrikaans</a></li>
<li><a href="https://als.wikipedia.org/wiki/Arktischer_Ozean" title="Arktischer Ozean – Alemannisch">Alemannisch</a></li>
<li><a href="https://am.wikipedia.org/wiki/%E1%8A%A0%E1%88%AD%E1%8A%AD%E1%89%B2%E1%8A%AD_%E1%8B%8D%E1%89%85%E1%8B%AB%E1%8A%96%E1%88%B5" title="አርክቲክ ውቅያኖስ – Amharic">አማርኛ</a></li>
<li><a href="https://ang.wikipedia.org/wiki/%C4%AAsh%C3%A6f" title="Īshæf – Old English">Ænglisc</a></li>
<li><a href="https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D8%AD%D9%8A%D8%B7_%D8%A7%D9%84%D9%85%D8%AA%D8%AC%D9%85%D8%AF_%D8%A7%D9%84%D8%B4%D9%85%D8%A7%D9%84%D9%8A" title="المحيط المتجمد الشمالي – Arabic">العربية</a></li>
<li><a href="https://an.wikipedia.org/wiki/Oci%C3%A1n_Glacial_Arctico" title="Ocián Glacial Arctico – Aragonese">Aragonés</a></li>
<li><a href="https://frp.wikipedia.org/wiki/Oc%C3%A8an_artico" title="Ocèan artico – Arpitan">Arpetan</a></li>
<li><a href="https://as.wikipedia.org/wiki/%E0%A6%89%E0%A6%A4%E0%A7%8D%E0%A6%A4%E0%A7%B0_%E0%A6%AE%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%BE%E0%A6%97%E0%A7%B0" title="উত্তৰ মহাসাগৰ – Assamese">অসমীয়া</a></li>
<li><a href="https://ast.wikipedia.org/wiki/Oc%C3%A9anu_Glacial_%C3%81rticu" title="Océanu Glacial Árticu – Asturian">Asturianu</a></li>
<li><a href="https://gn.wikipedia.org/wiki/Paraguasu_%C3%81rktiko" title="Paraguasu Árktiko – Guarani">Avañe'ẽ</a></li>
<li><a href="https://av.wikipedia.org/wiki/%D0%A8%D0%B8%D0%BC%D0%B0%D0%BB%D0%B8%D1%8F%D0%B1_%D0%A6%D0%86%D0%BE%D1%80%D0%BE%D0%BB_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Шималияб ЦІорол океан – Avaric">Авар</a></li>
<li><a href="https://az.wikipedia.org/wiki/%C5%9Eimal_Buzlu_okean" title="Şimal Buzlu okean – Azerbaijani">Azərbaycanca</a></li>
<li><a href="https://bn.wikipedia.org/wiki/%E0%A6%89%E0%A6%A4%E0%A7%8D%E0%A6%A4%E0%A6%B0_%E0%A6%AE%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%BE%E0%A6%97%E0%A6%B0" title="উত্তর মহাসাগর – Bengali">বাংলা</a></li>
<li><a href="https://zh-min-nan.wikipedia.org/wiki/Pak-ke%CC%8Dk-i%C3%BB%E2%81%BF" title="Pak-ke̍k-iûⁿ – Chinese (Min Nan)">Bân-lâm-gú</a></li>
<li><a href="https://ba.wikipedia.org/wiki/%D0%A2%D3%A9%D0%BD%D1%8C%D1%8F%D2%A1_%D0%91%D0%BE%D2%99%D0%BB%D0%BE_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Төньяҡ Боҙло океан – Bashkir">Башҡортса</a></li>
<li><a href="https://be.wikipedia.org/wiki/%D0%9F%D0%B0%D1%9E%D0%BD%D0%BE%D1%87%D0%BD%D1%8B_%D0%9B%D0%B5%D0%B4%D0%B0%D0%B2%D1%96%D1%82%D1%8B_%D0%B0%D0%BA%D1%96%D1%8F%D0%BD" title="Паўночны Ледавіты акіян – Belarusian">Беларуская</a></li>
<li><a href="https://be-x-old.wikipedia.org/wiki/%D0%90%D1%80%D0%BA%D1%82%D1%8B%D1%87%D0%BD%D1%8B_%D0%B0%D0%BA%D1%96%D1%8F%D0%BD" title="Арктычны акіян – беларуская (тарашкевіца)‎">Беларуская (тарашкевіца)‎</a></li>
<li><a href="https://bh.wikipedia.org/wiki/%E0%A4%86%E0%A4%B0%E0%A5%8D%E0%A4%95%E0%A4%9F%E0%A4%BF%E0%A4%95_%E0%A4%AE%E0%A4%B9%E0%A4%BE%E0%A4%B8%E0%A4%BE%E0%A4%97%E0%A4%B0" title="आर्कटिक महासागर – भोजपुरी">भोजपुरी</a></li>
<li><a href="https://bcl.wikipedia.org/wiki/Kadagatan_Arktiko" title="Kadagatan Arktiko – Bikol Central">Bikol Central</a></li>
<li><a href="https://bg.wikipedia.org/wiki/%D0%A1%D0%B5%D0%B2%D0%B5%D1%80%D0%B5%D0%BD_%D0%BB%D0%B5%D0%B4%D0%BE%D0%B2%D0%B8%D1%82_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Северен ледовит океан – Bulgarian">Български</a></li>
<li><a href="https://bar.wikipedia.org/wiki/Arktischer_Ozean" title="Arktischer Ozean – Bavarian">Boarisch</a></li>
<li><a href="https://bs.wikipedia.org/wiki/Arkti%C4%8Dki_okean" title="Arktički okean – Bosnian">Bosanski</a></li>
<li><a href="https://br.wikipedia.org/wiki/Meurvor_skornek_Arktika" title="Meurvor skornek Arktika – Breton">Brezhoneg</a></li>
<li><a href="https://bxr.wikipedia.org/wiki/%D0%A5%D0%BE%D0%B9%D1%82%D0%BE_%D0%BC%D2%AF%D0%BB%D1%8C%D2%BB%D1%8D%D0%BD_%D0%B4%D0%B0%D0%BB%D0%B0%D0%B9" title="Хойто мүльһэн далай – буряад">Буряад</a></li>
<li><a href="https://ca.wikipedia.org/wiki/Oce%C3%A0_%C3%80rtic" title="Oceà Àrtic – Catalan">Català</a></li>
<li><a href="https://cv.wikipedia.org/wiki/%C3%87%D1%83%D1%80%C3%A7%C4%95%D1%80_%D0%9F%C4%83%D1%80%D0%BB%C4%83_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD%C4%95" title="Çурçĕр Пăрлă океанĕ – Chuvash">Чӑвашла</a></li>
<li><a href="https://ceb.wikipedia.org/wiki/Kadagatang_Artiko" title="Kadagatang Artiko – Cebuano">Cebuano</a></li>
<li><a href="https://cs.wikipedia.org/wiki/Severn%C3%AD_ledov%C3%BD_oce%C3%A1n" title="Severní ledový oceán – Czech">Čeština</a></li>
<li><a href="https://co.wikipedia.org/wiki/Mari_Articu" title="Mari Articu – Corsican">Corsu</a></li>
<li><a href="https://cy.wikipedia.org/wiki/Cefnfor_yr_Arctig" title="Cefnfor yr Arctig – Welsh">Cymraeg</a></li>
<li><a href="https://da.wikipedia.org/wiki/Ishavet" title="Ishavet – Danish">Dansk</a></li>
<li><a href="https://de.wikipedia.org/wiki/Arktischer_Ozean" title="Arktischer Ozean – German">Deutsch</a></li>
<li><a href="https://dsb.wikipedia.org/wiki/P%C3%B3dpo%C5%82nocny_polarny_ocean" title="Pódpołnocny polarny ocean – Lower Sorbian">Dolnoserbski</a></li>
<li><a href="https://et.wikipedia.org/wiki/P%C3%B5hja-J%C3%A4%C3%A4meri" title="Põhja-Jäämeri – Estonian">Eesti</a></li>
<li><a href="https://el.wikipedia.org/wiki/%CE%91%CF%81%CE%BA%CF%84%CE%B9%CE%BA%CF%8C%CF%82_%CE%A9%CE%BA%CE%B5%CE%B1%CE%BD%CF%8C%CF%82" title="Αρκτικός Ωκεανός – Greek">Ελληνικά</a></li>
<li><a href="https://myv.wikipedia.org/wiki/%D0%9F%D0%B5%D0%BB%D0%B5%D0%B2%D0%B5%D1%91%D0%BD%D0%BA%D1%81_%D0%AD%D0%B9%D0%B5%D0%BD%D1%8C_%D0%98%D0%BD%D0%B5%D0%B2%D0%B5%D0%B4%D1%8C" title="Пелевеёнкс Эйень Иневедь – Erzya">Эрзянь</a></li>
<li><a href="https://es.wikipedia.org/wiki/Oc%C3%A9ano_%C3%81rtico" title="Océano Ártico – Spanish">Español</a></li>
<li><a href="https://eo.wikipedia.org/wiki/Arkta_Oceano" title="Arkta Oceano – Esperanto">Esperanto</a></li>
<li><a href="https://ext.wikipedia.org/wiki/Oc%C3%A9anu_Glacial_%C3%81rticu" title="Océanu Glacial Árticu – Extremaduran">Estremeñu</a></li>
<li><a href="https://eu.wikipedia.org/wiki/Ozeano_Artikoa" title="Ozeano Artikoa – Basque">Euskara</a></li>
<li><a href="https://fa.wikipedia.org/wiki/%D8%A7%D9%82%DB%8C%D8%A7%D9%86%D9%88%D8%B3_%D9%85%D9%86%D8%AC%D9%85%D8%AF_%D8%B4%D9%85%D8%A7%D9%84%DB%8C" title="اقیانوس منجمد شمالی – Persian">فارسی</a></li>
<li><a href="https://hif.wikipedia.org/wiki/Arctic_Ocean" title="Arctic Ocean – Fiji Hindi">Fiji Hindi</a></li>
<li><a href="https://fo.wikipedia.org/wiki/Nor%C3%B0ur%C3%ADshavi%C3%B0" title="Norðuríshavið – Faroese">Føroyskt</a></li>
<li><a href="https://fr.wikipedia.org/wiki/Oc%C3%A9an_Arctique" title="Océan Arctique – French">Français</a></li>
<li><a href="https://fy.wikipedia.org/wiki/Noardlike_Iissee" title="Noardlike Iissee – Western Frisian">Frysk</a></li>
<li><a href="https://ga.wikipedia.org/wiki/An_tAig%C3%A9an_Artach" title="An tAigéan Artach – Irish">Gaeilge</a></li>
<li><a href="https://gv.wikipedia.org/wiki/Yn_Vooir_Arctagh" title="Yn Vooir Arctagh – Manx">Gaelg</a></li>
<li><a href="https://gd.wikipedia.org/wiki/Cuan_Argtach" title="Cuan Argtach – Scottish Gaelic">Gàidhlig</a></li>
<li><a href="https://gl.wikipedia.org/wiki/Oc%C3%A9ano_%C3%81rtico" title="Océano Ártico – Galician">Galego</a></li>
<li><a href="https://gan.wikipedia.org/wiki/%E5%8C%97%E5%86%B0%E6%B4%8B" title="北冰洋 – Gan Chinese">贛語</a></li>
<li><a href="https://ko.wikipedia.org/wiki/%EB%B6%81%EA%B7%B9%ED%95%B4" title="북극해 – Korean">한국어</a></li>
<li><a href="https://haw.wikipedia.org/wiki/Moana_%CA%BB%C4%80lika" title="Moana ʻĀlika – Hawaiian">Hawai`i</a></li>
<li><a href="https://hy.wikipedia.org/wiki/%D5%80%D5%B5%D5%B8%D6%82%D5%BD%D5%AB%D5%BD%D5%A1%D5%B5%D5%AB%D5%B6_%D5%BD%D5%A1%D5%BC%D5%B8%D6%82%D6%81%D5%B5%D5%A1%D5%AC_%D6%85%D5%BE%D5%AF%D5%AB%D5%A1%D5%B6%D5%B8%D5%BD" title="Հյուսիսային սառուցյալ օվկիանոս – Armenian">Հայերեն</a></li>
<li><a href="https://hi.wikipedia.org/wiki/%E0%A4%89%E0%A4%A4%E0%A5%8D%E0%A4%A4%E0%A4%B0%E0%A4%A7%E0%A5%8D%E0%A4%B0%E0%A5%81%E0%A4%B5%E0%A5%80%E0%A4%AF_%E0%A4%AE%E0%A4%B9%E0%A4%BE%E0%A4%B8%E0%A4%BE%E0%A4%97%E0%A4%B0" title="उत्तरध्रुवीय महासागर – Hindi">हिन्दी</a></li>
<li><a href="https://hsb.wikipedia.org/wiki/Sewjerny_polarny_ocean" title="Sewjerny polarny ocean – Upper Sorbian">Hornjoserbsce</a></li>
<li><a href="https://hr.wikipedia.org/wiki/Arkti%C4%8Dki_ocean" title="Arktički ocean – Croatian">Hrvatski</a></li>
<li><a href="https://io.wikipedia.org/wiki/Arktika_oceano" title="Arktika oceano – Ido">Ido</a></li>
<li><a href="https://ig.wikipedia.org/wiki/Arctic_Ocean" title="Arctic Ocean – Igbo">Igbo</a></li>
<li><a href="https://ilo.wikipedia.org/wiki/Taaw_Artiko" title="Taaw Artiko – Iloko">Ilokano</a></li>
<li><a href="https://id.wikipedia.org/wiki/Samudra_Arktik" title="Samudra Arktik – Indonesian">Bahasa Indonesia</a></li>
<li><a href="https://ia.wikipedia.org/wiki/Oceano_Arctic" title="Oceano Arctic – Interlingua">Interlingua</a></li>
<li><a href="https://xh.wikipedia.org/wiki/Ulwandle_i-Arctica" title="Ulwandle i-Arctica – Xhosa">IsiXhosa</a></li>
<li><a href="https://is.wikipedia.org/wiki/Nor%C3%B0ur-%C3%8Dshaf" title="Norður-Íshaf – Icelandic">Íslenska</a></li>
<li><a href="https://it.wikipedia.org/wiki/Mar_Glaciale_Artico" title="Mar Glaciale Artico – Italian">Italiano</a></li>
<li><a href="https://he.wikipedia.org/wiki/%D7%90%D7%95%D7%A7%D7%99%D7%99%D7%A0%D7%95%D7%A1_%D7%94%D7%A7%D7%A8%D7%97_%D7%94%D7%A6%D7%A4%D7%95%D7%A0%D7%99" title="אוקיינוס הקרח הצפוני – Hebrew">עברית</a></li>
<li><a href="https://jv.wikipedia.org/wiki/Samudra_Arktika" title="Samudra Arktika – Javanese">Basa Jawa</a></li>
<li><a href="https://kn.wikipedia.org/wiki/%E0%B2%86%E0%B2%B0%E0%B3%8D%E0%B2%95%E0%B3%8D%E0%B2%9F%E0%B2%BF%E0%B2%95%E0%B3%8D_%E0%B2%AE%E0%B2%B9%E0%B2%BE%E0%B2%B8%E0%B2%BE%E0%B2%97%E0%B2%B0" title="ಆರ್ಕ್ಟಿಕ್ ಮಹಾಸಾಗರ – Kannada">ಕನ್ನಡ</a></li>
<li><a href="https://pam.wikipedia.org/wiki/Artiko_Kadayatmalatan" title="Artiko Kadayatmalatan – Pampanga">Kapampangan</a></li>
<li><a href="https://krc.wikipedia.org/wiki/%D0%A8%D0%B8%D0%BC%D0%B0%D0%BB_%D0%91%D1%83%D0%B7%D0%BB%D0%B0%D1%83%D1%83%D0%BA%D1%8A_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Шимал Бузлауукъ океан – Karachay-Balkar">Къарачай-малкъар</a></li>
<li><a href="https://ka.wikipedia.org/wiki/%E1%83%A9%E1%83%A0%E1%83%93%E1%83%98%E1%83%9A%E1%83%9D%E1%83%94%E1%83%97%E1%83%98%E1%83%A1_%E1%83%A7%E1%83%98%E1%83%9C%E1%83%A3%E1%83%9A%E1%83%9D%E1%83%95%E1%83%90%E1%83%9C%E1%83%98_%E1%83%9D%E1%83%99%E1%83%94%E1%83%90%E1%83%9C%E1%83%94" title="ჩრდილოეთის ყინულოვანი ოკეანე – Georgian">ქართული</a></li>
<li><a href="https://kk.wikipedia.org/wiki/%D0%A1%D0%BE%D0%BB%D1%82%D2%AF%D1%81%D1%82%D1%96%D0%BA_%D0%9C%D2%B1%D0%B7%D0%B4%D1%8B_%D0%BC%D2%B1%D1%85%D0%B8%D1%82" title="Солтүстік Мұзды мұхит – Kazakh">Қазақша</a></li>
<li><a href="https://sw.wikipedia.org/wiki/Bahari_ya_Aktiki" title="Bahari ya Aktiki – Swahili">Kiswahili</a></li>
<li><a href="https://ht.wikipedia.org/wiki/Aktik" title="Aktik – Haitian">Kreyòl ayisyen</a></li>
<li><a href="https://ku.wikipedia.org/wiki/Okyan%C3%BBsa_Arkt%C3%AEk" title="Okyanûsa Arktîk – Kurdish">Kurdî</a></li>
<li><a href="https://lez.wikipedia.org/wiki/%D0%9A%D0%B5%D1%84%D0%B5%D1%80%D0%BF%D0%B0%D1%82%D0%B0%D0%BD_%D0%9C%D1%83%D1%80%D0%BAI%D0%B0%D1%80%D0%B8%D0%BD_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Кеферпатан МуркIарин океан – Lezghian">Лезги</a></li>
<li><a href="https://la.wikipedia.org/wiki/Oceanus_Arcticus" title="Oceanus Arcticus – Latin">Latina</a></li>
<li><a href="https://lv.wikipedia.org/wiki/Zieme%C4%BCu_Ledus_oke%C4%81ns" title="Ziemeļu Ledus okeāns – Latvian">Latviešu</a></li>
<li><a href="https://lt.wikipedia.org/wiki/Arkties_vandenynas" title="Arkties vandenynas – Lithuanian">Lietuvių</a></li>
<li><a href="https://jbo.wikipedia.org/wiki/artik.zei_braxamsi" title="artik.zei braxamsi – Lojban">Lojban</a></li>
<li><a href="https://lmo.wikipedia.org/wiki/Ucean_Artich" title="Ucean Artich – Lombard">Lumbaart</a></li>
<li><a href="https://hu.wikipedia.org/wiki/Jeges-tenger" title="Jeges-tenger – Hungarian">Magyar</a></li>
<li><a href="https://mk.wikipedia.org/wiki/%D0%A1%D0%B5%D0%B2%D0%B5%D1%80%D0%B5%D0%BD_%D0%9B%D0%B5%D0%B4%D0%B5%D0%BD_%D0%9E%D0%BA%D0%B5%D0%B0%D0%BD" title="Северен Леден Океан – Macedonian">Македонски</a></li>
<li><a href="https://mg.wikipedia.org/wiki/Ranomasimbe_Arktika" title="Ranomasimbe Arktika – Malagasy">Malagasy</a></li>
<li><a href="https://ml.wikipedia.org/wiki/%E0%B4%86%E0%B5%BC%E0%B4%9F%E0%B5%8D%E0%B4%9F%E0%B4%BF%E0%B4%95%E0%B5%8D_%E0%B4%B8%E0%B4%AE%E0%B5%81%E0%B4%A6%E0%B5%8D%E0%B4%B0%E0%B4%82" title="ആർട്ടിക് സമുദ്രം – Malayalam">മലയാളം</a></li>
<li><a href="https://mr.wikipedia.org/wiki/%E0%A4%86%E0%A4%B0%E0%A5%8D%E0%A4%95%E0%A5%8D%E0%A4%9F%E0%A4%BF%E0%A4%95_%E0%A4%AE%E0%A4%B9%E0%A4%BE%E0%A4%B8%E0%A4%BE%E0%A4%97%E0%A4%B0" title="आर्क्टिक महासागर – Marathi">मराठी</a></li>
<li><a href="https://xmf.wikipedia.org/wiki/%E1%83%9D%E1%83%9D%E1%83%A0%E1%83%A3%E1%83%94_%E1%83%B8%E1%83%98%E1%83%9C%E1%83%A3%E1%83%90%E1%83%9B%E1%83%98_%E1%83%9D%E1%83%99%E1%83%98%E1%83%90%E1%83%9C%E1%83%94" title="ოორუე ჸინუამი ოკიანე – Mingrelian">მარგალური</a></li>
<li><a href="https://ms.wikipedia.org/wiki/Lautan_Artik" title="Lautan Artik – Malay">Bahasa Melayu</a></li>
<li><a href="https://min.wikipedia.org/wiki/Samudra_Artik" title="Samudra Artik – Minangkabau">Baso Minangkabau</a></li>
<li><a href="https://cdo.wikipedia.org/wiki/B%C3%A1e%CC%A4k-b%C4%ADng-i%C3%B2ng" title="Báe̤k-bĭng-iòng – Min Dong Chinese">Mìng-dĕ̤ng-ngṳ̄</a></li>
<li><a href="https://mwl.wikipedia.org/wiki/Ouceano_%C3%81rtico" title="Ouceano Ártico – Mirandese">Mirandés</a></li>
<li><a href="https://mn.wikipedia.org/wiki/%D0%A3%D0%BC%D0%B0%D1%80%D0%B4_%D0%BC%D3%A9%D1%81%D3%A9%D0%BD_%D0%B4%D0%B0%D0%BB%D0%B0%D0%B9" title="Умард мөсөн далай – Mongolian">Монгол</a></li>
<li><a href="https://my.wikipedia.org/wiki/%E1%80%A1%E1%80%AC%E1%80%90%E1%80%AD%E1%80%90%E1%80%BA_%E1%80%9E%E1%80%99%E1%80%AF%E1%80%92%E1%80%B9%E1%80%92%E1%80%9B%E1%80%AC" title="အာတိတ် သမုဒ္ဒရာ – Burmese">မြန်မာဘာသာ</a></li>
<li><a href="https://nah.wikipedia.org/wiki/Ilhuica%C4%81tl_%C3%81rtico" title="Ilhuicaātl Ártico – Nāhuatl">Nāhuatl</a></li>
<li><a href="https://nl.wikipedia.org/wiki/Noordelijke_IJszee" title="Noordelijke IJszee – Dutch">Nederlands</a></li>
<li><a href="https://ne.wikipedia.org/wiki/%E0%A4%86%E0%A4%B0%E0%A5%8D%E0%A4%95%E0%A4%9F%E0%A4%BF%E0%A4%95_%E0%A4%AE%E0%A4%B9%E0%A4%BE%E0%A4%B8%E0%A4%BE%E0%A4%97%E0%A4%B0" title="आर्कटिक महासागर – Nepali">नेपाली</a></li>
<li><a href="https://new.wikipedia.org/wiki/%E0%A4%86%E0%A4%B0%E0%A5%8D%E0%A4%9F%E0%A4%BF%E0%A4%95_%E0%A4%AE%E0%A4%B9%E0%A4%BE%E0%A4%B8%E0%A4%BE%E0%A4%97%E0%A4%B0" title="आर्टिक महासागर – Newari">नेपाल भाषा</a></li>
<li><a href="https://ja.wikipedia.org/wiki/%E5%8C%97%E6%A5%B5%E6%B5%B7" title="北極海 – Japanese">日本語</a></li>
<li><a href="https://ce.wikipedia.org/wiki/%D0%9A%D1%8A%D0%B8%D0%BB%D0%B1%D0%B0%D1%81%D0%B5%D0%B4%D0%B0_%D0%A8%D0%B5%D0%BD_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Къилбаседа Шен океан – Chechen">Нохчийн</a></li>
<li><a href="https://frr.wikipedia.org/wiki/Arktisk_Sia" title="Arktisk Sia – Northern Frisian">Nordfriisk</a></li>
<li><a href="https://no.wikipedia.org/wiki/Nordishavet" title="Nordishavet – Norwegian">Norsk bokmål</a></li>
<li><a href="https://nn.wikipedia.org/wiki/Nordishavet" title="Nordishavet – Norwegian Nynorsk">Norsk nynorsk</a></li>
<li><a href="https://oc.wikipedia.org/wiki/Ocean_Artic" title="Ocean Artic – Occitan">Occitan</a></li>
<li><a href="https://mhr.wikipedia.org/wiki/%D0%99%D3%B1%D0%B4%D0%B2%D0%B5%D0%BB_%D1%82%D0%B5%D0%BF%D1%82%D0%B5%D2%A5%D1%8B%D0%B7" title="Йӱдвел тептеҥыз – Eastern Mari">Олык марий</a></li>
<li><a href="https://om.wikipedia.org/wiki/Garba_Arkitiik" title="Garba Arkitiik – Oromo">Oromoo</a></li>
<li><a href="https://uz.wikipedia.org/wiki/Shimoliy_Muz_okeani" title="Shimoliy Muz okeani – Uzbek">Oʻzbekcha/ўзбекча</a></li>
<li><a href="https://pa.wikipedia.org/wiki/%E0%A8%86%E0%A8%B0%E0%A8%95%E0%A8%9F%E0%A8%BF%E0%A8%95_%E0%A8%AE%E0%A8%B9%E0%A8%BE%E0%A8%82%E0%A8%B8%E0%A8%BE%E0%A8%97%E0%A8%B0" title="ਆਰਕਟਿਕ ਮਹਾਂਸਾਗਰ – Punjabi">ਪੰਜਾਬੀ</a></li>
<li><a href="https://pnb.wikipedia.org/wiki/%D9%88%DA%88%D8%A7_%D8%B3%D9%85%D9%86%D8%AF%D8%B1_%D8%A2%D8%B1%DA%A9%D9%B9%DA%A9" title="وڈا سمندر آرکٹک – Western Punjabi">پنجابی</a></li>
<li><a href="https://ps.wikipedia.org/wiki/%D8%B4%D9%85%D8%A7%D9%84%D9%8A_%D9%82%D8%B7%D8%A8%D9%8A_%D8%B3%D9%85%D9%86%D8%AF%D8%B1" title="شمالي قطبي سمندر – Pashto">پښتو</a></li>
<li><a href="https://koi.wikipedia.org/wiki/%D0%9E%D0%B9%D0%B2%D1%8B%D0%B2_%D0%99%D1%8B%D0%B0_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Ойвыв Йыа океан – Komi-Permyak">Перем Коми</a></li>
<li><a href="https://km.wikipedia.org/wiki/%E1%9E%98%E1%9E%A0%E1%9E%B6%E1%9E%9F%E1%9E%98%E1%9E%BB%E1%9E%91%E1%9F%92%E1%9E%9A%E1%9E%A2%E1%9E%B6%E1%9E%80%E1%9E%91%E1%9E%B7%E1%9E%80" title="មហាសមុទ្រអាកទិក – Khmer">ភាសាខ្មែរ</a></li>
<li><a href="https://pms.wikipedia.org/wiki/Oc%C3%A9an_%C3%80rtich" title="Océan Àrtich – Piedmontese">Piemontèis</a></li>
<li><a href="https://pl.wikipedia.org/wiki/Ocean_Arktyczny" title="Ocean Arktyczny – Polish">Polski</a></li>
<li><a href="https://pt.wikipedia.org/wiki/Oceano_%C3%81rtico" title="Oceano Ártico – Portuguese">Português</a></li>
<li><a href="https://crh.wikipedia.org/wiki/Arktik_okean" title="Arktik okean – Crimean Turkish">Qırımtatarca</a></li>
<li><a href="https://ro.wikipedia.org/wiki/Oceanul_Arctic" title="Oceanul Arctic – Romanian">Română</a></li>
<li><a href="https://rm.wikipedia.org/wiki/Ocean_Arctic" title="Ocean Arctic – Romansh">Rumantsch</a></li>
<li><a href="https://qu.wikipedia.org/wiki/Artiku_mama_qucha" title="Artiku mama qucha – Quechua">Runa Simi</a></li>
<li><a href="https://rue.wikipedia.org/wiki/%D0%A1%D0%B5%D0%B2%D0%B5%D1%80%D0%BD%D1%8B%D0%B9_%D0%BB%D0%B5%D0%B4%D0%BE%D0%B2%D1%8B%D0%B9_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Северный ледовый океан – Rusyn">Русиньскый</a></li>
<li><a href="https://ru.wikipedia.org/wiki/%D0%A1%D0%B5%D0%B2%D0%B5%D1%80%D0%BD%D1%8B%D0%B9_%D0%9B%D0%B5%D0%B4%D0%BE%D0%B2%D0%B8%D1%82%D1%8B%D0%B9_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Северный Ледовитый океан – Russian">Русский</a></li>
<li><a href="https://sah.wikipedia.org/wiki/%D0%A5%D0%BE%D1%82%D1%83_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Хоту океан – Sakha">Саха тыла</a></li>
<li><a href="https://sa.wikipedia.org/wiki/%E0%A4%89%E0%A4%A4%E0%A5%8D%E0%A4%A4%E0%A4%B0%E0%A4%A7%E0%A5%8D%E0%A4%B0%E0%A5%81%E0%A4%B5%E0%A5%80%E0%A4%AF%E0%A4%AE%E0%A4%B9%E0%A4%BE%E0%A4%B8%E0%A4%BE%E0%A4%97%E0%A4%B0%E0%A4%83" title="उत्तरध्रुवीयमहासागरः – Sanskrit">संस्कृतम्</a></li>
<li><a href="https://nso.wikipedia.org/wiki/Arctic_Ocean" title="Arctic Ocean – Northern Sotho">Sesotho sa Leboa</a></li>
<li><a href="https://scn.wikipedia.org/wiki/Oc%C3%A8anu_%C3%80rticu" title="Ocèanu Àrticu – Sicilian">Sicilianu</a></li>
<li><a href="https://simple.wikipedia.org/wiki/Arctic_Ocean" title="Arctic Ocean – Simple English">Simple English</a></li>
<li><a href="https://sk.wikipedia.org/wiki/Severn%C3%BD_%C4%BEadov%C3%BD_oce%C3%A1n" title="Severný ľadový oceán – Slovak">Slovenčina</a></li>
<li><a href="https://sl.wikipedia.org/wiki/Arkti%C4%8Dni_ocean" title="Arktični ocean – Slovenian">Slovenščina</a></li>
<li><a href="https://szl.wikipedia.org/wiki/Arktyczny_Uocean" title="Arktyczny Uocean – Silesian">Ślůnski</a></li>
<li><a href="https://ckb.wikipedia.org/wiki/%D8%A6%DB%86%D9%82%DB%8C%D8%A7%D9%86%D9%88%D9%88%D8%B3%DB%8C_%D8%A6%D8%A7%D8%B1%DA%A9%D8%AA%DB%8C%DA%A9" title="ئۆقیانووسی ئارکتیک – Central Kurdish">کوردیی ناوەندی</a></li>
<li><a href="https://sr.wikipedia.org/wiki/%D0%A1%D0%B5%D0%B2%D0%B5%D1%80%D0%BD%D0%B8_%D0%BB%D0%B5%D0%B4%D0%B5%D0%BD%D0%B8_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Северни ледени океан – Serbian">Српски / srpski</a></li>
<li><a href="https://sh.wikipedia.org/wiki/Arkti%C4%8Dki_ocean" title="Arktički ocean – Serbo-Croatian">Srpskohrvatski / српскохрватски</a></li>
<li><a href="https://fi.wikipedia.org/wiki/Pohjoinen_j%C3%A4%C3%A4meri" title="Pohjoinen jäämeri – Finnish">Suomi</a></li>
<li><a href="https://sv.wikipedia.org/wiki/Norra_ishavet" title="Norra ishavet – Swedish">Svenska</a></li>
<li><a href="https://tl.wikipedia.org/wiki/Karagatang_Artiko" title="Karagatang Artiko – Tagalog">Tagalog</a></li>
<li><a href="https://ta.wikipedia.org/wiki/%E0%AE%86%E0%AE%B0%E0%AF%8D%E0%AE%95%E0%AF%8D%E0%AE%9F%E0%AE%BF%E0%AE%95%E0%AF%8D_%E0%AE%AA%E0%AF%86%E0%AE%B0%E0%AF%81%E0%AE%99%E0%AF%8D%E0%AE%95%E0%AE%9F%E0%AE%B2%E0%AF%8D" title="ஆர்க்டிக் பெருங்கடல் – Tamil">தமிழ்</a></li>
<li><a href="https://kab.wikipedia.org/wiki/Agaraw_Arkti" title="Agaraw Arkti – Kabyle">Taqbaylit</a></li>
<li><a href="https://roa-tara.wikipedia.org/wiki/Mar_Glaciale_Arteche" title="Mar Glaciale Arteche – tarandíne">Tarandíne</a></li>
<li><a href="https://tt.wikipedia.org/wiki/%D0%A2%D3%A9%D0%BD%D1%8C%D1%8F%D0%BA_%D0%91%D0%BE%D0%B7_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD%D1%8B" title="Төньяк Боз океаны – Tatar">Татарча/tatarça</a></li>
<li><a href="https://te.wikipedia.org/wiki/%E0%B0%86%E0%B0%B0%E0%B1%8D%E0%B0%95%E0%B1%8D%E2%80%8C%E0%B0%9F%E0%B0%BF%E0%B0%95%E0%B1%8D_%E0%B0%AE%E0%B0%B9%E0%B0%BE%E0%B0%B8%E0%B0%AE%E0%B1%81%E0%B0%A6%E0%B1%8D%E0%B0%B0%E0%B0%82" title="ఆర్క్‌టిక్ మహాసముద్రం – Telugu">తెలుగు</a></li>
<li><a href="https://th.wikipedia.org/wiki/%E0%B8%A1%E0%B8%AB%E0%B8%B2%E0%B8%AA%E0%B8%A1%E0%B8%B8%E0%B8%97%E0%B8%A3%E0%B8%AD%E0%B8%B2%E0%B8%A3%E0%B9%8C%E0%B8%81%E0%B8%95%E0%B8%B4%E0%B8%81" title="มหาสมุทรอาร์กติก – Thai">ไทย</a></li>
<li><a href="https://tg.wikipedia.org/wiki/%D0%A3%D2%9B%D1%91%D0%BD%D1%83%D1%81%D0%B8_%D1%8F%D1%85%D0%B1%D0%B0%D1%81%D1%82%D0%B0%D0%B8_%D1%88%D0%B8%D0%BC%D0%BE%D0%BB%D3%A3" title="Уқёнуси яхбастаи шимолӣ – Tajik">Тоҷикӣ</a></li>
<li><a href="https://tr.wikipedia.org/wiki/Arktik_Okyanusu" title="Arktik Okyanusu – Turkish">Türkçe</a></li>
<li><a href="https://tk.wikipedia.org/wiki/Demirgazyk_Buzly_okean" title="Demirgazyk Buzly okean – Turkmen">Türkmençe</a></li>
<li><a href="https://udm.wikipedia.org/wiki/%D0%A3%D0%B9%D0%BF%D0%B0%D0%BB_%D0%99%D3%A7_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Уйпал Йӧ океан – Udmurt">Удмурт</a></li>
<li><a href="https://uk.wikipedia.org/wiki/%D0%9F%D1%96%D0%B2%D0%BD%D1%96%D1%87%D0%BD%D0%B8%D0%B9_%D0%9B%D1%8C%D0%BE%D0%B4%D0%BE%D0%B2%D0%B8%D1%82%D0%B8%D0%B9_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Північний Льодовитий океан – Ukrainian">Українська</a></li>
<li><a href="https://ur.wikipedia.org/wiki/%D8%A8%D8%AD%D8%B1_%D9%85%D9%86%D8%AC%D9%85%D8%AF_%D8%B4%D9%85%D8%A7%D9%84%DB%8C" title="بحر منجمد شمالی – Urdu">اردو</a></li>
<li><a href="https://za.wikipedia.org/wiki/Baekbinghyangz" title="Baekbinghyangz – Zhuang">Vahcuengh</a></li>
<li><a href="https://vec.wikipedia.org/wiki/Mar_Giazzal_Artego" title="Mar Giazzal Artego – Venetian">Vèneto</a></li>
<li><a href="https://vep.wikipedia.org/wiki/J%C3%A4valdmeri" title="Jävaldmeri – Veps">Vepsän kel’</a></li>
<li><a href="https://vi.wikipedia.org/wiki/B%E1%BA%AFc_B%C4%83ng_D%C6%B0%C6%A1ng" title="Bắc Băng Dương – Vietnamese">Tiếng Việt</a></li>
<li><a href="https://fiu-vro.wikipedia.org/wiki/P%C3%B5h%27a-I%C3%A4meri" title="Põh'a-Iämeri – Võro">Võro</a></li>
<li><a href="https://wa.wikipedia.org/wiki/Oceyan_Artike" title="Oceyan Artike – Walloon">Walon</a></li>
<li><a href="https://war.wikipedia.org/wiki/Kalawdan_Artico" title="Kalawdan Artico – Waray">Winaray</a></li>
<li><a href="https://wo.wikipedia.org/wiki/Mb%C3%A0mbulaan_gu_B%C3%ABj-g%C3%A0nnaar" title="Mbàmbulaan gu Bëj-gànnaar – Wolof">Wolof</a></li>
<li><a href="https://yi.wikipedia.org/wiki/%D7%90%D7%A8%D7%A7%D7%98%D7%99%D7%A9%D7%A2%D7%A8_%D7%90%D7%A7%D7%A2%D7%90%D7%9F" title="ארקטישער אקעאן – Yiddish">ייִדיש</a></li>
<li><a href="https://yo.wikipedia.org/wiki/%C3%92kun_%C3%81rkt%C3%ACk%C3%AC" title="Òkun Árktìkì – Yoruba">Yorùbá</a></li>
<li><a href="https://zh-yue.wikipedia.org/wiki/%E5%8C%97%E5%86%B0%E6%B4%8B" title="北冰洋 – Cantonese">粵語</a></li>
<li><a href="https://diq.wikipedia.org/wiki/Okyanuso_Arktik" title="Okyanuso Arktik – Zazaki">Zazaki</a></li>
<li><a href="https://bat-smg.wikipedia.org/wiki/Arkt%C4%97is_ond%C4%97n%C4%ABns" title="Arktėis ondėnīns – Samogitian">Žemaitėška</a></li>
<li><a href="https://zh.wikipedia.org/wiki/%E5%8C%97%E5%86%B0%E6%B4%8B" title="北冰洋 – Chinese">中文</a></li>
<li><a href="https://tyv.wikipedia.org/wiki/%D0%A1%D0%BE%D2%A3%D0%B3%D1%83_%D0%94%D0%BE%D1%88%D1%82%D1%83%D0%B3_%D0%BE%D0%BA%D0%B5%D0%B0%D0%BD" title="Соңгу Доштуг океан – Tuvinian">Тыва дыл</a></li>
<li><a href="https://en.wikipedia.org/wiki#"></a></li> 
</ul> 
<div>
<span><a href="https://www.wikidata.org/wiki/Q788#sitelinks-wikipedia" title="Edit interlanguage links">Edit links</a></span>
</div> 
</div> 
</div> 
</div> 
</div> 
<div> 
<ul> 
<li> This page was last modified on 5 August 2015, at 23:12.</li> 
<li>Text is available under the <a href="https://en.wikipedia.org/wiki/Wikipedia:Text_of_Creative_Commons_Attribution-ShareAlike_3.0_Unported_License">Creative Commons Attribution-ShareAlike License</a><a href="https://creativecommons.org/licenses/by-sa/3.0/"></a>; additional terms may apply. By using this site, you agree to the <a href="https://wikimediafoundation.org/wiki/Terms_of_Use">Terms of Use</a> and <a href="https://wikimediafoundation.org/wiki/Privacy_policy">Privacy Policy</a>. Wikipedia® is a registered trademark of the <a href="https://www.wikimediafoundation.org/">Wikimedia Foundation, Inc.</a>, a non-profit organization.</li> 
</ul> 
<ul> 
<li><a href="https://wikimediafoundation.org/wiki/Privacy_policy" title="wikimedia:Privacy policy">Privacy policy</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:About" title="Wikipedia:About">About Wikipedia</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:General_disclaimer" title="Wikipedia:General disclaimer">Disclaimers</a></li> 
<li><a href="https://en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact Wikipedia</a></li> 
<li><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li> 
<li><a href="https://en.m.wikipedia.org/w/index.php?title=Arctic_Ocean&amp;mobileaction=toggle_view_mobile">Mobile view</a></li> 
</ul> 
<ul> 
<li> <a href="https://wikimediafoundation.org/"><img src="https://en.wikipedia.org/static/images/wikimedia-button.png" width="88" height="31" alt="Wikimedia Foundation"></a> </li> 
<li> <a href="https://www.mediawiki.org/"><img src="https://en.wikipedia.org/static/1.26wmf18/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" width="88" height="31"></a> </li> 
</ul> 
<div></div> 
</div>